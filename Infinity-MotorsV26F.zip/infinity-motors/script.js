// ═════════════════════════════════════════════════════════════════════════════════
// INFINITY MOTORS - SCRIPT PRINCIPAL
// Gestiona navegación, catálogo dinámico, modales, chat y validaciones globales
// Cada función está documentada línea por línea explicando su interacción con el sistema
// ═════════════════════════════════════════════════════════════════════════════════

// FUNCIÓN: mostrarNotificacion
// Propósito: Mostrar mensaje emergente en esquina superior derecha de la página
// Interactúa con: HTML (div#notification), CSS (clases .notification .show .error .success)
// Llamada desde: cargarProductos, initNavbar, formularios de login/registro/perfil
function mostrarNotificacion(texto, isError = false) {
  // Obtiene el elemento contenedor de notificaciones del DOM (id="notification")
  const notif = document.getElementById("notification")

  // Valida que el elemento exista antes de continuar (previene errores)
  if (!notif) return

  // Inicializa variable para almacenar el texto procesado
  let cleanText = texto

  try {
    // Intenta decodificar URL encoding (ej: "Hola+Mundo" → "Hola Mundo")
    // Necesario porque algunos mensajes vienen codificados desde PHP/URLs
    cleanText = decodeURIComponent(texto.replace(/\+/g, " "))
  } catch (e) {
    // Si falla la decodificación, usa el texto original sin cambios
    console.warn("No se pudo decodificar el texto de la notificación:", texto)
  }

  // Asigna el texto limpio al contenedor para que sea visible en pantalla
  notif.textContent = cleanText

  // Construye dinámicamente la clase CSS: "notification" base + "error" o "success" + "show" para animación
  // isError true = color rojo, isError false = color verde
  notif.className = `notification ${isError ? "error" : "success"} show`

  // Programar ocultamiento automático después de 4 segundos (4000 ms)
  // Remueve la clase "show" que activa la animación de salida
  setTimeout(() => notif.classList.remove("show"), 4000)
}

// FUNCIÓN: initNavbar
// Propósito: Inicializar navbar con efecto sticky, menú móvil y notificaciones de URL
// Interactúa con: HTML (header.navbar, .mobile-toggle), window.location, URLSearchParams
// Se ejecuta una única vez cuando el DOM carga (DOMContentLoaded)
function initNavbar() {
  // Selecciona el elemento navbar (barra de navegación superior)
  const navbar = document.querySelector(".navbar")

  // Selecciona el botón que alterna el menú en dispositivos móviles
  const mobileToggle = document.querySelector(".mobile-toggle")

  // Si existe el navbar, añade animación después de 100ms para que no aparezca instantáneamente
  if (navbar) {
    setTimeout(() => {
      // Añade la clase "nav-animated" que activa una transición suave en CSS
      navbar.classList.add("nav-animated")
    }, 100)

    // Registra un listener en el evento "scroll" de la ventana (cuando usuario hace scroll)
    window.addEventListener("scroll", () => {
      // Alterna la clase "sticky" si el usuario ha hecho scroll más de 50px
      // Cuando está activa, el navbar se ve diferente (más pegajoso/prominente)
      navbar.classList.toggle("sticky", window.scrollY > 50)
    })
  }

  // Si existen ambos elementos (toggle y navbar), activa la funcionalidad de menú móvil
  if (mobileToggle && navbar) {
    // Al hacer clic en el toggle, alterna la clase "open-nav" en el navbar
    // Esta clase abre/cierra el menú mediante CSS (display, transform, etc)
    mobileToggle.addEventListener("click", () => {
      navbar.classList.toggle("open-nav")
    })
  }

  // ═══ SECCIÓN: Manejo de notificaciones de URL ═══
  // Detecta parámetros en la URL como ?msg=Bienvenido o ?error=Acceso+denegado
  // Útil para mostrar mensajes después de redirecciones desde PHP

  // Crea objeto URLSearchParams a partir de la querystring de la URL actual
  const params = new URLSearchParams(window.location.search)

  // Verifica si la URL contiene parámetro "msg" O parámetro "error"
  if (params.has("msg") || params.has("error")) {
    // Obtiene el valor del primer parámetro disponible (msg tiene prioridad sobre error)
    const message = params.get("msg") || params.get("error")

    // Determina si es un mensaje de error (presencia del parámetro "error" en la URL)
    const isError = params.has("error")

    // Llama a mostrarNotificacion con el mensaje y el tipo (error o éxito)
    mostrarNotificacion(message, isError)

    // Limpia la URL sin hacer reload de la página
    // Previene que el mensaje aparezca nuevamente si el usuario presiona F5 (recargar)
    history.replaceState(null, "", window.location.pathname)
  }
}

// FUNCIÓN: configurarListenersCatalogo
// Propósito: Configurar botones interactivos del catálogo (ver descripción, editar, eliminar, detalles)
// Interactúa con: HTML (botones .ver-desc .editar .eliminar .ver-detalles), modales, API
// Parámetros:
//   - showManagementButtons: true si usuario es admin (muestra botones editar/eliminar)
//   - currentFetchUrl: URL del endpoint para recargar catálogo después de cambios
//   - isRegularUser: true si es usuario normal (muestra enlace a cotizar)
function configurarListenersCatalogo(showManagementButtons, currentFetchUrl, isRegularUser) {
  // ═══ FUNCIONALIDAD 1: Ver/Ocultar Descripción ═══
  // Aplica a todos los botones con clase "ver-desc" en el catálogo

  // Itera sobre cada botón de "Ver descripción"
  document.querySelectorAll(".ver-desc").forEach((btn) => {
    // Al hacer clic en el botón
    btn.addEventListener("click", function () {
      // Obtiene el elemento siguiente (hermano) que es la descripción
      // nextElementSibling devuelve el próximo elemento HTML (no texto)
      const desc = this.nextElementSibling

      // Valida que la descripción existe antes de manipularla
      if (desc) {
        // Obtiene el estado actual del display (oculto o visible)
        // Si está vacío o "none", significa que está oculta
        const isHidden = desc.style.display === "none" || desc.style.display === ""

        // Alterna visibilidad: si estaba oculta, la muestra; si estaba visible, la oculta
        desc.style.display = isHidden ? "block" : "none"

        // Actualiza el texto del botón dinámicamente según el nuevo estado
        this.textContent = isHidden ? "Ocultar descripción" : "Ver descripción"
      }
    })
  })

  // ═══ FUNCIONALIDAD 2: Botones de Gestión (Solo para Admin) ═══
  // Solo se configura si showManagementButtons es true

  if (showManagementButtons) {
    // ─────────────────────────────────────────────
    // SUBFUNCIONALIDAD 2A: Botón Eliminar Vehículo
    // ─────────────────────────────────────────────

    // Itera sobre todos los botones con clase "eliminar"
    document.querySelectorAll(".eliminar").forEach((btn) => {
      // Al hacer clic en botón eliminar
      btn.addEventListener("click", function () {
        // Obtiene el ID del vehículo del atributo data-id del botón
        const id = this.getAttribute("data-id")

        // Busca hacia arriba (closest) hasta encontrar el contenedor .car
        // Luego busca dentro el h3 (título/modelo del vehículo)
        const model = this.closest(".car").querySelector("h3").textContent

        // Muestra diálogo de confirmación al usuario
        // confirm() retorna true si hace clic OK, false si Cancelar
        if (confirm(`¿Seguro que quieres eliminar "${model}" (ID: ${id})?\n\nEsta acción no se puede deshacer.`)) {
          // Si usuario confirma, realiza petición fetch GET al backend PHP
          fetch(`php/gestionar_vehiculos.php?action=deleteCar&id=${id}`)
            // Convierte la respuesta HTTP a texto (recibe mensaje del servidor)
            .then((res) => res.text())
            // Maneja el resultado exitoso
            .then((msg) => {
              // Muestra notificación de éxito con el mensaje recibido del backend
              mostrarNotificacion(msg || "Vehículo eliminado correctamente.", false)

              // Recarga la lista completa para reflejar la eliminación
              cargarProductos(currentFetchUrl, true, false)
            })
            // Maneja errores de conexión o ejecución
            .catch((err) => {
              console.error("Error al eliminar:", err)
              mostrarNotificacion("Ocurrió un error al eliminar el vehículo.", true)
            })
        }
        // Si usuario cancela, no sucede nada
      })
    })

    // ─────────────────────────────────────────────
    // SUBFUNCIONALIDAD 2B: Modal de Edición
    // ─────────────────────────────────────────────

    // Obtiene el elemento modal que contiene el formulario de edición
    const editModal = document.getElementById("edit-modal")

    // Itera sobre todos los botones con clase "editar"
    document.querySelectorAll(".editar").forEach((btn) => {
      // Al hacer clic en botón editar
      btn.addEventListener("click", function () {
        // Valida que el modal exista antes de abrir
        if (editModal) {
          // Busca el contenedor .car más cercano (tarjeta del vehículo)
          const card = this.closest(".car")

          // Extrae el JSON almacenado en data-car-data (contiene todos los datos del auto)
          // JSON.parse() convierte el string JSON a objeto JavaScript
          const carData = JSON.parse(card.dataset.carData)

          // Obtiene el formulario dentro del modal
          const editForm = document.getElementById("edit-modal-form")

          // ═══ LLENAR CAMPOS DEL MODAL CON DATOS DEL VEHÍCULO ═══

          // Establece título del modal: "Editando: [nombre del modelo]"
          document.getElementById("edit-modal-title").textContent = `Editando: ${carData.modelo}`

          // Rellena el campo oculto con el ID del vehículo (necesario para identificar qué editar)
          editForm.querySelector("#edit-car-id").value = carData.id

          // Rellena cada campo del formulario con los datos actuales del vehículo
          editForm.querySelector("#edit-modelo").value = carData.modelo
          editForm.querySelector("#edit-precio").value = carData.precio
          editForm.querySelector("#edit-estado").value = carData.estado
          editForm.querySelector("#edit-vendedor_id").value = carData.vendedor_id
          editForm.querySelector("#edit-descripcion").value = carData.descripcion || ""

          // Establece la imagen actual del vehículo en la vista previa
          // Construye la ruta: "uploads/[nombre_archivo]"
          document.getElementById("edit-current-image").src = `uploads/${carData.imagen}`

          // Añade la clase "show" al modal para hacerlo visible
          // CSS utilizará esta clase para aplicar display: flex, opacity: 1, etc
          editModal.classList.add("show")
        } else {
          // Fallback: si no existe modal, redirige a página de edición antigua
          const id = this.getAttribute("data-id")
          window.location.href = `editarCar.php?id=${id}`
        }
      })
    })
  } else {
    // ═══ FUNCIONALIDAD 3: Para Usuarios Normales (No Admin) ═══
    // Si no es admin, se muestra funcionalidad limitada

    // Itera sobre todos los botones con clase "ver-detalles"
    document.querySelectorAll(".ver-detalles").forEach((btn) => {
      // Al hacer clic
      btn.addEventListener("click", function () {
        // Obtiene el ID del vehículo desde atributo data-id
        const id = this.getAttribute("data-id")

        // Redirige a la página de detalles específica del vehículo
        window.location.href = `vehiculo.php?id=${id}`
      })
    })
  }
}

// FUNCIÓN: cargarProductos
// Propósito: Cargar catálogo de vehículos desde servidor y renderizar en HTML
// Interactúa con: API backend (php/gestionar_vehiculos.php), HTML #car-list, CSS .car
// Parámetros:
//   - fetchUrl: URL del endpoint que devuelve JSON con vehículos
//   - showManagementButtons: Si es admin (muestra opciones de editar/eliminar)
//   - isRegularUser: Si es usuario normal (muestra link a cotizar)
function cargarProductos(fetchUrl, showManagementButtons, isRegularUser) {
  // Obtiene el contenedor HTML donde se mostrarán los vehículos (#car-list)
  const contenedor = document.getElementById("car-list")

  // Valida que el contenedor exista antes de manipularlo
  if (!contenedor) return

  // Muestra mensaje de carga mientras se obtienen los datos del servidor
  contenedor.innerHTML = '<p class="loading-indicator">Cargando autos de lujo... 🏎️</p>'

  // Realiza petición fetch GET a la URL proporcionada
  // El endpoint debe devolver JSON con array de vehículos
  fetch(fetchUrl)
    // Convierte la respuesta HTTP a objeto JSON
    // .json() retorna una promesa que se resuelve al objeto parseado
    .then((res) => res.json())
    // Maneja los datos JSON recibidos
    .then((data) => {
      // Verifica si hay error en respuesta O si la respuesta no es un array válido
      if (data.error || !Array.isArray(data)) {
        // Muestra mensaje de error en el contenedor
        contenedor.innerHTML = `<p class="error-message">${data.error || "Error al cargar datos."}</p>`
        // Termina la función para evitar más procesamiento
        return
      }

      // Si no hay vehículos en la respuesta (array vacío)
      if (data.length === 0) {
        // Muestra mensaje informando que no hay vehículos
        contenedor.innerHTML = '<p class="no-cars-message">No hay vehículos en el catálogo.</p>'
        // Termina la función
        return
      }

      // Limpia el contenedor anterior (remueve el mensaje de carga)
      contenedor.innerHTML = ""

      // Crea un DocumentFragment para optimizar inserción al DOM
      // Permite agregar múltiples elementos al DOM de una sola vez
      // Esto es más eficiente que agregar elemento por elemento
      const fragment = document.createDocumentFragment()

      // Itera sobre cada vehículo en el array recibido del servidor
      data.forEach((car) => {
        // Crea un nuevo div para cada vehículo
        const div = document.createElement("div")

        // Añade la clase CSS "car" para aplicar estilos (grid, padding, bordes, etc)
        div.classList.add("car")

        // Almacena todos los datos del vehículo en JSON dentro de un atributo data-car-data
        // Permite acceder a los datos sin hacer peticiones adicionales al servidor
        div.dataset.carData = JSON.stringify(car)

        // Inicializa string que contendrá los botones de acción (editar/eliminar)
        let actionButtons = ""

        // Si es admin (showManagementButtons === true), construye botones de admin
        if (showManagementButtons) {
          // Crea botones con el ID del vehículo en atributos data-id
          // Los listeners se configurarán después en configurarListenersCatalogo()
          actionButtons = `
            <button class="btn btn-edit editar" data-id="${car.id}">Editar</button>
            <button class="btn btn-danger eliminar" data-id="${car.id}">Eliminar</button>
          `
        }

        // Formatea el precio en formato de moneda colombiana
        // toLocaleString('es-CO') da formato con punto separador de miles
        // No mostrar decimales porque los precios son números enteros
        const precioFormateado = Number.parseFloat(car.precio).toLocaleString("es-CO", {
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        })

        // Construye el HTML completo del vehículo con todos sus datos
        div.innerHTML = `
          ${car.imagen ? `<img src="uploads/${car.imagen}" alt="${car.modelo}" style="object-fit: contain; height: 280px;">` : ""}
          <div>
            <h3>${car.modelo}</h3>
            <p><strong>Precio:</strong> $${precioFormateado}</p>
            <p><strong>Estado:</strong> ${car.estado}</p>
            <p><strong>Vendedor:</strong> ${car.vendedor_nombre || "N/A"}</p>
            
            <button class="btn ver-desc">Ver descripción</button>
            <p class="descripcion" style="display:none; margin-top:10px;">${car.descripcion || "No disponible."}</p>
            
            <div class="action-buttons" style="margin-top: 15px;">
              ${actionButtons}
            </div>

            ${isRegularUser ? '<p style="font-size: 0.9em; margin-top: 15px;">¿Interesado? <a href="cotizar.php">¡Cotiza aquí!</a></p>' : ""}
          </div>
        `

        // Añade el div del vehículo al fragmento (no al DOM aún)
        fragment.appendChild(div)
      })

      // Inserta todo el fragmento al contenedor de una sola vez
      // Esto es más eficiente que insertar elemento por elemento
      contenedor.appendChild(fragment)

      // Ahora que los elementos están en el DOM, configura sus event listeners
      // Llama la función que configura botones (ver descripción, editar, eliminar, etc)
      configurarListenersCatalogo(showManagementButtons, fetchUrl, isRegularUser)
    })
    // Maneja errores de conexión o parsing JSON
    .catch((err) => {
      console.error("Error cargando productos:", err)
      // Muestra mensaje de error en el contenedor
      contenedor.innerHTML = `<p class="error-message">Error de conexión al cargar el catálogo.</p>`
    })
}

// FUNCIÓN: initAdminModalLogic
// Propósito: Configurar modal de edición de vehículos (cerrar, enviar, validar)
// Interactúa con: Modal #edit-modal, formulario #edit-modal-form, API backend
// Parámetros:
//   - fetchUrlParaRecargar: URL para recargar catálogo después de editar
//   - esAdmin: Boolean que indica si estamos en contexto admin
function initAdminModalLogic(fetchUrlParaRecargar, esAdmin) {
  // Obtiene el elemento del modal completo
  const editModal = document.getElementById("edit-modal")

  // Obtiene el botón X para cerrar el modal
  const editModalCloseBtn = document.getElementById("edit-modal-close")

  // Obtiene el formulario dentro del modal
  const editForm = document.getElementById("edit-modal-form")

  // Valida que todos los elementos existan (seguridad)
  if (!editModal || !editModalCloseBtn || !editForm) return

  // ═══ Listener: Cerrar modal al hacer clic en botón X ═══
  editModalCloseBtn.addEventListener("click", () => {
    // Remueve la clase "show" que hace visible el modal
    // CSS complementario hará display: none, opacity: 0, etc
    editModal.classList.remove("show")
  })

  // ═══ Listener: Cerrar modal al hacer clic fuera del contenido ═══
  // Mejora UX: permite cerrar modal clickeando el fondo oscuro
  editModal.addEventListener("click", (e) => {
    // Verifica si el click fue exactamente en el overlay (no en el contenido)
    // e.target es el elemento donde ocurrió el click
    if (e.target === editModal) {
      // Cierra el modal removiendo la clase "show"
      editModal.classList.remove("show")
    }
  })

  // ═══ Listener: Envío del formulario de edición ═══
  editForm.addEventListener("submit", function (e) {
    // Previene el envío por defecto del formulario (POST/recarga)
    // Usaremos fetch para mantener la experiencia SPA (sin recargar página)
    e.preventDefault()

    // Crea objeto FormData con todos los campos del formulario
    // Incluye archivos, inputs de texto, selects, textareas, etc
    // FormData es el formato correcto para enviar archivos por fetch
    const formData = new FormData(this)

    // Realiza petición fetch POST al servidor
    fetch("php/gestionar_vehiculos.php", {
      method: "POST",
      body: formData,
    })
      // Maneja la respuesta del servidor
      .then((response) => {
        // Verifica si la respuesta HTTP fue exitosa (status 200-299)
        if (response.ok) {
          // Muestra notificación de éxito al usuario
          mostrarNotificacion("Vehículo actualizado con éxito.", false)

          // Oculta el modal removiendo la clase "show"
          editModal.classList.remove("show")

          // Recarga la lista de productos para mostrar los cambios
          cargarProductos(fetchUrlParaRecargar, esAdmin, false)
        } else {
          // Si la respuesta no fue exitosa (400, 500, etc)
          // Muestra mensaje de error
          mostrarNotificacion("Error al actualizar el vehículo.", true)
        }
      })
      // Maneja errores de conexión o excepciones JavaScript
      .catch((err) => {
        mostrarNotificacion("Error de conexión al actualizar.", true)
        console.error("Error en fetch (updateCar):", err)
      })
  })
}

// FUNCIÓN: initTabs
// Propósito: Implementar sistema de pestañas/tabs (cambiar secciones sin recargar)
// Interactúa con: HTML (.tab-button .tab-content), URL (parámetro ?tab=)
// Parámetros:
//   - onTabChange: Función callback opcional que se ejecuta cuando cambia de pestaña
function initTabs(onTabChange) {
  // Obtiene el contenedor que alberga todos los botones de pestaña
  const tabContainer = document.querySelector(".tab-navigation")

  // Si no existe, termina la función (la página no tiene tabs)
  if (!tabContainer) return

  // Obtiene todos los botones de las pestañas
  const tabButtons = tabContainer.querySelectorAll(".tab-button")

  // Obtiene todos los contenidos de las pestañas
  const tabContents = document.querySelectorAll(".tab-content")

  // Itera sobre cada botón de pestaña para agregar listeners
  tabButtons.forEach((button) => {
    // Al hacer clic en un botón de pestaña
    button.addEventListener("click", () => {
      // Obtiene el ID de la pestaña a mostrar (del atributo data-tab)
      // Ej: data-tab="datos" → targetTabId = "datos"
      const targetTabId = button.getAttribute("data-tab")

      // Oculta todas las pestañas removiendo la clase "active"
      tabContents.forEach((content) => content.classList.remove("active"))

      // Desactiva todos los botones removiendo la clase "active"
      tabButtons.forEach((btn) => btn.classList.remove("active"))

      // Obtiene el elemento de contenido de la pestaña destino
      const targetContent = document.getElementById(targetTabId)

      // Si el contenido existe, lo hace visible añadiendo la clase "active"
      if (targetContent) {
        targetContent.classList.add("active")
      }

      // Activa el botón clickeado añadiendo la clase "active"
      button.classList.add("active")

      // Si se proporcionó un callback, lo ejecuta pasando el ID de la pestaña
      // Esto permite que funciones externas sepan qué pestaña se abrió
      if (typeof onTabChange === "function") {
        onTabChange(targetTabId)
      }
    })
  })

  // ═══ Detectar pestaña inicial desde la URL ═══
  // Permite URLs como: perfil.php?tab=cotizaciones

  // Obtiene los parámetros de la URL actual
  const urlParams = new URLSearchParams(window.location.search)

  // Obtiene el valor del parámetro "tab" si existe en la URL
  const tabFromUrl = urlParams.get("tab")

  // Si hay una pestaña especificada en la URL
  if (tabFromUrl) {
    // Busca el botón que corresponde a esa pestaña
    const buttonToClick = tabContainer.querySelector(`[data-tab="${tabFromUrl}"]`)

    // Si el botón existe, simula un click en él
    if (buttonToClick) {
      buttonToClick.click()
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// PUNTO DE ENTRADA: Ejecuta initNavbar cuando el DOM está completamente cargado
// ═════════════════════════════════════════════════════════════════════════════

// Espera a que el evento DOMContentLoaded se dispare (cuando se carga el HTML)
document.addEventListener("DOMContentLoaded", initNavbar)
