<?php
// Define el nombre del servidor donde está alojada la base de datos.
// En este caso, 'localhost' indica que la base de datos está en la misma máquina.
$host = "localhost";

// Define el nombre de usuario con el que se accederá a la base de datos.
// Por defecto, en XAMPP o entornos locales, suele ser 'root'.
$user = "root";

// Define la contraseña del usuario de la base de datos.
// En entornos locales normalmente está vacía ("").
$pass = "";

// Define el nombre de la base de datos a la que se desea conectar.
// En este caso, la base se llama 'infinity_motors'.
$db   = "infinity_motors";

// Crea un nuevo objeto de conexión usando la clase mysqli (MySQL mejorado).
// Se le pasan los parámetros: servidor, usuario, contraseña y nombre de la base de datos.
$conn = new mysqli($host, $user, $pass, $db);

// Verifica si ocurrió un error al intentar conectarse a la base de datos.
// La propiedad 'connect_error' devuelve el mensaje de error si falla la conexión.
if ($conn->connect_error) {
    // Si hay error, el programa se detiene (die) y muestra el mensaje de error.
    die("Error de conexión: " . $conn->connect_error);
}

// Configura el conjunto de caracteres de la conexión a UTF-8 extendido (utf8mb4).
// Esto asegura que se manejen correctamente caracteres especiales y emojis.
$conn->set_charset("utf8mb4");
?>
