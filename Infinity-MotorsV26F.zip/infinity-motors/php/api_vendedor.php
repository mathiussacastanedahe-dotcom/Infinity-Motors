<?php
// Inicia la sesión para acceder a datos del usuario autenticado
session_start();

// Incluye la conexión a la base de datos
require_once "conexion.php";

// Configura que las respuestas sean en formato JSON
header('Content-Type: application/json');

// Inicializa la estructura base de respuesta JSON (éxito=false, mensaje genérico)
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];

// Verifica que exista sesión activa, si no redirige con error
if (!isset($_SESSION['user'])) {
    $response['message'] = 'Acceso no válido. Inicia sesión.';
    echo json_encode($response);
    exit;
}

// Obtiene el ID del usuario actual desde la sesión
$user_id = (int)$_SESSION['user']['id'];

// Obtiene el rol del usuario (vendedor, usuario, admin, etc.)
$user_rol = $_SESSION['user']['rol'] ?? 'usuario';

// Obtiene la acción solicitada (puede venir por GET o POST)
$action = $_REQUEST['action'] ?? '';

// Estructura principal que ejecuta la lógica según la acción
switch ($action) {

    // === ACCIÓN: Obtener autos disponibles del vendedor ===
    case 'getAvailableCars':
        // Verifica que sea vendedor o administrador
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') {
            $response['message'] = 'Solo los vendedores pueden ver esta información.';
            break;
        }

        // Consulta los autos disponibles asignados a este vendedor
        $sql = "SELECT id, modelo, precio 
                FROM autos 
                WHERE estado = 'disponible' AND vendedor_id = ? 
                ORDER BY modelo ASC";
        
        // Prepara la consulta
        $stmt = $conn->prepare($sql);
        
        // Vincula el ID del vendedor
        $stmt->bind_param("i", $user_id);
        
        // Ejecuta la consulta
        $stmt->execute();
        
        // Obtiene los resultados como array asociativo
        $cars = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement
        $stmt->close();

        // Actualiza la respuesta con éxito y los datos de autos
        $response['success'] = true;
        $response['cars'] = $cars;
        break;

    // === ACCIÓN: Registrar una nueva venta ===
    case 'registerSale':
        // Verifica que sea vendedor o administrador
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') {
            $response['message'] = 'Solo los vendedores pueden registrar ventas.';
            break;
        }

        // Obtiene el ID del auto vendido
        $car_id = (int)($_POST['car_id'] ?? 0);
        
        // Obtiene el nombre del cliente
        $cliente_nombre = trim($_POST['cliente_nombre'] ?? '');
        
        // Obtiene el email del cliente
        $cliente_email = trim($_POST['cliente_email'] ?? '');
        
        // Obtiene la fecha de venta
        $fecha_venta = trim($_POST['fecha_venta'] ?? '');
        
        // Obtiene el monto final de la venta
        $monto_final = (float)($_POST['monto_final'] ?? 0);

        // Valida que todos los datos obligatorios estén presentes
        if (!$car_id || !$cliente_nombre || !$fecha_venta || !$monto_final) {
            $response['message'] = 'Faltan datos obligatorios.';
            break;
        }

        // Inicia una transacción para asegurar integridad
        $conn->begin_transaction();
        
        try {
            // Inserta la venta en la tabla ventas
            $sql_insert = "INSERT INTO ventas (car_id, vendedor_id, cliente_nombre, cliente_email, monto_final, fecha_venta)
                           VALUES (?, ?, ?, ?, ?, ?)";
            
            // Prepara el statement
            $stmt_insert = $conn->prepare($sql_insert);
            
            // Vincula los parámetros: i=integer(car_id), i=integer(vendedor_id), s=string(cliente), s=string(email), d=double(monto), s=string(fecha)
            $stmt_insert->bind_param("iissds", $car_id, $user_id, $cliente_nombre, $cliente_email, $monto_final, $fecha_venta);
            
            // Ejecuta la inserción
            $stmt_insert->execute();
            
            // Cierra el statement
            $stmt_insert->close();

            // Actualiza el estado del auto vendido
            $sql_update = "UPDATE autos SET estado = 'vendido' WHERE id = ?";
            
            // Prepara el statement
            $stmt_update = $conn->prepare($sql_update);
            
            // Vincula el ID del auto
            $stmt_update->bind_param("i", $car_id);
            
            // Ejecuta la actualización
            $stmt_update->execute();
            
            // Cierra el statement
            $stmt_update->close();

            // Confirma la transacción (todos los cambios se guardan)
            $conn->commit();

            // Actualiza la respuesta con éxito
            $response['success'] = true;
            $response['message'] = 'Venta registrada y auto actualizado.';
        } catch (Exception $e) {
            // Si hay error, revierte todos los cambios
            $conn->rollback();
            $response['message'] = 'Error en la transacción: ' . $e->getMessage();
        }
        break;

    // === ACCIÓN: Obtener historial de ventas ===
    case 'getSalesHistory':
        // Verifica que sea vendedor o administrador
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') {
            $response['message'] = 'Solo los vendedores pueden ver el historial.';
            break;
        }

        // Consulta todas las ventas del vendedor actual
        $sql = "SELECT v.id, a.modelo AS vehiculo_modelo, v.cliente_nombre, v.cliente_email, v.fecha_venta, v.monto_final 
                FROM ventas v
                JOIN autos a ON v.car_id = a.id
                WHERE v.vendedor_id = ?
                ORDER BY v.fecha_venta DESC";
        
        // Prepara la consulta
        $stmt = $conn->prepare($sql);
        
        // Vincula el ID del vendedor
        $stmt->bind_param("i", $user_id);
        
        // Ejecuta
        $stmt->execute();
        
        // Obtiene los resultados
        $sales = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement
        $stmt->close();

        // Devuelve el historial en la respuesta
        $response['success'] = true;
        $response['sales'] = $sales;
        break;

    // === ACCIÓN: Obtener cotizaciones recibidas (para vendedores) ===
    case 'getCotizacionesRecibidas':
        // Verifica que sea vendedor o administrador
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') {
            $response['message'] = 'Solo los vendedores pueden ver cotizaciones recibidas.';
            break;
        }

        // Consulta las solicitudes/cotizaciones enviadas a este vendedor
        $sql = "SELECT s.*, u.nombre AS cliente_nombre, u.email AS cliente_email 
                FROM solicitudes s
                JOIN usuarios u ON s.cliente_id = u.id
                WHERE s.vendedor_id = ?
                ORDER BY s.fecha DESC";
        
        // Prepara la consulta
        $stmt = $conn->prepare($sql);
        
        // Vincula el ID del vendedor
        $stmt->bind_param("i", $user_id);
        
        // Ejecuta
        $stmt->execute();
        
        // Obtiene las cotizaciones
        $cotizaciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement
        $stmt->close();

        // Devuelve los datos en la respuesta
        $response['success'] = true;
        $response['data'] = $cotizaciones;
        break;

    // === ACCIÓN: Obtener cotizaciones del cliente ===
    case 'getMisCotizaciones':
        // Verifica que sea usuario normal
        if ($user_rol !== 'user' && $user_rol !== 'usuario') {
            $response['message'] = 'Acción no permitida para este rol.';
            break;
        }

        // Consulta las solicitudes realizadas por el cliente actual
        $sql = "SELECT s.*, a.modelo AS vehiculo_modelo 
                FROM solicitudes s
                LEFT JOIN autos a ON s.vehiculo_id = a.id
                WHERE s.cliente_id = ? 
                ORDER BY s.fecha DESC";
        
        // Prepara la consulta
        $stmt = $conn->prepare($sql);
        
        // Vincula el ID del cliente
        $stmt->bind_param("i", $user_id);
        
        // Ejecuta
        $stmt->execute();
        
        // Obtiene las cotizaciones
        $cotizaciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement
        $stmt->close();

        // Devuelve los datos
        $response['success'] = true;
        $response['data'] = $cotizaciones;
        break;

    // === ACCIÓN: Obtener mensajes del chat ===
    case 'getChatMessages':
        // Obtiene el ID de la cotización/solicitud
        $cotizacion_id = (int)($_REQUEST['cotizacion_id'] ?? 0);
        
        // Si no hay ID válido, termina
        if (!$cotizacion_id) break;

        // Consulta los mensajes del chat de esa cotización
        $sql = "SELECT m.*, u.nombre AS remitente_nombre, u.email AS remitente_email 
                FROM chat_mensajes m
                JOIN usuarios u ON m.remitente_id = u.id
                LEFT JOIN solicitudes s ON m.solicitud_id = s.id
                WHERE m.solicitud_id = ? 
                AND (s.cliente_id = ? OR s.vendedor_id = ?)
                ORDER BY m.fecha ASC";
        
        // Prepara la consulta
        $stmt = $conn->prepare($sql);
        
        // Vincula: cotizacion_id, user_id (cliente), user_id (vendedor)
        $stmt->bind_param("iii", $cotizacion_id, $user_id, $user_id);
        
        // Ejecuta
        $stmt->execute();
        
        // Obtiene los mensajes
        $messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement
        $stmt->close();

        // Devuelve los mensajes
        $response['success'] = true;
        $response['data'] = $messages;
        break;

    // === ACCIÓN: Enviar mensaje al chat ===
    case 'sendChatMessage':
        // Obtiene el ID de la cotización
        $cotizacion_id = (int)($_POST['cotizacion_id'] ?? 0);
        
        // Obtiene y limpia el mensaje
        $mensaje = trim($_POST['mensaje'] ?? '');

        // Valida que los datos sean válidos
        if (!$cotizacion_id || !$mensaje) {
            $response['message'] = 'Faltan datos.';
            break;
        }

        // Verifica que el usuario pertenezca a ese chat (cliente o vendedor)
        $stmt_check = $conn->prepare("SELECT id FROM solicitudes WHERE id = ? AND (cliente_id = ? OR vendedor_id = ?)");
        
        // Vincula los parámetros
        $stmt_check->bind_param("iii", $cotizacion_id, $user_id, $user_id);
        
        // Ejecuta
        $stmt_check->execute();
        
        // Almacena el resultado en memoria
        $stmt_check->store_result();
        
        // Si no es cliente ni vendedor, deniega acceso
        if ($stmt_check->num_rows == 0) {
            $response['message'] = 'Acceso denegado a este chat.';
            $stmt_check->close();
            break;
        }
        
        // Cierra el statement
        $stmt_check->close();

        // Determina si el remitente es vendedor o cliente
        $remitente_rol = ($user_rol === 'vendedor' || $user_rol === 'admin') ? 'vendedor' : 'cliente';

        // Inserta el mensaje en la base de datos
        $sql = "INSERT INTO chat_mensajes (solicitud_id, remitente_id, remitente_rol, mensaje) 
                VALUES (?, ?, ?, ?)";
        
        // Prepara el statement
        $stmt = $conn->prepare($sql);
        
        // Vincula: cotizacion_id (integer), remitente_id (integer), remitente_rol (string), mensaje (string)
        $stmt->bind_param("iiss", $cotizacion_id, $user_id, $remitente_rol, $mensaje);

        // Intenta insertar el mensaje
        if ($stmt->execute()) {
            // Si fue exitoso, marca la respuesta como exitosa
            $response['success'] = true;
        } else {
            // Si hay error, lo reporta
            $response['message'] = 'Error al enviar mensaje.';
        }
        
        // Cierra el statement
        $stmt->close();
        break;

    // === ACCIÓN: Crear una nueva cotización ===
    case 'crearCotizacion':
        // Verifica que sea usuario normal
        if ($user_rol !== 'user' && $user_rol !== 'usuario') {
            $response['message'] = 'Acción no permitida para este rol.';
            break;
        }

        // Obtiene el ID del vendedor
        $vendedor_id = (int)($_POST['vendedor_id'] ?? 0);
        
        // Obtiene el ID del vehículo (opcional)
        $vehiculo_id = (int)($_POST['vehiculo_id'] ?? 0);
        
        // Obtiene el asunto de la cotización
        $asunto = trim($_POST['asunto'] ?? '');
        
        // Obtiene el mensaje inicial
        $mensaje = trim($_POST['mensaje'] ?? '');
        
        // Asigna el ID del cliente actual
        $cliente_id = $user_id;

        // Valida que al menos vendedor, asunto y mensaje estén presentes
        if (!$vendedor_id || !$asunto || !$mensaje) {
            $response['message'] = 'Faltan datos (vendedor, asunto y mensaje son obligatorios).';
            break;
        }

        // Si el vehiculo_id es 0, lo convierte a null para la base de datos
        $vehiculo_id_sql = ($vehiculo_id === 0) ? null : $vehiculo_id;

        // Inicia una transacción
        $conn->begin_transaction();
        
        try {
            // Inserta la solicitud de cotización
            $sql_solicitud = "INSERT INTO solicitudes (cliente_id, vendedor_id, vehiculo_id, asunto)
                              VALUES (?, ?, ?, ?)";
            
            // Prepara el statement
            $stmt_sol = $conn->prepare($sql_solicitud);
            
            // Vincula: cliente_id, vendedor_id, vehiculo_id, asunto
            $stmt_sol->bind_param("iiis", $cliente_id, $vendedor_id, $vehiculo_id_sql, $asunto);
            
            // Ejecuta la inserción
            $stmt_sol->execute();

            // Obtiene el ID de la solicitud creada
            $solicitud_id = $stmt_sol->insert_id;
            
            // Cierra el statement
            $stmt_sol->close();

            // Inserta el primer mensaje del cliente en el chat
            $sql_chat = "INSERT INTO chat_mensajes (solicitud_id, remitente_id, remitente_rol, mensaje)
                         VALUES (?, ?, 'cliente', ?)";
            
            // Prepara el statement
            $stmt_chat = $conn->prepare($sql_chat);
            
            // Vincula: solicitud_id, cliente_id, mensaje
            $stmt_chat->bind_param("iis", $solicitud_id, $cliente_id, $mensaje);
            
            // Ejecuta la inserción
            $stmt_chat->execute();
            
            // Cierra el statement
            $stmt_chat->close();

            // Confirma la transacción (todos los cambios se guardan)
            $conn->commit();

            // Actualiza la respuesta con éxito
            $response['success'] = true;
            $response['message'] = 'Cotización enviada. Revisa tu perfil para ver el chat.';
        } catch (Exception $e) {
            // Si hay error, revierte los cambios
            $conn->rollback();
            $response['message'] = 'Error al crear la solicitud: ' . $e->getMessage();
        }
        break;

    // === ACCIÓN: Eliminar cotización ===
    case 'deleteCotizacion':
        // Verifica que sea vendedor o administrador
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') {
            $response['message'] = 'Solo los vendedores pueden eliminar cotizaciones.';
            break;
        }

        // Obtiene el ID de la cotización a eliminar
        $cotizacion_id = (int)($_POST['cotizacion_id'] ?? 0);
        
        // Valida que el ID sea válido
        if (!$cotizacion_id) {
            $response['message'] = 'ID de cotización no válido.';
            break;
        }

        // Verifica que la cotización pertenezca a este vendedor
        $stmt_check = $conn->prepare("SELECT id FROM solicitudes WHERE id = ? AND vendedor_id = ?");
        
        // Vincula: cotizacion_id, user_id del vendedor
        $stmt_check->bind_param("ii", $cotizacion_id, $user_id);
        
        // Ejecuta
        $stmt_check->execute();
        
        // Almacena el resultado
        $stmt_check->store_result();
        
        // Si no encuentra la cotización, deniega
        if ($stmt_check->num_rows == 0) {
            $response['message'] = 'No tienes permiso para eliminar esta cotización.';
            $stmt_check->close();
            break;
        }
        
        // Cierra el statement
        $stmt_check->close();

        // Inicia transacción para eliminar todo atomicamente
        $conn->begin_transaction();
        
        try {
            // Elimina los mensajes del chat de esa cotización
            $sql_delete_messages = "DELETE FROM chat_mensajes WHERE solicitud_id = ?";
            
            // Prepara y ejecuta
            $stmt_messages = $conn->prepare($sql_delete_messages);
            $stmt_messages->bind_param("i", $cotizacion_id);
            $stmt_messages->execute();
            $stmt_messages->close();

            // Elimina la cotización (solicitud)
            $sql_delete_cotizacion = "DELETE FROM solicitudes WHERE id = ?";
            
            // Prepara y ejecuta
            $stmt_cotizacion = $conn->prepare($sql_delete_cotizacion);
            $stmt_cotizacion->bind_param("i", $cotizacion_id);
            $stmt_cotizacion->execute();
            $stmt_cotizacion->close();

            // Confirma la transacción
            $conn->commit();
            
            // Marca como exitoso
            $response['success'] = true;
            $response['message'] = 'Cotización eliminada exitosamente.';
        } catch (Exception $e) {
            // Si hay error, revierte todo
            $conn->rollback();
            $response['message'] = 'Error al eliminar la cotización: ' . $e->getMessage();
        }
        break;

    // === ACCIÓN DESCONOCIDA ===
    default:
        // Si la acción no existe o no es reconocida
        $response['message'] = 'Acción desconocida: ' . htmlspecialchars($action);
        break;
}

// Cierra la conexión con la base de datos
$conn->close();

// Envía la respuesta final en formato JSON
echo json_encode($response);
?>
