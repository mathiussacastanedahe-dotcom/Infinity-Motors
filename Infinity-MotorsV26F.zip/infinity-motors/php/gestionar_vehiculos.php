<?php
// Inicia la sesión para acceder a datos del usuario autenticado almacenados en $_SESSION
session_start();

// Importa la conexión a la base de datos desde el archivo conexion.php
require_once "conexion.php"; 

// Obtiene la acción solicitada desde GET o POST (getCarsCatalogo, addCar, updateCar, etc.)
$action = $_REQUEST['action'] ?? '';

// Obtiene el ID del usuario actual desde la sesión (si no existe, asigna 0)
$user_id = $_SESSION['user']['id'] ?? 0;

// Obtiene el rol del usuario actual desde la sesión (si no existe, asigna 'guest')
$user_rol = $_SESSION['user']['rol'] ?? 'guest';

// === FUNCIÓN: Enviar respuesta en formato JSON ===
function jsonResponse($data) {
    // Configura el header para indicar que la respuesta es JSON
    header('Content-Type: application/json');
    
    // Convierte el array PHP a formato JSON y lo envía al cliente
    echo json_encode($data);
    
    // Detiene la ejecución del script
    exit;
}

// === FUNCIÓN: Redirigir con mensaje (éxito o error) ===
function redirect($url, $message, $isError = false) {
    // Elige el parámetro: 'error' si es error, 'msg' si es éxito
    $param = $isError ? 'error' : 'msg';
    
    // Construye la URL con el parámetro y mensaje usando http_build_query
    header("Location: $url?" . http_build_query([$param => $message]));
    
    // Detiene la ejecución del script
    exit;
}

// === FUNCIÓN: Enviar respuesta en texto plano ===
function textResponse($message, $isError = false) {
    // Configura el header para indicar que la respuesta es texto plano
    header('Content-Type: text/plain');
    
    // Si es error, establece el código HTTP 500
    if ($isError) http_response_code(500);
    
    // Envía el mensaje al cliente
    echo $message;
    
    // Detiene la ejecución del script
    exit;
}

// Estructura principal que ejecuta diferentes acciones según lo solicitado
switch ($action) {

    // === ACCIÓN: Obtener vehículos disponibles (catálogo público) ===
    case 'getCarsCatalogo':
        // Prepara una consulta SQL que trae todos los autos disponibles con el nombre del vendedor
        $sql = "SELECT 
                    autos.*, 
                    usuarios.nombre AS vendedor_nombre 
                FROM autos 
                LEFT JOIN usuarios ON autos.vendedor_id = usuarios.id
                WHERE autos.estado = 'disponible'
                ORDER BY autos.id DESC";
        
        // Ejecuta la consulta en la base de datos
        $result = $conn->query($sql);
        
        // Convierte el resultado a un array asociativo (cada fila es un array)
        $autos = $result->fetch_all(MYSQLI_ASSOC);
        
        // Devuelve los autos en formato JSON al cliente
        jsonResponse($autos);
        break;

    // === ACCIÓN: Obtener vehículos de un vendedor específico (para cotizar) ===
    case 'getCarsByVendedor':
        // Obtiene el ID del vendedor de la URL
        $vendedor_id = (int)($_GET['vendedor_id'] ?? 0);
        
        // Si no se proporcionó un ID válido, devuelve un array vacío
        if ($vendedor_id === 0) {
            jsonResponse([]);
            break;
        }

        // Prepara una consulta SQL segura contra inyección SQL
        $sql = "SELECT id, modelo, precio 
                FROM autos 
                WHERE estado = 'disponible' AND vendedor_id = ?
                ORDER BY modelo ASC";
        
        // Prepara el statement
        $stmt = $conn->prepare($sql);
        
        // Vincula el ID del vendedor como parámetro (i = integer)
        $stmt->bind_param("i", $vendedor_id);
        
        // Ejecuta la consulta
        $stmt->execute();
        
        // Obtiene el resultado
        $result = $stmt->get_result();
        
        // Convierte a array asociativo
        $autos = $result->fetch_all(MYSQLI_ASSOC);
        
        // Cierra el statement para liberar recursos
        $stmt->close();

        // Devuelve los autos disponibles del vendedor en JSON
        jsonResponse($autos);
        break;

    // === ACCIÓN: Obtener todos los vehículos (solo para administradores) ===
    case 'getCarsAdmin':
        // Verifica que el usuario sea administrador
        if ($user_rol !== 'admin') {
            jsonResponse(['error' => 'Acceso denegado']);
        }

        // Prepara una consulta SQL que trae todos los autos con información del vendedor
        $sql = "SELECT 
                    autos.*, 
                    usuarios.nombre AS vendedor_nombre 
                FROM autos 
                LEFT JOIN usuarios ON autos.vendedor_id = usuarios.id
                ORDER BY autos.id DESC";
        
        // Ejecuta la consulta
        $result = $conn->query($sql);
        
        // Convierte a array asociativo
        $autos = $result->fetch_all(MYSQLI_ASSOC);
        
        // Devuelve todos los autos en JSON
        jsonResponse($autos);
        break;

    // === ACCIÓN: Crear/Agregar un nuevo vehículo (solo admin) ===
    case 'addCar':
        // Verifica que el usuario sea administrador
        if ($user_rol !== 'admin') {
            redirect("../admin.php", "Acceso denegado", true);
        }

        // Obtiene los datos del formulario
        $modelo = $_POST['modelo'] ?? '';
        $precio = $_POST['precio'] ?? 0;
        $estado = $_POST['estado'] ?? 'disponible';
        $vendedor_id = (int)($_POST['vendedor_id'] ?? 0);
        $descripcion = $_POST['descripcion'] ?? '';
        $imagen_nombre = null;

        // Valida que se haya seleccionado un vendedor
        if ($vendedor_id === 0) {
            redirect("../admin.php", "Debe seleccionar un vendedor.", true);
        }
        
        // Valida que modelo y precio sean válidos
        if (empty($modelo) || $precio <= 0) {
            redirect("../admin.php", "Modelo y precio son obligatorios.", true);
        }

        // Si se subió una imagen, la procesa y guarda
        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            // Define la carpeta donde se guardarán las imágenes
            $dir_subidas = "../uploads/";

            // Crea la carpeta si no existe (con permisos 755)
            if (!is_dir($dir_subidas)) mkdir($dir_subidas, 0755, true);

            // Limpia el nombre del archivo de caracteres especiales
            $baseName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', basename($_FILES["imagen"]["name"]));
            
            // Agrega un timestamp al nombre para evitar conflictos de nombres duplicados
            $imagen_nombre = time() . "_" . $baseName;

            // Mueve el archivo del directorio temporal a la carpeta final
            move_uploaded_file($_FILES["imagen"]["tmp_name"], $dir_subidas . $imagen_nombre);
        }

        // Prepara la consulta para insertar el nuevo vehículo
        $sql = "INSERT INTO autos (modelo, precio, estado, vendedor_id, descripcion, imagen) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        // Prepara el statement
        $stmt = $conn->prepare($sql);
        
        // Vincula los parámetros: s=string, d=double (precio), i=integer, s=string (imagen)
        $stmt->bind_param("sdsiss", $modelo, $precio, $estado, $vendedor_id, $descripcion, $imagen_nombre);

        // Intenta insertar el nuevo vehículo
        if ($stmt->execute()) {
            // Si fue exitoso, redirige con mensaje de confirmación
            redirect("../admin.php", "Vehículo agregado con éxito");
        } else {
            // Si hay error, redirige con mensaje de error
            redirect("../admin.php", "Error al agregar vehículo: " . $stmt->error, true);
        }
        
        // Cierra el statement
        $stmt->close();
        break;

    // === ACCIÓN: Actualizar vehículo existente ===
    case 'updateCar':
        // Verifica que sea admin o vendedor
        if ($user_rol !== 'admin' && $user_rol !== 'vendedor') {
            redirect("../login.html", "Acceso denegado", true);
        }

        // Obtiene y valida el ID del vehículo
        $car_id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        
        // Obtiene y limpia el modelo
        $modelo = trim($_POST['modelo'] ?? '');
        
        // Obtiene y valida el precio
        $precio = filter_input(INPUT_POST, 'precio', FILTER_VALIDATE_FLOAT);
        
        // Obtiene el estado del vehículo
        $estado = trim($_POST['estado'] ?? '');
        
        // Obtiene y valida el ID del vendedor
        $vendedor_id = filter_input(INPUT_POST, 'vendedor_id', FILTER_VALIDATE_INT);
        
        // Obtiene la descripción
        $descripcion = trim($_POST['descripcion'] ?? '');
        
        // Inicializa el nombre de imagen como null
        $imgName = null;

        // Valida que todos los datos obligatorios sean válidos
        if (!$car_id || !$vendedor_id || empty($modelo) || $precio <= 0) {
            redirect("../admin.php", "Datos inválidos o faltantes.", true);
        }

        // Si hay una imagen nueva, la procesa
        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            // Define la carpeta de upload
            $uploadDir = "../uploads/";
            
            // Limpia el nombre del archivo
            $baseName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', basename($_FILES["imagen"]["name"]));
            
            // Agrega timestamp
            $imgName = time() . "_" . $baseName;
            
            // Establece la ruta final
            $target = $uploadDir . $imgName;
            
            // Mueve el archivo
            move_uploaded_file($_FILES['imagen']['tmp_name'], $target);
        }

        // Construye la consulta dependiendo de si hay imagen nueva
        if ($imgName) {
            // Consulta con actualización de imagen
            $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=?, imagen=? WHERE id=?";
            $tipos = "sdsissi";
            $params = [$modelo, $precio, $estado, $vendedor_id, $descripcion, $imgName, $car_id];
        } else {
            // Consulta sin actualización de imagen
            $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=? WHERE id=?";
            $tipos = "sdsisi";
            $params = [$modelo, $precio, $estado, $vendedor_id, $descripcion, $car_id];
        }

        // Si es vendedor, solo puede actualizar sus propios autos
        if ($user_rol === 'vendedor') {
            $sql .= " AND vendedor_id = ?";
            $tipos .= "i";
            $params[] = $user_id;
        }

        // Prepara el statement
        $stmt = $conn->prepare($sql);
        
        // Vincula los parámetros con sus tipos
        $stmt->bind_param($tipos, ...$params);
        
        // Ejecuta la actualización
        $stmt->execute();

        // Verifica si se actualizó alguna fila
        if ($stmt->affected_rows > 0) {
            // Redirige al panel correspondiente según el rol
            $redirect_url = ($user_rol === 'admin') ? '../admin.php' : '../vendedor.php';
            redirect($redirect_url, "Vehículo actualizado correctamente");
        } else {
            // Si no se actualizó, es porque no tiene permisos
            redirect("../admin.php", "No se actualizó el vehículo (posiblemente no tengas permisos sobre él).", true);
        }
        
        // Cierra el statement
        $stmt->close();
        break;

    // === ACCIÓN: Eliminar vehículo (solo admin) ===
    case 'deleteCar':
        // Verifica que sea administrador
        if ($user_rol !== 'admin') {
            textResponse("Acceso denegado.", true);
        }

        // Obtiene el ID del vehículo a eliminar
        $id = intval($_GET['id'] ?? 0);
        
        // Valida que el ID sea válido
        if ($id === 0) {
            textResponse("ID inválido", true);
        }

        // Inicia una transacción para asegurar que todas las operaciones se hagan o ninguna
        $conn->begin_transaction();
        
        try {
            // Busca la imagen del auto para eliminarlo del servidor
            $stmt_img = $conn->prepare("SELECT imagen FROM autos WHERE id = ?");
            
            // Vincula el ID
            $stmt_img->bind_param("i", $id);
            
            // Ejecuta
            $stmt_img->execute();
            
            // Obtiene el resultado
            $res = $stmt_img->get_result();
            
            // Si hay resultado, obtiene el nombre de la imagen
            if ($res && $res->num_rows > 0) {
                $row = $res->fetch_assoc();
                
                // Construye la ruta de la imagen
                $imagen = "../uploads/" . $row['imagen'];
                
                // Si la imagen existe, la elimina del servidor
                if ($row['imagen'] && file_exists($imagen)) {
                    unlink($imagen);
                }
            }
            
            // Cierra el statement
            $stmt_img->close();

            // Elimina registros de ventas relacionadas
            $stmt_ventas = $conn->prepare("DELETE FROM ventas WHERE car_id = ?");
            $stmt_ventas->bind_param("i", $id);
            $stmt_ventas->execute();
            $stmt_ventas->close();

            // Elimina registros de solicitudes (cotizaciones) relacionadas
            $stmt_solicitudes = $conn->prepare("DELETE FROM solicitudes WHERE vehiculo_id = ?");
            $stmt_solicitudes->bind_param("i", $id);
            $stmt_solicitudes->execute();
            $stmt_solicitudes->close();

            // Elimina mensajes de chat relacionados a esas solicitudes
            $stmt_chat = $conn->prepare("DELETE FROM chat_mensajes WHERE solicitud_id IN (SELECT id FROM solicitudes WHERE vehiculo_id = ?)");
            $stmt_chat->bind_param("i", $id);
            $stmt_chat->execute();
            $stmt_chat->close();

            // Finalmente elimina el vehículo
            $stmt_auto = $conn->prepare("DELETE FROM autos WHERE id = ?");
            $stmt_auto->bind_param("i", $id);
            $stmt_auto->execute();

            // Si se eliminó exitosamente, confirma la transacción
            if ($stmt_auto->affected_rows > 0) {
                $conn->commit();
                textResponse("Vehículo y registros asociados eliminados.");
            } else {
                // Si no se encontró, revierte
                $conn->rollback();
                textResponse("Error: No se encontró el vehículo.", true);
            }
            
            // Cierra el statement
            $stmt_auto->close();

        } catch (Exception $e) {
            // Si hay excepción, revierte toda la transacción
            $conn->rollback();
            textResponse("Error en la transacción: " . $e->getMessage(), true);
        }
        break;

    // === ACCIÓN DESCONOCIDA ===
    default:
        jsonResponse(['error' => 'Acción de vehículo no especificada.']);
        break;
}

// Cierra la conexión con la base de datos
$conn->close();
?>
