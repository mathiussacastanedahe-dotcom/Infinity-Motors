<?php
// Inicia la sesión para utilizar variables de $_SESSION que almacenan datos del usuario autenticado
session_start();

// Incluye el archivo de conexión que contiene el objeto $conn para acceder a la base de datos
require_once "conexion.php";

// Obtiene la acción solicitada del formulario POST (login, register, updateProfile, etc.)
$action = $_POST['action'] ?? '';

// Determina si la respuesta debe ser JSON (para peticiones AJAX) o redirección HTTP (para formularios HTML)
$is_json_response = in_array($action, ['updateProfile', 'updateRole']);

// Si la acción requiere respuesta JSON, configura el header para que el navegador lo interprete como JSON
if ($is_json_response) {
    header('Content-Type: application/json');
}

// Estructura de control que ejecuta la lógica según la acción recibida
switch ($action) {

    // === CASO: AUTENTICACIÓN DE USUARIO (LOGIN) ===
    case 'login':
        // Obtiene y limpia el email del formulario, eliminando espacios en blanco
        $email = trim($_POST['email'] ?? '');
        
        // Obtiene la contraseña del formulario sin procesar (se comparará con hash después)
        $password = $_POST['password'] ?? '';

        // Valida que el email tenga formato correcto (ejemplo@dominio.com)
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Si el formato es inválido, redirige con mensaje de error
            header("Location: ../login.html?error=" . urlencode("Formato de correo inválido"));
            exit();
        }

        // Prepara una consulta SQL segura contra inyección SQL usando parámetros vinculados
        $stmt = $conn->prepare("SELECT id, nombre, email, telefono, password, rol, fecha_registro FROM usuarios WHERE email = ?");
        
        // Vincula el email como parámetro string (s) para evitar inyección SQL
        $stmt->bind_param("s", $email);
        
        // Ejecuta la consulta con el email proporcionado
        $stmt->execute();
        
        // Obtiene el resultado de la búsqueda
        $result = $stmt->get_result();

        // Intenta traer un registro de la base de datos (fetch_assoc = resultado como array asociativo)
        if ($row = $result->fetch_assoc()) {
            
            // Valida que el rol del usuario sea válido (user, vendedor o admin)
            if (empty($row['rol']) || !in_array($row['rol'], ['user', 'vendedor', 'admin'])) {
                // Si el rol es inválido, la cuenta está corrupta
                header("Location: ../login.html?error=" . urlencode("Esta cuenta de usuario está corrupta (Rol inválido). Contacte a soporte."));
                exit();
            }

            // Compara la contraseña introducida con el hash almacenado en la base de datos
            if (password_verify($password, $row['password'])) {
                
                // Regenera el ID de sesión para prevenir ataques de fijación de sesión
                session_regenerate_id(true);

                // Almacena los datos del usuario en la sesión para que esté disponible durante toda su navegación
                $_SESSION['user'] = [
                    "id" => $row['id'],
                    "nombre" => $row['nombre'],
                    "email" => $row['email'],
                    "telefono" => $row['telefono'],
                    "fecha_registro" => $row['fecha_registro'],
                    "rol" => $row['rol']
                ];

                // Redirige según el rol: administradores a admin.php, vendedores a vendedor.php, usuarios normales a inicio.php
                if ($row['rol'] === 'admin') {
                    header("Location: ../admin.php?msg=" . urlencode("Bienvenido Administrador"));
                } elseif ($row['rol'] === 'vendedor') {
                    header("Location: ../vendedor.php?msg=" . urlencode("Bienvenido Vendedor"));
                } else {
                    header("Location: ../inicio.php?msg=" . urlencode("Bienvenido " . $row['nombre']));
                }
                exit();
            } else {
                // La contraseña no coincide con el hash, acceso denegado
                header("Location: ../login.html?error=" . urlencode("Contraseña incorrecta"));
                exit();
            }
        } else {
            // El email no existe en la base de datos
            header("Location: ../login.html?error=" . urlencode("Usuario no encontrado"));
            exit();
        }

    // === CASO: REGISTRO DE NUEVO USUARIO ===
    case 'register':
        // Obtiene y limpia el nombre del formulario, eliminando espacios en blanco
        $nombre   = trim($_POST['nombre'] ?? '');
        
        // Obtiene y limpia el email del formulario
        $email    = trim($_POST['email'] ?? '');
        
        // Obtiene y limpia el teléfono del formulario
        $telefono = trim($_POST['telefono'] ?? '');
        
        // Obtiene la contraseña del formulario (no se limpia para no alterar espacios intencionados)
        $password = $_POST['password'] ?? '';
        
        // Valida que ninguno de los campos obligatorios esté vacío
        if (empty($nombre) || empty($email) || empty($password) || empty($telefono)) {
            header("Location: ../register.html?error=" . urlencode("Todos los campos son obligatorios."));
            exit;
        }
        
        // Valida que el email tenga formato correcto
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            header("Location: ../register.html?error=" . urlencode("Formato de correo inválido."));
            exit;
        }
        
        // Valida que el nombre solo contenga letras y tenga mínimo 3 caracteres
        if (!preg_match('/^[a-zA-Z\sñÑáéíóúÁÉÍÓÚ]+$/', $nombre) || strlen($nombre) < 3) {
            header("Location: ../register.html?error=" . urlencode("El nombre solo debe contener letras y ser de al menos 3 caracteres."));
            exit;
        }
        
        // Valida que el teléfono tenga exactamente 10 dígitos numéricos
        if (!preg_match('/^\d{10}$/', $telefono)) {
            header("Location: ../register.html?error=" . urlencode("El teléfono debe tener 10 dígitos numéricos."));
            exit;
        }
        
        // Valida que la contraseña tenga mínimo 8 caracteres, al menos 1 mayúscula y 1 número
        if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
            header("Location: ../register.html?error=" . urlencode("La contraseña debe tener 8+ caracteres, 1 mayúscula y 1 número."));
            exit;
        }

        // Prepara una consulta para verificar si el email ya está registrado
        $sql_check = "SELECT id FROM usuarios WHERE email = ?";
        $stmt_check = $conn->prepare($sql_check);
        
        // Vincula el email como parámetro
        $stmt_check->bind_param("s", $email);
        
        // Ejecuta la búsqueda
        $stmt_check->execute();
        
        // Guarda el resultado en memoria para usar store_result()
        $stmt_check->store_result();

        // Si encuentra un registro, el email ya existe en la base de datos
        if ($stmt_check->num_rows > 0) {
            $stmt_check->close();
            header("Location: ../register.html?error=El correo ya está registrado");
            exit;
        }
        
        // Cierra el statement de verificación para liberar recursos
        $stmt_check->close();

        // Codifica la contraseña usando bcrypt para almacenarla de forma segura
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Asigna el rol por defecto "user" a todos los usuarios nuevos
        $rol_db = 'user'; 

        // Prepara la consulta para insertar el nuevo usuario
        $sql_insert = "INSERT INTO usuarios (nombre, email, telefono, password, rol) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        
        // Vincula los parámetros: 5 strings (s) para nombre, email, teléfono, password y rol
        $stmt_insert->bind_param("sssss", $nombre, $email, $telefono, $hash, $rol_db);

        // Intenta insertar el nuevo usuario en la base de datos
        if ($stmt_insert->execute()) {
            
            // Regenera el ID de sesión para el nuevo usuario
            session_regenerate_id(true);
            
            // Almacena los datos del usuario nuevo en la sesión para iniciar sesión automáticamente
            $_SESSION['user'] = [
                "id" => $stmt_insert->insert_id,
                "nombre" => $nombre,
                "email" => $email,
                "telefono" => $telefono,
                "rol" => $rol_db
            ];
            
            // Redirige a la página de inicio con mensaje de bienvenida
            header("Location: ../inicio.php?msg=" . urlencode("Registro exitoso, bienvenido $nombre"));
            exit();
        } else {
            // Registra el error en los logs del servidor para depuración
            error_log("Error en registro de BBDD: " . $stmt_insert->error);
            
            // Redirige al formulario de registro con mensaje de error
            header("Location: ../register.html?error=Error al registrarse en la base de datos.");
            exit();
        }
      
    // === CASO: ACTUALIZAR PERFIL DE USUARIO ===
    case 'updateProfile':
        // Inicializa la estructura de respuesta JSON que se devolverá al cliente
        $response = ['success' => false, 'message' => 'Error al actualizar.'];
        
        // Verifica que exista una sesión activa, si no el usuario no está autenticado
        if (!isset($_SESSION['user']['id'])) {
            $response['message'] = 'Usuario no autenticado.';
            echo json_encode($response);
            exit;
        }

        // Obtiene y valida el email proporcionado usando filter_input con FILTER_VALIDATE_EMAIL
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        
        // Obtiene y limpia el teléfono del formulario
        $telefono = trim($_POST['telefono'] ?? '');
        
        // Obtiene el ID del usuario actual desde la sesión
        $userId = $_SESSION['user']['id'];

        // Valida que el email tenga formato válido
        if (!$email) {
            $response['message'] = 'El formato del correo no es válido.';
            echo json_encode($response);
            exit;
        }
        
        // Valida que el teléfono tenga exactamente 10 dígitos
        if (!preg_match('/^\d{10}$/', $telefono)) {
            $response['message'] = 'El teléfono debe tener 10 dígitos.';
            echo json_encode($response);
            exit;
        }

        // Prepara una consulta para verificar si el email ya está en uso por otra cuenta
        $sql_check_email = "SELECT id FROM usuarios WHERE email = ? AND id != ?";
        $stmt_check = $conn->prepare($sql_check_email);
        
        // Vincula el email y el ID actual (el AND id != ? evita conflicto con su propio email)
        $stmt_check->bind_param("si", $email, $userId);
        
        // Ejecuta la búsqueda
        $stmt_check->execute();
        
        // Almacena el resultado en memoria
        $stmt_check->store_result();
        
        // Si encuentra un registro, otro usuario ya tiene ese email
        if ($stmt_check->num_rows > 0) {
            $response['message'] = 'El correo electrónico ya está en uso por otra cuenta.';
            echo json_encode($response);
            $stmt_check->close();
            exit;
        }
        
        // Cierra el statement de verificación
        $stmt_check->close();

        // Prepara la consulta para actualizar el email y teléfono del usuario
        $sql_update = "UPDATE usuarios SET email = ?, telefono = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        
        // Vincula los parámetros: 2 strings (email y teléfono) y 1 integer (ID)
        $stmt_update->bind_param("ssi", $email, $telefono, $userId);

        // Intenta ejecutar la actualización
        if ($stmt_update->execute()) {
            // Actualiza la sesión con los nuevos datos
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['telefono'] = $telefono;
            
            // Marca la respuesta como exitosa
            $response['success'] = true;
            $response['message'] = '¡Perfil actualizado!';
        } else {
            // Registra el error en los logs del servidor
            error_log("Error en updateProfile: " . $stmt_update->error);
            
            // Establece mensaje de error en la respuesta
            $response['message'] = 'Error al actualizar en la base de datos.';
        }
        
        // Cierra el statement
        $stmt_update->close();
        
        // Envía la respuesta como JSON al cliente
        echo json_encode($response);
        break;

    // === CASO: CAMBIAR ROL DE USUARIO (SOLO ADMIN) ===
    case 'updateRole':
        // Inicializa la estructura de respuesta JSON
        $response = ['success' => false, 'message' => ''];
        
        // Verifica que haya sesión activa y que el usuario sea administrador
        if (!isset($_SESSION['user']) || $_SESSION['user']['rol'] !== 'admin') {
            $response['message'] = "Acceso denegado. Se requiere ser Administrador.";
            echo json_encode($response);
            exit();
        }

        // Obtiene el ID del usuario al que se cambiará el rol
        $user_id = (int)$_POST['id'];
        
        // Obtiene y limpia el nuevo rol
        $new_role = trim($_POST['rol']);
        
        // Previene que el admin se quité el rol a sí mismo accidentalmente
        if ($user_id === (int)$_SESSION['user']['id']) {
            $response['message'] = "No puedes cambiar tu propio rol.";
            echo json_encode($response);
            exit();
        }
        
        // Define los roles válidos que existen en el sistema
        $allowed_roles = ['user', 'vendedor', 'admin']; 

        // Verifica que el rol proporcionado sea válido
        if (!in_array($new_role, $allowed_roles)) {
            $response['message'] = "Rol no válido: " . htmlspecialchars($new_role);
            echo json_encode($response);
            exit();
        }
        
        // Prepara la consulta para actualizar el rol del usuario
        $stmt_role = $conn->prepare("UPDATE usuarios SET rol = ? WHERE id = ?");
        
        // Vincula el nuevo rol (string) y el ID del usuario (integer)
        $stmt_role->bind_param("si", $new_role, $user_id);

        // Intenta ejecutar la actualización
        if ($stmt_role->execute()) {
            // Marca la respuesta como exitosa
            $response['success'] = true;
            $response['message'] = "Rol del usuario #{$user_id} actualizado.";
        } else {
            // Registra el error en los logs del servidor
            error_log("Error en updateRole: " . $stmt_role->error);
            
            // Establece mensaje de error en la respuesta
            $response['message'] = "Error al ejecutar la actualización: " . $stmt_role->error;
        }
        
        // Cierra el statement
        $stmt_role->close();
        
        // Envía la respuesta como JSON al cliente
        echo json_encode($response);
        break;

    // === ACCIÓN DESCONOCIDA ===
    default:
        // Si no es respuesta JSON, redirige a página de error
        if (!$is_json_response) {
            header("Location: ../index.html?error=AccionInvalida");
            exit();
        }
        
        // Si se esperaba JSON, devuelve error en formato JSON
        $response['message'] = 'Acción desconocida.';
        echo json_encode($response);
        break;
}

// Cierra la conexión con la base de datos para liberar recursos
$conn->close();
?>
