<?php

// Reanuda o inicia la sesión del usuario actualmente logueado
// La sesión contiene $_SESSION['user'] con los datos del usuario (id, nombre, email, rol, etc.)
// Sin esta línea, no podríamos acceder a $_SESSION en los siguientes pasos
session_start();

// Elimina TODOS los pares clave-valor almacenados en el array $_SESSION
// Esto borra los datos del usuario logueado: nombre, email, rol, permisos, etc.
// Después de esto, $_SESSION está vacío pero la sesión aún existe (ID de sesión sigue activo)
session_unset();

// Destruye completamente la sesión actual, eliminando el ID de sesión del servidor
// Esto invalida el archivo de sesión en /tmp/ (Linux) o AppData/Local/Temp/ (Windows)
// Combinado con session_unset(), garantiza que el usuario esté completamente deslogueado
session_destroy();

// Redirige al navegador del usuario hacia la página de inicio (index.html)
// Se añade un parámetro de mensaje ("msg") que es capturado por script.js en index.html
// El mensaje codificado ("Sesión cerrada correctamente") se muestra en una notificación flotante
// urlencode() convierte espacios en "+" y caracteres especiales en códigos %XX para URL segura
header("Location: ../index.html?msg=" . urlencode("Sesión cerrada correctamente"));

// Detiene la ejecución del script inmediatamente después de enviar el header
// Sin exit(), el código PHP seguiría ejecutándose después de la redirección (aunque el usuario ya se fue)
// Garantiza que no haya código no deseado ejecutándose post-logout
exit();
?>
