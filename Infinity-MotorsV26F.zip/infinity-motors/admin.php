<?php
// LÍNEA 1-2: Inicia sesión para acceder a datos del usuario autenticado ($_SESSION)
session_start();

// LÍNEA 4-8: Valida que el usuario existe y tiene rol de administrador
// Si no cumple, redirige al login y detiene ejecución
// Interactúa con: sistema de autenticación, login.html
if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] ?? 'usuario') !== 'admin') {
    $_SESSION['notification_msg'] = "Acceso denegado: Se requiere ser Administrador.";
    header("Location: login.html");
    exit();
}

// LÍNEA 11-12: Obtiene nombre del admin actual y su ID de la sesión
// Estos valores se usan para mostrar bienvenida y excluir admin de listado
$nombre = $_SESSION['user']['nombre'];
$admin_id = $_SESSION['user']['id'];

// LÍNEA 15-18: Conecta a base de datos Infinity Motors
// Interactúa con: mysql/base de datos, gestionar_vehiculos.php, gestionar_usuarios.php
$mysqli = new mysqli("localhost", "root", "", "infinity_motors");
if ($mysqli->connect_error) {
    die("Error de conexión a la base de datos.");
}

// LÍNEA 21-30: Consulta SQL para obtener TODOS los usuarios excepto el admin actual
// Variables preparadas previenen inyección SQL
// Los datos se guardan en array $usuarios para renderizar tabla HTML
// Interactúa con: tabla usuarios en BD, tabla HTML de gestión
$query_users = "SELECT id, nombre, email, rol FROM usuarios WHERE id != ? ORDER BY id ASC";
$stmt_users = $mysqli->prepare($query_users);
$stmt_users->bind_param("i", $admin_id);
$stmt_users->execute();
$result_users = $stmt_users->get_result();
$usuarios = [];
while ($row = $result_users->fetch_assoc()) {
    $usuarios[] = $row;
}
$stmt_users->close();

// LÍNEA 33-42: Consulta SQL para obtener vendedores disponibles
// Se usan en dos select HTML: uno para añadir vehículos y otro para editar
// Interactúa con: tabla usuarios (rol=vendedor), formularios de vehículos
$vendedores = [];
$query_vendedores = "SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre ASC";
$result_vendedores = $mysqli->query($query_vendedores);
if ($result_vendedores) {
    while ($row = $result_vendedores->fetch_assoc()) {
        $vendedores[] = $row;
    }
}
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- METADATOS HTML: Configuran la página para navegadores -->
    <meta charset="UTF-8"> <!-- Codificación de caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive design -->
    <title>Panel Administrador - Infinity Motors</title> <!-- Título de la pestaña del navegador -->
    <link rel="stylesheet" href="styles.css"> <!-- Importa hoja de estilos CSS global -->
</head>
<body>
    <!-- HEADER NAVBAR: Barra de navegación fija con logo y menú -->
    <header class="navbar sticky"> <!-- sticky = se queda en top al scroll -->
        <div class="row"> <!-- Contenedor grid para ancho controlado -->
            <nav>
                <!-- Logo e ícono: enlaza a inicio.php -->
                <div class="navbar-brand">
                    <a href="inicio.php"><img src="assets/img/logo-icon.png" alt="Logo" class="logo-img"><h1>Infinity Motors</h1></a>
                </div>
                
                <!-- MENÚ ADMIN: Enlaces internos a secciones del panel -->
                <!-- Interactúa con: secciones con id="users-management", id="add", id="published" -->
                <ul class="admin-menu">
                    <li><a href="#users-management">Usuarios</a></li>
                    <li><a href="#add">Añadir Vehículo</a></li>
                    <li><a href="#published">Publicados</a></li>
                </ul> 
                
                <!-- Botones de acción: volver al catálogo y cerrar sesión -->
                <!-- Interactúa con: inicio.php, logout.php (destruye sesión) -->
                <div class="navbar-actions">
                    <a href="inicio.php" class="btn btn-secondary">Catálogo</a>
                    <a href="php/logout.php" class="btn btn-danger">Cerrar sesión</a>
                </div>
            </nav>
        </div>
    </header>
    
    <!-- HERO/BANNER: Sección de bienvenida con título y descripción -->
    <section class="hero hero-small">
        <!-- Título principal de la página -->
        <h1>Panel de Administrador</h1>
        <!-- Mensaje de bienvenida personalizado con nombre del admin (sanitizado con htmlspecialchars) -->
        <p>Bienvenido, <strong><?php echo htmlspecialchars($nombre); ?></strong>. Gestión total del sitio.</p>
    </section>

    <!-- CONTENEDOR PRINCIPAL: Agrupa todas las secciones del panel admin -->
    <div class="admin-panel-container">
        
        <!-- SECCIÓN 1: GESTIÓN DE USUARIOS Y ROLES -->
        <section id="users-management" class="content-section">
            <h2>Gestión de Usuarios y Roles</h2>
            <div class="user-list-container">
                
                <!-- CONTROLES DE TABLA: Filtrado por búsqueda y selector de registros por página -->
                <div class="table-controls">
                    <!-- Input de búsqueda que filtra tabla en tiempo real vía JavaScript -->
                    <!-- Interactúa con: script.js (evento input) -->
                    <div class="search-box">
                        <input type="text" id="user-search" placeholder="Buscar por nombre o email...">
                    </div>
                    
                    <!-- Selector para mostrar 5, 10, 15, 20 o todos los registros -->
                    <!-- Interactúa con: JavaScript que oculta/muestra filas -->
                    <div class="records-selector">
                        <label for="records-per-page">Mostrar:</label>
                        <select id="records-per-page">
                            <option value="5">5 registros</option>
                            <option value="10" selected>10 registros</option>
                            <option value="15">15 registros</option>
                            <option value="20">20 registros</option>
                            <option value="all">Todos</option>
                        </select>
                    </div>
                </div>
                
                <!-- TABLA DE USUARIOS: Renderiza lista de usuarios con opción de cambiar rol -->
                <?php if (count($usuarios) > 0): ?>
                    <table class="users-table">
                        <!-- Encabezado de tabla con columnas: ID, Nombre, Email, Rol Actual, Cambiar Rol -->
                        <thead>
                            <tr>
                                <th>ID</th> <th>Nombre</th> <th>Email</th> <th>Rol Actual</th> <th>Cambiar Rol</th>
                            </tr>
                        </thead>
                        
                        <!-- CUERPO DE TABLA: Itera sobre array $usuarios y crea una fila por cada usuario -->
                        <tbody>
                            <?php foreach ($usuarios as $user_data): ?>
                                <!-- data-user-id = atributo para JavaScript identifique qué usuario se editó -->
                                <tr data-user-id="<?= $user_data['id'] ?>">
                                    <!-- Columnas con datos sanitizados (htmlspecialchars previene XSS) -->
                                    <td><?= htmlspecialchars($user_data['id']) ?></td>
                                    <td><?= htmlspecialchars($user_data['nombre']) ?></td>
                                    <td><?= htmlspecialchars($user_data['email']) ?></td>
                                    
                                    <!-- Clase "current-role" permite JavaScript actualizar visualmente tras cambio -->
                                    <td class="current-role"><?= htmlspecialchars(ucfirst($user_data['rol'])) ?></td>
                                    
                                    <!-- Select para elegir nuevo rol + Botón para guardar -->
                                    <!-- Interactúa con: JavaScript y gestionar_usuarios.php (updateRole) -->
                                    <td>
                                        <!-- Select con opciones de roles: usuario, vendedor, admin -->
                                        <select class="role-selector" id="role-<?= $user_data['id'] ?>">
                                            <option value="user" <?= $user_data['rol'] == 'user' ? 'selected' : '' ?>>Usuario</option>
                                            <option value="vendedor" <?= $user_data['rol'] == 'vendedor' ? 'selected' : '' ?>>Vendedor</option>
                                            <option value="admin" <?= $user_data['rol'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                                        </select>
                                        
                                        <!-- Botón con data-user-id para que JS sepa qué usuario actualizar -->
                                        <button class="btn btn-sm btn-primary save-role-btn" data-user-id="<?= $user_data['id'] ?>">Guardar</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <!-- Mensaje si no hay otros usuarios (solo el admin) -->
                    <p>No hay otros usuarios registrados.</p>
                <?php endif; ?>
            </div>
        </section>

        <!-- Separador visual entre secciones -->
        <hr>

        <!-- SECCIÓN 2: AGREGAR NUEVO VEHÍCULO -->
        <section id="add" class="content-section">
            <div class="form-container">
                <!-- Formulario multipart para subir archivo imagen + datos vehículo -->
                <!-- Interactúa con: gestionar_vehiculos.php (action=addCar) -->
                <form class="login-form-card" action="php/gestionar_vehiculos.php" method="POST" enctype="multipart/form-data">
                    <!-- Campo oculto que indica acción al servidor: addCar -->
                    <input type="hidden" name="action" value="addCar">
                    
                    <h2>Agregar Nuevo Vehículo</h2>
                    
                    <!-- GRID FORM: Dos columnas para campos en pequeño -->
                    <div class="form-grid">
                        <!-- Modelo: nombre del vehículo -->
                        <div>
                            <label for="modelo">Modelo</label>
                            <input type="text" id="modelo" name="modelo" placeholder="Ej: Ferrari F8" required>
                        </div>
                        
                        <!-- Precio: número con mínimo 1000 -->
                        <div>
                            <label for="precio">Precio ($)</label>
                            <input type="number" id="precio" name="precio" placeholder="Ej: 300000" required min="1000">
                        </div>
                        
                        <!-- Select de vendedor: obtiene lista de array PHP $vendedores -->
                        <!-- Asigna vehículo a un vendedor específico en la BD -->
                        <div>
                            <label for="vendedor_id">Vendedor Asignado</label>
                            <select id="vendedor_id" name="vendedor_id" required>
                                <option value="">-- Seleccionar Vendedor --</option>
                                <?php foreach ($vendedores as $vendedor): ?>
                                    <option value="<?= $vendedor['id'] ?>">
                                        <?= htmlspecialchars($vendedor['nombre']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Estado inicial del vehículo: disponible, reservado o vendido -->
                        <div>
                            <label for="estado">Estado Inicial</label>
                            <select id="estado" name="estado" required>
                                <option value="disponible" selected>Disponible</option>
                                <option value="reservado">Reservado</option>
                                <option value="vendido">Vendido</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- CAMPO ANCHO: Descripción del vehículo (motor, km, año, etc.) -->
                    <div class="form-full-width">
                        <label for="descripcion">Descripción</label>
                        <textarea id="descripcion" name="descripcion" placeholder="Descripción detallada (motor, km, año, etc.)" rows="4" required></textarea>
                    </div>
                    
                    <!-- INPUT FILE: Carga imagen del vehículo -->
                    <!-- Interactúa con: gestionar_vehiculos.php (procesa upload a servidor) -->
                    <div class="form-full-width">
                        <label for="imagen">Imagen del Vehículo</label>
                        <input type="file" id="imagen" name="imagen" accept="image/*" required>
                    </div>
                    
                    <!-- BOTÓN SUBMIT: Envía formulario al servidor -->
                    <div class="form-full-width">
                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top: 20px;">Agregar Vehículo</button>
                    </div>
                </form>
            </div>
        </section>
        
        <!-- Separador visual -->
        <hr>

        <!-- SECCIÓN 3: VEHÍCULOS PUBLICADOS (GESTIÓN) -->
        <section id="published" class="content-section">
            <h2>Vehículos Publicados (Gestión)</h2>
            
            <!-- Contenedor donde JavaScript cargará lista de vehículos dinámicamente -->
            <!-- Interactúa con: script.js (función cargarProductos) y gestionar_vehiculos.php -->
            <div id="car-list" class="admin-car-list">
                <p>Cargando vehículos...</p>
            </div>
        </section>
    </div>

    <!-- MODAL PARA EDITAR VEHÍCULOS: Se abre al hacer click en botón Editar de un vehículo -->
    <div id="edit-modal" class="modal-overlay">
        <div class="modal-content">
            <!-- CABECERA MODAL: Título y botón cerrar (X) -->
            <div class="modal-header">
                <h2 id="edit-modal-title">Editar Vehículo</h2>
                <!-- Botón cerrar con clase icon-button (solo ícono, sin texto) -->
                <button id="edit-modal-close" class="icon-button">&times;</button>
            </div>
            
            <!-- CUERPO MODAL: Formulario para editar datos del vehículo -->
            <div class="modal-body">
                <!-- Formulario multipart para actualizar vehículo con imagen opcional -->
                <!-- Interactúa con: gestionar_vehiculos.php (action=updateCar) -->
                <form id="edit-modal-form" action="php/gestionar_vehiculos.php" method="POST" enctype="multipart/form-data">
                    <!-- Campo oculto: acción updateCar -->
                    <input type="hidden" name="action" value="updateCar">
                    <!-- Campo oculto: ID del vehículo a actualizar (se rellena vía JavaScript) -->
                    <input type="hidden" id="edit-car-id" name="id">
                    
                    <!-- GRID FORM: Mismo layout que formulario agregar -->
                    <div class="form-grid">
                        <!-- Modelo editable -->
                        <div>
                            <label for="edit-modelo">Modelo</label>
                            <input type="text" id="edit-modelo" name="modelo" required>
                        </div>
                        
                        <!-- Precio editable -->
                        <div>
                            <label for="edit-precio">Precio ($)</label>
                            <input type="number" id="edit-precio" name="precio" required min="1000">
                        </div>
                        
                        <!-- Vendedor editable (reasignar a otro vendedor) -->
                        <div>
                            <label for="edit-vendedor_id">Vendedor Asignado</label>
                            <select id="edit-vendedor_id" name="vendedor_id" required>
                                <option value="">-- Seleccionar Vendedor --</option>
                                <?php foreach ($vendedores as $vendedor): ?>
                                    <option value="<?= $vendedor['id'] ?>">
                                        <?= htmlspecialchars($vendedor['nombre']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Estado editable: cambiar disponibilidad del vehículo -->
                        <div>
                            <label for="edit-estado">Estado</label>
                            <select id="edit-estado" name="estado" required>
                                <option value="disponible">Disponible</option>
                                <option value="reservado">Reservado</option>
                                <option value="vendido">Vendido</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Descripción editable -->
                    <div class="form-full-width">
                        <label for="edit-descripcion">Descripción</label>
                        <textarea id="edit-descripcion" name="descripcion" rows="4"></textarea>
                    </div>
                    
                    <!-- Campo file OPCIONAL: Si se sube, reemplaza imagen anterior -->
                    <div class="form-full-width">
                        <label for="edit-imagen">Cambiar Imagen actual (Opcional)</label>
                        <input type="file" id="edit-imagen" name="imagen" accept="image/*">
                        
                        <!-- Imagen preview de la imagen actual del vehículo -->
                        <img id="edit-current-image" src="/placeholder.svg" alt="Imagen actual" class="current-image-preview">
                    </div>
                    
                    <!-- BOTÓN SUBMIT: Envía actualización al servidor -->
                    <div class="form-full-width">
                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top: 20px;">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- NOTIFICACIONES: Contenedor donde aparecen mensajes de éxito/error -->
    <!-- Manipulado por función global mostrarNotificacion() en script.js -->
    <div id="notification" class="notification"></div>
    
    <!-- IMPORTA SCRIPT GLOBAL: Contiene funciones reutilizables (cargarProductos, mostrarNotificacion, etc.) -->
    <script src="script.js"></script>
    
    <!-- SCRIPT LOCAL: Lógica específica del panel admin -->
    <script>
        // Espera a que DOM esté completamente cargado antes de ejecutar código -->
        document.addEventListener("DOMContentLoaded", () => {
            
            // LÍNEA 1-3: URL de API que devuelve TODOS los vehículos (solo visible por admin)
            // true = mostrar botones de acción, false = no es usuario regular
            // Interactúa con: gestionar_vehiculos.php (action=getCarsAdmin)
            const adminFetchUrl = "php/gestionar_vehiculos.php?action=getCarsAdmin"; 
            
            // LÍNEA 4-8: Verifica que cargarProductos existe en script.js
            // Si existe, la llama con parámetros específicos para mostrar lista de vehículos
            if (typeof cargarProductos === 'function') {
                cargarProductos(adminFetchUrl, true, false); 
            } else {
                // Si no existe, registra error en consola para debugging
                console.error("Error: 'cargarProductos' no está en script.js");
            }

            // --- LÓGICA DEL MODAL DE EDICIÓN DE VEHÍCULOS ---
            
            // LÍNEA 10-12: Referencias a elementos DOM del modal -->
            const editModal = document.getElementById('edit-modal');
            const editModalCloseBtn = document.getElementById('edit-modal-close');
            const editForm = document.getElementById('edit-modal-form');

            // LÍNEA 14-18: Cierra modal cuando hace click en botón X
            // Interactúa con: CSS que oculta modal al remover clase "show"
            if (editModalCloseBtn) {
                editModalCloseBtn.addEventListener('click', () => {
                    editModal.classList.remove('show');
                });
            }

            // LÍNEA 20-45: Al enviar el formulario del modal, actualiza vehículo via fetch
            // Previene recarga de página usando preventDefault()
            // Interactúa con: gestionar_vehiculos.php (updateCar), mostrarNotificacion()
            if (editForm) {
                editForm.addEventListener('submit', function(e) {
                    e.preventDefault(); // Evita recarga de página
                    
                    // FormData recoge todos los campos incluido file de imagen
                    const formData = new FormData(this);
                    
                    // POST a gestionar_vehiculos.php con los datos del vehículo
                    fetch('php/gestionar_vehiculos.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        // Si response.ok = verdadero, significa que PHP procesó correctamente
                        if (response.ok) {
                            mostrarNotificacion("Vehículo actualizado con éxito.", false);
                            editModal.classList.remove('show'); // Cierra modal
                            // Recarga lista de vehículos sin refrescar página
                            cargarProductos(adminFetchUrl, true, false);
                        } else {
                            mostrarNotificacion("Error al actualizar el vehículo.", true);
                        }
                    })
                    // Si hay error de conexión, muestra notificación de error
                    .catch(err => {
                        mostrarNotificacion("Error de conexión al actualizar.", true);
                        console.error('Error en fetch (updateCar):', err);
                    });
                });
            }

            // --- LÓGICA DE CAMBIO DE ROL DE USUARIOS ---
            // Interactúa con: gestionar_usuarios.php (updateRole), tabla usuarios
            
            // LÍNEA 47-68: Por cada botón "Guardar" en la tabla de usuarios
            document.querySelectorAll('.save-role-btn').forEach(button => {
                button.addEventListener('click', function() {
                    // Obtiene ID del usuario desde atributo data-user-id
                    const userId = this.getAttribute('data-user-id');
                    // Lee el nuevo rol seleccionado en el select
                    const newRole = document.getElementById(`role-${userId}`).value;
                    
                    // Confirma con el usuario antes de cambiar rol (seguridad)
                    if (!confirm(`¿Seguro que quieres cambiar el rol del usuario #${userId} a ${newRole.toUpperCase()}?`)) return;

                    // POST a gestionar_usuarios.php para actualizar rol
                    fetch('php/gestionar_usuarios.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        // Parámetros: action=updateRole, id del usuario, nuevo rol
                        body: `action=updateRole&id=${userId}&rol=${newRole}`
                    })
                    .then(response => response.json()) // Espera JSON del servidor
                    .then(data => {
                        // Si success=true, muestra notificación de éxito
                        if (data.success) {
                            mostrarNotificacion(data.message, false); 
                            // Actualiza visualmente el rol en la tabla sin recargar página
                            document.querySelector(`tr[data-user-id="${userId}"] .current-role`).textContent = newRole.charAt(0).toUpperCase() + newRole.slice(1);
                        } else {
                            // Si hay error desde servidor, muestra mensaje de error
                            mostrarNotificacion(data.message, true); 
                        }
                    })
                    // Si hay error de conexión
                    .catch(error => mostrarNotificacion('Error de conexión.', true));
                });
            });

            // --- LÓGICA DE FILTRADO Y PAGINACIÓN DE TABLA DE USUARIOS ---
            // Interactúa con: input#user-search, select#records-per-page, tabla usuarios
            
            // LÍNEA 70-72: Referencias a elementos de filtrado
            const userSearch = document.getElementById('user-search');
            const recordsPerPage = document.getElementById('records-per-page');
            const usersTable = document.querySelector('.users-table tbody');
            
            // LÍNEA 74-87: Si existe input de búsqueda, filtra tabla en tiempo real
            if (userSearch && usersTable) {
                userSearch.addEventListener('input', function() {
                    // Obtiene texto de búsqueda en minúsculas
                    const searchTerm = this.value.toLowerCase();
                    // Itera sobre todas las filas de la tabla
                    const rows = usersTable.querySelectorAll('tr');
                    
                    rows.forEach(row => {
                        // Extrae nombre (columna 2) y email (columna 3)
                        const nombre = row.querySelector('td:nth-child(2)')?.textContent.toLowerCase() || '';
                        const email = row.querySelector('td:nth-child(3)')?.textContent.toLowerCase() || '';
                        
                        // Muestra fila si contiene el término de búsqueda
                        if (nombre.includes(searchTerm) || email.includes(searchTerm)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none'; // Oculta fila
                        }
                    });
                });
                
                // LÍNEA 89-101: Si existe select de registros, limita filas visibles
                if (recordsPerPage) {
                    recordsPerPage.addEventListener('change', function() {
                        const limit = this.value; // Obtiene valor seleccionado (5, 10, 15, 20, all)
                        const rows = Array.from(usersTable.querySelectorAll('tr'));
                        
                        // Si "all" está seleccionado, muestra todas las filas
                        if (limit === 'all') {
                            rows.forEach(row => row.style.display = '');
                        } else {
                            // Si no, limita a N registros convertido a número
                            const limitNum = parseInt(limit);
                            rows.forEach((row, index) => {
                                // Muestra si index < límite, oculta si no
                                row.style.display = index < limitNum ? '' : 'none';
                            });
                        }
                    });
                }
            }
        });
    </script>
</body>
</html>
