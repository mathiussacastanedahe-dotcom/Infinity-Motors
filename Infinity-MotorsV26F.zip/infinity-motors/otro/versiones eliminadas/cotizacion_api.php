<?php
session_start();
require_once "conexion.php";

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];
$action = $_REQUEST['action'] ?? '';

switch ($action) {

    // ACCIÓN 1: Obtener la lista de todos los vendedores
    case 'getSellers':
        $sql = "SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre ASC";
        $result = $conn->query($sql);
        $sellers = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $sellers;
        break;

    // ACCIÓN 2: Obtener autos filtrados por el ID del vendedor
    case 'getVehiclesBySeller':
        $vendedor_id = (int)($_GET['vendedor_id'] ?? 0);
        if ($vendedor_id === 0) {
            $response['message'] = 'ID de vendedor no válido.';
            break;
        }

        $sql = "SELECT id, modelo FROM autos WHERE vendedor_id = ? AND estado = 'disponible' ORDER BY modelo ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $vendedor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $vehicles = $result->fetch_all(MYSQLI_ASSOC);

        $response['success'] = true;
        $response['data'] = $vehicles;
        break;

    // ACCIÓN 3: Guardar la cotización (reemplaza a gestor.php)
    case 'submitQuotation':
        $cliente_id = (int)($_SESSION['user']['id'] ?? 0);
        $vendedor_id = (int)($_POST['vendedor_id'] ?? 0);
        $vehiculo_id = (int)($_POST['vehiculo_id'] ?? 0);
        
        $nombre = trim($_POST['nombre'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $mensaje = trim($_POST['mensaje'] ?? '');
        $asunto = "Cotización de Vehículo"; // Asunto automático

        if (empty($vendedor_id) || empty($vehiculo_id) || empty($nombre) || empty($email) || empty($mensaje)) {
            $response['message'] = 'Todos los campos son obligatorios.';
            break;
        }

        $sql = "INSERT INTO solicitudes (cliente_id, vendedor_id, vehiculo_id, nombre, email, asunto, mensaje, fecha) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiissss", $cliente_id, $vendedor_id, $vehiculo_id, $nombre, $email, $asunto, $mensaje);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Cotización enviada. Pronto podrás chatear con el vendedor desde tu perfil.';
        } else {
            $response['message'] = 'Error al guardar la cotización.';
        }
        break;
}

$conn->close();
echo json_encode($response);
?>