<?php
session_start();

//Verificación de sesión y rol
if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] ?? 'usuario') !== 'admin') {
    header("Location: login.html?msg=Acceso denegado"); // Redirigido a login con mensaje
    exit();
}

//Datos del administrador actual
$nombre = $_SESSION['user']['nombre'];
$admin_id = $_SESSION['user']['id'];

//Conexión a la base de datos
$mysqli = new mysqli("localhost", "root", "", "infinity_motors");

//Verificar conexión
if ($mysqli->connect_error) {
    die("Error de conexión a la base de datos.");
}

// --- 1. CONSULTAR USUARIOS (para la tabla de roles) ---
$query_users = "SELECT id, nombre, email, rol FROM usuarios WHERE id != ? ORDER BY id ASC";
$stmt_users = $mysqli->prepare($query_users);
$stmt_users->bind_param("i", $admin_id);
$stmt_users->execute();
$result_users = $stmt_users->get_result();
$usuarios = [];
while ($row_user = $result_users->fetch_assoc()) {
    $usuarios[] = $row_user;
}
$stmt_users->close();

// --- 2. CONSULTAR VENDEDORES (para el formulario de agregar) ---
$vendedores = [];
$query_vendedores = "SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre ASC";
$result_vendedores = $mysqli->query($query_vendedores);
if ($result_vendedores) {
    while ($row_vend = $result_vendedores->fetch_assoc()) {
        $vendedores[] = $row_vend;
    }
}
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrador - Infinity Motors</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* (Tus estilos CSS existentes de admin.php se mantienen) */
        .admin-panel-container { max-width: 1200px; margin: 0 auto 50px; padding: 20px; padding-top: 120px; }
        .content-section { margin-bottom: 40px; }
        .form-container { max-width: 650px; margin: auto; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-full-width { grid-column: 1 / -1; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: var(--color-dorado-metalico); }
        .admin-car-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-top: 20px; }
        .car { background: var(--color-morado-card); border-radius: 12px; padding: 20px; color: white; box-shadow: 0 4px 10px rgba(0,0,0,0.5); text-align: center; }
        .car p { text-align: left; margin: 5px 0; }
        .car strong { color: var(--color-dorado-metalico); }
        .users-table { width: 100%; border-collapse: collapse; margin-top: 20px; background: var(--color-morado-oscuro-base); border-radius: 8px; overflow: hidden; color: var(--color-blanco-tostado); }
        .users-table th, .users-table td { padding: 12px; text-align: left; border-bottom: 1px solid var(--color-morado-card); }
        .users-table th { background: var(--color-dorado-metalico); color: var(--color-negro-profundo); font-weight: bold; }
        .users-table tr:hover { background: rgba(212, 175, 55, 0.05); }
        .role-selector { padding: 8px; border-radius: 6px; border: 1px solid var(--color-gris-suave); background: var(--color-morado-card); color: white; margin-right: 5px; }
        .btn-sm { padding: 8px 12px; font-size: 0.9em; }
    </style>
</head>
<body>
    <header class="navbar sticky">
        <div class="row"> 
            <nav>
                <div class="navbar-brand"><a href="home.php"><img src="assets/img/logo-icon.png" alt="Logo" class="logo-img"><h1>Infinity Motors</h1></a></div>
                <ul class="admin-menu">
                    <li><a href="#users-management">Usuarios</a></li>
                    <li><a href="#add">Añadir Vehículo</a></li>
                    <li><a href="#published">Publicados</a></li>
                </ul> 
                <div class="navbar-actions">
                    <a href="home.php" class="btn btn-secondary">Catálogo</a>
                    <a href="perfil.php" class="btn">Mi Perfil</a>
                    <a href="php/logout.php" class="btn btn-danger">Cerrar sesión</a>
                </div>
            </nav>
        </div>
    </header>
    
    <section class="hero hero-small">
        <h1>Panel de Administrador</h1>
        <p>Bienvenido, <strong><?php echo htmlspecialchars($nombre); ?></strong>. Gestión total del sitio.</p>
    </section>

    <div class="admin-panel-container">
        
        <section id="users-management" class="content-section">
            <h2>Gestión de Usuarios y Roles</h2>
            <div class="user-list-container">
                <?php if (count($usuarios) > 0): ?>
                    <table class="users-table">
                        <thead>
                            <tr>
                                <th>ID</th> <th>Nombre</th> <th>Email</th> <th>Rol Actual</th> <th>Cambiar Rol</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($usuarios as $user_data): ?>
                                <tr data-user-id="<?= $user_data['id'] ?>">
                                    <td><?= htmlspecialchars($user_data['id']) ?></td>
                                    <td><?= htmlspecialchars($user_data['nombre']) ?></td>
                                    <td><?= htmlspecialchars($user_data['email']) ?></td>
                                    <td class="current-role"><?= htmlspecialchars(ucfirst($user_data['rol'])) ?></td>
                                    <td>
                                        <select class="role-selector" id="role-<?= $user_data['id'] ?>">
                                            <option value="user" <?= $user_data['rol'] == 'user' ? 'selected' : '' ?>>Usuario</option>
                                            <option value="vendedor" <?= $user_data['rol'] == 'vendedor' ? 'selected' : '' ?>>Vendedor</option>
                                            <option value="admin" <?= $user_data['rol'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                                        </select>
                                        <button class="btn btn-sm btn-primary save-role-btn" data-user-id="<?= $user_data['id'] ?>">Guardar</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No hay otros usuarios registrados en el sistema para gestionar.</p>
                <?php endif; ?>
            </div>
        </section>

        <hr>

        <section id="add" class="content-section">
            <div class="form-container">
                <form class="login-form-card" action="php/gestionar_vehiculos.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="addCar">
                
                    <h2>Agregar Nuevo Vehículo</h2>
                    <div class="form-grid">
                        <div>
                            <label for="modelo">Modelo</label>
                            <input type="text" id="modelo" name="modelo" placeholder="Ej: Ferrari F8" required>
                        </div>
                        <div>
                            <label for="precio">Precio ($)</label>
                            <input type="number" id="precio" name="precio" placeholder="Ej: 300000" required min="1000">
                        </div>
                        <div>
                            <label for="estado">Estado Inicial</label>
                            <select id="estado" name="estado" required>
                                <option value="disponible" selected>Disponible</option>
                                <option value="reservado">Reservado</option>
                                <option value="vendido">Vendido</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="vendedor_id">Vendedor Asignado</label>
                            <select id="vendedor_id" name="vendedor_id" required>
                                <option value="">-- Seleccionar Vendedor --</option>
                                <?php foreach ($vendedores as $vendedor): ?>
                                    <option value="<?= $vendedor['id'] ?>">
                                        <?= htmlspecialchars($vendedor['nombre']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-full-width">
                        <label for="descripcion">Descripción</label>
                        <textarea id="descripcion" name="descripcion" placeholder="Descripción detallada..." rows="4" required></textarea>
                    </div>
                    <div class="form-full-width">
                        <label for="imagen">Imagen del Vehículo</label>
                        <input type="file" id="imagen" name="imagen" accept="image/*" required>
                    </div>
                    <div class="form-full-width">
                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top: 20px;">Agregar Vehículo</button>
                    </div>
                </form>
            </div>
        </section>
        
        <hr>

        <section id="published" class="content-section">
            <h2>Vehículos Publicados (Gestión)</h2>
            <div id="car-list" class="admin-car-list">
                <p>Cargando vehículos...</p>
            </div>
        </section>
    </div>

    <div id="notification" class="notification"></div>
    
    <script src="script.js"></script>
    <script>
        // La función mostrarNotificacion() ahora viene de script.js

        // 🔹 Función para cargar los vehículos
        function cargarProductos() {
          // ✅ REAJUSTE: Llama a la acción 'getCars' del nuevo archivo
          fetch("php/gestionar_vehiculos.php?action=getCars")
            .then(res => res.json())
            .then(data => {
              if (data.error) {
                 document.getElementById("car-list").innerHTML = `<p class.error-message">${data.error}</p>`;
                 return;
              }
              const contenedor = document.getElementById("car-list");
              contenedor.innerHTML = "";
              data.forEach(car => {
                const div = document.createElement("div");
                div.classList.add("car");
                div.innerHTML = `
                  <h3>${car.modelo}</h3>
                  <img src="uploads/${car.imagen}" alt="${car.modelo}" style="max-width:100%; border-radius:8px;">
                  <p><strong>Precio:</strong> $${parseFloat(car.precio).toLocaleString('es-CO')}</p>
                  <p><strong>Estado:</strong> ${car.estado}</p>
                  <p><strong>Vendedor:</strong> ${car.vendedor_nombre || 'Sin Asignar'}</p>
                  <button onclick="editarCar(${car.id})" class="btn btn-edit">✏️ Editar</button>
                  <button onclick="eliminarCar(${car.id})" class="btn btn-danger">🗑️ Eliminar</button>
                `;
                contenedor.appendChild(div);
              });
            })
            .catch(err => console.error("Error cargando autos:", err));
        }

        function eliminarCar(id) {
            if (!confirm("¿Seguro que quieres eliminar este vehículo? ...")) return;
            // ✅ REAJUSTE: Llama a la acción 'deleteCar' del nuevo archivo
            fetch(`php/gestionar_vehiculos.php?action=deleteCar&id=${id}`)
                .then(res => res.text())
                .then(msg => {
                    mostrarNotificacion(msg); // Llama a la función global
                    cargarProductos();
                })
                .catch(err => {
                    mostrarNotificacion("Ocurrió un error al eliminar.", true);
                    console.error("Error eliminando:", err);
                });
        }

        function editarCar(id) {
            window.location.href = "editarCar.php?id=" + id; // Esto no cambia
        }

        document.addEventListener("DOMContentLoaded", () => {
            // initNavbar() y el manejo de notificaciones de URL ya están en script.js
            
            cargarProductos(); // Carga los productos al iniciar

            // 👑 LÓGICA DE CAMBIO DE ROL AJAX 👑
            document.querySelectorAll('.save-role-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.getAttribute('data-user-id');
                    const newRole = document.getElementById(`role-${userId}`).value;
                    
                    if (!confirm(`¿Seguro que quieres cambiar el rol del usuario #${userId} a ${newRole.toUpperCase()}?`)) {
                        return;
                    }

                    // ✅ REAJUSTE: Llama al nuevo gestor de usuarios
                    fetch('php/gestionar_usuarios.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=updateRole&id=${userId}&rol=${newRole}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            mostrarNotificacion(data.message, false); 
                            const currentRoleCell = document.querySelector(`tr[data-user-id="${userId}"] .current-role`);
                            if (currentRoleCell) {
                                currentRoleCell.textContent = newRole.charAt(0).toUpperCase() + newRole.slice(1);
                            }
                        } else {
                            mostrarNotificacion(data.message, true); 
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        mostrarNotificacion('Error de conexión al servidor.', true);
                    });
                });
            });
        });
    </script>
</body>
</html>