<?php
// Conexión con la base de datos
$conn = new mysqli("localhost", "root", "", "infinity_motors");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consultar productos
$sql = "SELECT * FROM productos";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Infinity Motors - Catálogo</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      background: #111439;
      color: #F8F8F9;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      text-align: center;
    }
    header {
      padding: 20px;
      background: linear-gradient(135deg, #5a189a, #ffb703);
    }
    header h1 {
      margin: 0;
      color: white;
    }
    .catalogo {
      padding: 40px 20px;
    }
    .productos-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    .producto {
      background: #1a1a2e;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0px 5px 15px rgba(0,0,0,0.3);
      transition: transform 0.3s ease;
    }
    .producto:hover {
      transform: scale(1.05);
    }
    .producto img {
      width: 100%;
      border-radius: 10px;
      margin-bottom: 10px;
    }
    .producto h3 {
      color: #ffb703;
    }
    .producto p {
      color: #F8F8F9;
      font-size: 1.1em;
    }
    .btn {
      display: inline-block;
      background: linear-gradient(135deg, #6a11cb, #ffb703);
      color: white;
      padding: 10px 20px;
      margin-top: 15px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s ease;
    }
    .btn:hover {
      background: linear-gradient(135deg, #5a189a, #d97706);
    }
  </style>
</head>
<body>
  <header>
    <h1>Infinity Motors 🚗</h1>
    <p>Catálogo de productos</p>
  </header>

  <section class="catalogo">
    <div class="productos-grid">
      <?php if ($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <div class="producto">
            <?php if ($row['imagen']): ?>
              <img src="uploads/<?php echo $row['imagen']; ?>" alt="<?php echo $row['nombre']; ?>">
            <?php endif; ?>
            <h3><?php echo $row['nombre']; ?></h3>
            <p><?php echo $row['descripcion']; ?></p>
            <p><strong>$<?php echo number_format($row['precio'], 2); ?></strong></p>
            <a href="login.html" class="btn">Comprar</a>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No hay productos disponibles.</p>
      <?php endif; ?>
    </div>
  </section>
</body>
</html>
<?php $conn->close(); ?>
