<?php
session_start();
require_once "conexion.php";

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];

// Verificamos que el usuario (cliente) esté logueado
if (!isset($_SESSION['user']) || $_SESSION['user']['rol'] === 'admin') {
    $response['message'] = 'Acceso no válido.';
    echo json_encode($response);
    exit;
}

$cliente_id = (int)$_SESSION['user']['id'];

// --- ASIGNACIÓN DE VENDEDOR ---
// En un sistema real, esto se asignaría dinámicamente.
// Por ahora, asignaremos todas las conversaciones al Vendedor ID 3 (Santiago Padilla)
// basado en tu archivo 'infinity_motors (3).sql'.
$vendedor_id = 3; 

$action = $_REQUEST['action'] ?? '';

switch ($action) {
    // --- Acción: OBTENER todos los mensajes de esta conversación ---
    case 'getMessages':
        $sql = "SELECT * FROM chat_mensajes 
                WHERE cliente_id = ? AND vendedor_id = ? 
                ORDER BY fecha ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $cliente_id, $vendedor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['message'] = 'Mensajes cargados.';
        $response['data'] = $messages;
        $stmt->close();
        break;

    // --- Acción: ENVIAR un nuevo mensaje ---
    case 'sendMessage':
        $mensaje = trim($_POST['mensaje'] ?? '');
        if (empty($mensaje)) {
            $response['message'] = 'El mensaje no puede estar vacío.';
            break;
        }

        $sql = "INSERT INTO chat_mensajes (cliente_id, vendedor_id, remitente_rol, mensaje) 
                VALUES (?, ?, 'cliente', ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $cliente_id, $vendedor_id, $mensaje);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Mensaje enviado.';
        } else {
            $response['message'] = 'Error al guardar el mensaje.';
        }
        $stmt->close();
        break;
}

$conn->close();
echo json_encode($response);
?>