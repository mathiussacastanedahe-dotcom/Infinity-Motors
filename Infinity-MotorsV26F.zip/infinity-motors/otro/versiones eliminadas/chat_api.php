<?php
session_start();
require_once "conexion.php"; //

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];

if (!isset($_SESSION['user'])) {
    $response['message'] = 'Acceso no válido. Inicia sesión.';
    echo json_encode($response);
    exit;
}

$user_id = (int)$_SESSION['user']['id'];
$user_rol = $_SESSION['user']['rol'];

// Usamos $_REQUEST para aceptar GET o POST
$action = $_REQUEST['action'] ?? '';

switch ($action) {
    // --- ACCIÓN PARA EL CLIENTE (perfil.php) ---
    case 'getMisCotizaciones':
        if ($user_rol !== 'usuario' && $user_rol !== 'user') break; // Acepta 'user' o 'usuario'
        
        // Buscamos en la tabla 'solicitudes' por el ID del cliente
        $sql = "SELECT s.*, a.modelo as vehiculo_modelo 
                FROM solicitudes s
                LEFT JOIN autos a ON s.vehiculo_id = a.id
                WHERE s.cliente_id = ? 
                ORDER BY s.fecha DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cotizaciones = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $cotizaciones;
        break;

    // --- ACCIONES PARA EL VENDEDOR (vendedor.php) ---
    case 'getCotizacionesRecibidas':
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') break;
        
        $sql = "SELECT s.*, u.nombre as cliente_nombre 
                FROM solicitudes s
                JOIN usuarios u ON s.cliente_id = u.id
                ORDER BY s.fecha DESC";
        $result = $conn->query($sql);
        $cotizaciones = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $cotizaciones;
        break;

    // --- ACCIONES COMUNES (Cliente y Vendedor) ---
    case 'getChatMessages':
        $cotizacion_id = (int)($_REQUEST['cotizacion_id'] ?? 0);
        if ($cotizacion_id === 0) break;
        
        // (Aquí faltaría validar que el $user_id pertenezca a esta cotización)
        
        $sql = "SELECT * FROM chat_mensajes 
                WHERE solicitud_id = ? 
                ORDER BY fecha ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cotizacion_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $messages;
        break;

    case 'sendChatMessage':
        $cotizacion_id = (int)($_POST['cotizacion_id'] ?? 0);
        $mensaje = trim($_POST['mensaje'] ?? '');
        
        if ($cotizacion_id === 0 || empty($mensaje)) {
            $response['message'] = 'Faltan datos.';
            break;
        }
        
        $remitente_rol = ($user_rol === 'vendedor' || $user_rol === 'admin') ? 'vendedor' : 'cliente';

        $sql = "INSERT INTO chat_mensajes (solicitud_id, remitente_id, remitente_rol, mensaje) 
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $cotizacion_id, $user_id, $remitente_rol, $mensaje);
        
        if ($stmt->execute()) {
            $response['success'] = true;
        } else {
            $response['message'] = 'Error al enviar mensaje.';
        }
        break;
}

$conn->close();
echo json_encode($response);
?>