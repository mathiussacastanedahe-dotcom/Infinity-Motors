<?php
require_once 'conexion.php'; 
session_start();
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    $response['message'] = 'Acceso no autorizado.';
    echo json_encode($response);
    exit;
}

$vendedorId = $_SESSION['user']['id'];

$car_id = filter_input(INPUT_POST, 'car_id', FILTER_VALIDATE_INT);
$cliente_nombre = $conn->real_escape_string($_POST['cliente_nombre']);
$cliente_email = filter_input(INPUT_POST, 'cliente_email', FILTER_VALIDATE_EMAIL);
$fecha_venta = $conn->real_escape_string($_POST['fecha_venta']);
$monto_final = filter_input(INPUT_POST, 'monto_final', FILTER_VALIDATE_FLOAT);

if (!$car_id || !$cliente_nombre || !$cliente_email || !$fecha_venta || $monto_final === false) {
    $response['message'] = 'Datos del formulario incompletos o inválidos.';
    echo json_encode($response);
    exit;
}

// Iniciar una transacción
$conn->begin_transaction();

try {
    // 1. Obtener el modelo del auto
    $stmtCar = $conn->prepare("SELECT modelo FROM autos WHERE id = ?");
    $stmtCar->bind_param("i", $car_id);
    $stmtCar->execute();
    $resultCar = $stmtCar->get_result();
    $car = $resultCar->fetch_assoc();
    $stmtCar->close();

    if (!$car) {
        $conn->rollback();
        $response['message'] = 'Vehículo no encontrado.';
        echo json_encode($response);
        exit;
    }
    $vehiculo_modelo = $car['modelo'];

    // 2. Insertar la nueva venta
    $stmtVenta = $conn->prepare("
        INSERT INTO ventas (vendedor_id, cliente_nombre, cliente_email, vehiculo_id, vehiculo_modelo, monto_final, fecha_venta) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmtVenta->bind_param("isssids", $vendedorId, $cliente_nombre, $cliente_email, $car_id, $vehiculo_modelo, $monto_final, $fecha_venta);
    $stmtVenta->execute();
    $stmtVenta->close();

    // 3. Actualizar el estado del vehículo
    $stmtUpdate = $conn->prepare("
        UPDATE autos 
        SET estado = 'vendido' 
        WHERE id = ?
    ");
    $stmtUpdate->bind_param("i", $car_id);
    $stmtUpdate->execute();
    $stmtUpdate->close();

    // Confirmar la transacción
    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Venta registrada y stock actualizado.';

} catch (Exception $e) {
    // Revertir la transacción si hay un error
    $conn->rollback();
    $response['message'] = 'Error en la transacción: ' . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>