<?php
session_start();
require_once "conexion.php"; //

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    $response['message'] = 'Acceso no válido. Inicia sesión.';
    echo json_encode($response);
    exit;
}

$user_id = (int)$_SESSION['user']['id'];
$user_rol = $_SESSION['user']['rol'];

$action = $_REQUEST['action'] ?? '';

switch ($action) {

    // --- ACCIONES PESTAÑA "REGISTRAR VENTA" ---
    
    case 'getAvailableCars':
        // ✅ ¡ESTA ES LA FUNCIÓN QUE TE FALTABA!
        // (Nota: Usamos el vendedor_id de la sesión para filtrar)
        $sql = "SELECT id, modelo, precio FROM autos 
                WHERE estado = 'disponible' AND vendedor_id = ? 
                ORDER BY modelo ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cars = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['cars'] = $cars;
        break;

    case 'registerSale':
        $car_id = (int)($_POST['car_id'] ?? 0);
        $cliente_nombre = trim($_POST['cliente_nombre'] ?? '');
        $cliente_email = trim($_POST['cliente_email'] ?? '');
        $fecha_venta = trim($_POST['fecha_venta'] ?? '');
        $monto_final = (float)($_POST['monto_final'] ?? 0);

        if (empty($car_id) || empty($cliente_nombre) || empty($fecha_venta) || empty($monto_final)) {
            $response['message'] = 'Faltan datos obligatorios.';
            break;
        }

        $conn->begin_transaction();
        try {
            $sql_insert = "INSERT INTO ventas (car_id, vendedor_id, cliente_nombre, cliente_email, monto_final, fecha_venta) 
                           VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("iisssd", $car_id, $user_id, $cliente_nombre, $cliente_email, $monto_final, $fecha_venta);
            $stmt->execute();
            $stmt->close();

            $sql_update = "UPDATE autos SET estado = 'vendido' WHERE id = ?";
            $stmt = $conn->prepare($sql_update);
            $stmt->bind_param("i", $car_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $response['success'] = true;
            $response['message'] = 'Venta registrada y auto actualizado.';
        } catch (Exception $e) {
            $conn->rollback();
            $response['message'] = 'Error en la transacción: ' + $e->getMessage();
        }
        break;

    // --- ACCIÓN PESTAÑA "HISTORIAL" ---
    case 'getSalesHistory':
        $sql = "SELECT v.id, a.modelo as vehiculo_modelo, v.cliente_nombre, v.cliente_email, v.fecha_venta, v.monto_final 
                FROM ventas v
                JOIN autos a ON v.car_id = a.id
                WHERE v.vendedor_id = ?
                ORDER BY v.fecha_venta DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $sales = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['sales'] = $sales;
        break;

    // --- ACCIONES PESTAÑA "COTIZACIONES Y CHATS" ---
    case 'getCotizacionesRecibidas':
        // Esta es la versión correcta y filtrada
        $sql = "SELECT s.*, u.nombre as cliente_nombre 
                FROM solicitudes s
                JOIN usuarios u ON s.cliente_id = u.id
                WHERE s.vendedor_id = ? 
                ORDER BY s.fecha DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cotizaciones = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $cotizaciones;
        break;

    case 'getChatMessages':
        $cotizacion_id = (int)($_REQUEST['cotizacion_id'] ?? 0);
        if ($cotizacion_id === 0) break;
        
        // (Aquí faltaría validar que el vendedor actual esté en esta cotización)
        
        $sql = "SELECT * FROM chat_mensajes 
                WHERE solicitud_id = ? 
                ORDER BY fecha ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cotizacion_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $messages = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['data'] = $messages;
        break;

    case 'sendChatMessage':
        $cotizacion_id = (int)($_POST['cotizacion_id'] ?? 0);
        $mensaje = trim($_POST['mensaje'] ?? '');
        
        if ($cotizacion_id === 0 || empty($mensaje)) {
            $response['message'] = 'Faltan datos.';
            break;
        }
        
        $remitente_rol = ($user_rol === 'vendedor' || $user_rol === 'admin') ? 'vendedor' : 'cliente';

        $sql = "INSERT INTO chat_mensajes (solicitud_id, remitente_id, remitente_rol, mensaje) 
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $cotizacion_id, $user_id, $remitente_rol, $mensaje);
        
        if ($stmt->execute()) {
            $response['success'] = true;
        } else {
            $response['message'] = 'Error al enviar mensaje.';
        }
        break;
}

$conn->close();
echo json_encode($response);
?>