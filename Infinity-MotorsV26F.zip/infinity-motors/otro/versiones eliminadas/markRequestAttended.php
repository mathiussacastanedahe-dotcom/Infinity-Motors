<?php
require_once 'conexion.php'; 
session_start();
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    $response['message'] = 'Acceso no autorizado.';
    echo json_encode($response);
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    $response['message'] = 'ID de solicitud no válido.';
    echo json_encode($response);
    exit;
}

try {
    $stmt = $conn->prepare("
        UPDATE solicitudes 
        SET estado = 'atendido' 
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $response['success'] = true;
        $response['message'] = 'Solicitud actualizada correctamente.';
    } else {
        $response['message'] = 'No se encontró la solicitud o ya estaba atendida.';
    }
    
    $stmt->close();

} catch (Exception $e) {
    $response['message'] = 'Error de base de datos: ' . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>