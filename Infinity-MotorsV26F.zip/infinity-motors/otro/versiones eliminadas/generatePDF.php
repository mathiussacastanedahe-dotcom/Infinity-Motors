<?php
session_start();
require_once "conexion.php";

if (!isset($_SESSION['user'])) {
    die("Acceso denegado.");
}

$sale_id = filter_input(INPUT_GET, 'sale_id', FILTER_VALIDATE_INT);
if (!$sale_id) {
    die("ID de venta no válido.");
}

$sql = "SELECT v.*, a.modelo, u.nombre as vendedor_nombre
        FROM ventas v
        JOIN autos a ON v.car_id = a.id
        JOIN usuarios u ON v.vendedor_id = u.id
        WHERE v.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$result = $stmt->get_result();
$sale = $result->fetch_assoc();

if (!$sale) {
    die("Venta no encontrada.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recibo de Venta #<?= htmlspecialchars($sale['id']) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .receipt-container { border: 1px solid #ccc; padding: 20px; max-width: 600px; margin: auto; }
        h1 { text-align: center; color: #333; }
        .details { margin-top: 30px; }
        .details p { line-height: 1.8; }
        .details strong { display: inline-block; width: 150px; }
        .footer { text-align: center; margin-top: 40px; font-size: 0.9em; color: #777; }
    </style>
</head>
<body>
    <div class="receipt-container">
        <h1>Infinity Motors</h1>
        <h2>Recibo de Venta</h2>
        <div class="details">
            <p><strong>ID de Venta:</strong> #<?= htmlspecialchars($sale['id']) ?></p>
            <p><strong>Fecha:</strong> <?= htmlspecialchars(date("d/m/Y", strtotime($sale['fecha_venta']))) ?></p>
            <hr>
            <p><strong>Cliente:</strong> <?= htmlspecialchars($sale['cliente_nombre']) ?></p>
            <p><strong>Email Cliente:</strong> <?= htmlspecialchars($sale['cliente_email']) ?></p>
            <hr>
            <p><strong>Vehículo:</strong> <?= htmlspecialchars($sale['modelo']) ?></p>
            <p><strong>Monto Final:</strong> $<?= htmlspecialchars(number_format($sale['monto_final'], 2)) ?></p>
            <hr>
            <p><strong>Atendido por:</strong> <?= htmlspecialchars($sale['vendedor_nombre']) ?></p>
        </div>
        <div class="footer">
            <p>© <?= date("Y") ?> Infinity Motors. Gracias por su compra.</p>
        </div>
    </div>
</body>
</html>