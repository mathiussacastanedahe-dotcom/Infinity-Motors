<?php
session_start();
require_once __DIR__ . "/conexion.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1. Recopilar y sanear los datos del formulario
    $nombre   = trim($_POST['nombre'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $password = $_POST['password'] ?? '';

    // 2. Validaciones (campos vacíos, formato de email, etc.)
    if (empty($nombre) || empty($email) || empty($password) || empty($telefono)) {
        header("Location: ../register.html?error=Todos los campos son obligatorios");
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: ../register.html?error=Correo electrónico inválido");
        exit;
    }

    // 3. Verificar si el correo ya está registrado
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        $conn->close();
        header("Location: ../register.html?error=El correo ya está registrado");
        exit;
    }
    $stmt->close();

    // 4. Hashear la contraseña e insertar el nuevo usuario
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, telefono, password, rol) VALUES (?, ?, ?, ?, 'usuario')");
    $stmt->bind_param("ssss", $nombre, $email, $telefono, $hash);

    if ($stmt->execute()) {
        $new_user_id = $stmt->insert_id; // Obtener el ID del nuevo usuario
        $stmt->close();

        // ✅ MEJORA CLAVE: Obtener todos los datos del nuevo usuario para crear una sesión completa
        $stmt = $conn->prepare("SELECT id, nombre, email, telefono, rol, fecha_registro FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $new_user_id);
        $stmt->execute();
        $new_user_data = $stmt->get_result()->fetch_assoc();
        
        // Guardar la información completa en la sesión
        $_SESSION['user'] = $new_user_data;

        $stmt->close();
        $conn->close();

        // Redirigir a la página de inicio con un mensaje de bienvenida
        header("Location: ../home.php?msg=" . urlencode("Registro exitoso, ¡bienvenido $nombre!"));
        exit;
    } else {
        // Manejo de errores en la inserción
        error_log("Error en registro: " . $stmt->error);
        $stmt->close();
        $conn->close();
        header("Location: ../register.html?error=Ocurrió un error al registrarse");
        exit;
    }
}
?> 