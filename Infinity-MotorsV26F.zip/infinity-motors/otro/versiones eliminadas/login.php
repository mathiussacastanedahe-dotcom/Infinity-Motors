<?php
session_start();
require_once __DIR__ . "/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        header("Location: ../login.html?error=" . urlencode("Correo y contraseña son requeridos."));
        exit();
    }
    
    // ✅ CORRECCIÓN CLAVE: Seleccionamos TODOS los campos que necesita el perfil.
    $stmt = $conn->prepare("SELECT id, nombre, email, telefono, password, rol, fecha_registro FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            // ✅ Y GUARDAMOS TODOS los campos en la sesión.
            // Esta es la "foto" completa y actualizada de tu información.
            $_SESSION['user'] = [
                "id" => $row['id'],
                "nombre" => $row['nombre'],
                "email" => $row['email'],
                "telefono" => $row['telefono'],
                "fecha_registro" => $row['fecha_registro'],
                "rol" => $row['rol']
            ];

            // Redirección según el rol del usuario
            if ($row['rol'] === 'admin') {
                header("Location: ../admin.php?msg=" . urlencode("Bienvenido Administrador"));
            } else {
                header("Location: ../home.php?msg=" . urlencode("Bienvenido " . $row['nombre']));
            }
            exit();

        } else {
            header("Location: ../login.html?error=" . urlencode("Contraseña incorrecta."));
            exit();
        }
    } else {
        header("Location: ../login.html?error=" . urlencode("El usuario no fue encontrado."));
        exit();
    }
}
?>