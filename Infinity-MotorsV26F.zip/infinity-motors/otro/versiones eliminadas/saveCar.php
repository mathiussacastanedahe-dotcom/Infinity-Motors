<?php
session_start();
require_once "conexion.php"; //

// 1. Seguridad: Verificar que el usuario sea administrador o vendedor
if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'admin' && $_SESSION['user']['rol'] !== 'vendedor')) {
    header("Location: ../login.html?error=Acceso denegado");
    exit;
}

// 2. Recoger y validar los datos del formulario
$car_id  = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT); // ID para saber si es edición
$modelo  = trim($_POST['modelo'] ?? '');
$precio  = filter_input(INPUT_POST, 'precio', FILTER_VALIDATE_FLOAT);
$estado  = trim($_POST['estado'] ?? '');
// ✅ CORREGIDO: Usamos vendedor_id (debe venir del campo select del formulario)
$vendedor_id = filter_input(INPUT_POST, 'vendedor_id', FILTER_VALIDATE_INT);
$descripcion = trim($_POST['descripcion'] ?? '');

// Validación de datos esenciales, incluyendo el ID del vendedor
if (empty($modelo) || $precio === false || empty($estado) || $vendedor_id === false || $vendedor_id === 0) {
    header("Location: ../admin.php?msg=" . urlencode("Error: Todos los campos son obligatorios y debe seleccionar un vendedor."));
    exit;
}

// 3. Manejo de la subida de imagen
$imagen_nombre = null;
if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
    $dir_subidas = "../uploads/";
    if (!is_dir($dir_subidas)) {
        mkdir($dir_subidas, 0777, true);
    }
    $imagen_nombre = time() . "_" . basename($_FILES["imagen"]["name"]);
    move_uploaded_file($_FILES["imagen"]["tmp_name"], $dir_subidas . $imagen_nombre);
}

// 4. Lógica de Decisión: ¿INSERT o UPDATE?
if ($car_id) {
    // --- LÓGICA DE ACTUALIZACIÓN (UPDATE) ---
    if ($imagen_nombre) {
        // ✅ CORREGIDO: La consulta usa vendedor_id (y tipos sdsissi)
        $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=?, imagen=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdsissi", $modelo, $precio, $estado, $vendedor_id, $descripcion, $imagen_nombre, $car_id);
    } else {
        // ✅ CORREGIDO: La consulta usa vendedor_id (y tipos sdsisi)
        $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdsisi", $modelo, $precio, $estado, $vendedor_id, $descripcion, $car_id);
    }
    $mensaje_exito = "Vehículo actualizado con éxito.";

} else {
    // --- LÓGICA DE CREACIÓN (INSERT) ---
    // ✅ CORREGIDO: La consulta usa vendedor_id (y tipos sdsiss)
    $sql = "INSERT INTO autos (modelo, precio, estado, vendedor_id, descripcion, imagen) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdsiss", $modelo, $precio, $estado, $vendedor_id, $descripcion, $imagen_nombre);
    $mensaje_exito = "Vehículo agregado con éxito.";
}

// 5. Ejecutar la consulta y redirigir
if ($stmt->execute()) {
    header("Location: ../admin.php?msg=" . urlencode($mensaje_exito));
} else {
    error_log("Error al guardar el vehículo: " . $stmt->error);
    header("Location: ../admin.php?msg=" . urlencode("Error al guardar el vehículo: " . $stmt->error));
}

$stmt->close();
$conn->close();
?>