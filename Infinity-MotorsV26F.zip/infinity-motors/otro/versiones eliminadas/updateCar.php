<?php
session_start();
require_once "conexion.php"; //

// Seguridad: Solo Admin o Vendedor pueden editar
if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'admin' && $_SESSION['user']['rol'] !== 'vendedor')) {
    header("Location: ../login.html?error=Acceso denegado");
    exit;
}

// Validar y sanear entradas
$id          = $_POST['id'] ?? null;
$modelo      = trim($_POST['modelo'] ?? '');
$precio      = $_POST['precio'] ?? '';
$estado      = trim($_POST['estado'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
// ✅ CORREGIDO: Aceptar el ID del vendedor
$vendedor_id = (int)($_POST['vendedor_id'] ?? 0); 

if (!is_numeric($id) || empty($modelo) || $precio === '' || $vendedor_id === 0) {
    header("Location: ../admin.php?error=Datos inválidos");
    exit;
}

$imgName = null;

// Manejar imagen (opcional)
if (!empty($_FILES['imagen']['name'])) {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    $tmpPath = $_FILES['imagen']['tmp_name'];
    $fileType = mime_content_type($tmpPath);

    if (!in_array($fileType, $allowedTypes)) {
        header("Location: ../admin.php?error=Tipo de imagen no permitido");
        exit;
    }

    $uploadDir = "../uploads/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $baseName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', basename($_FILES["imagen"]["name"]));
    $imgName = time() . "_" . $baseName;
    $target = $uploadDir . $imgName;

    if (!move_uploaded_file($tmpPath, $target)) {
        header("Location: ../admin.php?error=Error al subir imagen");
        exit;
    }
}

// Preparar y ejecutar UPDATE según si hay imagen o no
if ($imgName) {
    // ✅ CORREGIDO: Actualiza 'vendedor_id' en lugar de 'vendedor'
    $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=?, imagen=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        header("Location: ../admin.php?error=Error en la consulta");
        exit;
    }
    // Tipos: s, d, s, i (vendedor_id), s, s, i
    $stmt->bind_param("sdsissi", $modelo, $precio, $estado, $vendedor_id, $descripcion, $imgName, $id);
} else {
    // ✅ CORREGIDO: Actualiza 'vendedor_id' en lugar de 'vendedor' (Esta es la línea 75 que falló)
    $sql = "UPDATE autos SET modelo=?, precio=?, estado=?, vendedor_id=?, descripcion=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Prepare failed: " . $conn->error);
        header("Location: ../admin.php?error=Error en la consulta");
        exit;
    }
    // Tipos: s, d, s, i (vendedor_id), s, i
    $stmt->bind_param("sdsisi", $modelo, $precio, $estado, $vendedor_id, $descripcion, $id);
}

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    // Redirigir según el rol
    $redirect_url = ($_SESSION['user']['rol'] === 'admin') ? '../admin.php' : '../vendedor.php';
    header("Location: $redirect_url?msg=Vehículo actualizado correctamente");
    exit;
} else {
    error_log("Error actualizando auto: " . $stmt->error);
    $stmt->close();
    $conn->close();
    header("Location: ../admin.php?error=Error al actualizar el vehículo");
    exit;
}
?>