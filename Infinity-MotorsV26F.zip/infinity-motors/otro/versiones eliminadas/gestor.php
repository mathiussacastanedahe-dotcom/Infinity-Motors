<?php
session_start();
require_once "conexion.php";

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.'];

// Comprobamos la acción
$action = $_POST['action'] ?? '';
if ($action !== 'createRequest') {
    echo json_encode($response);
    exit;
}

// --- ✅ LÓGICA DEL CHAT: VINCULAR USUARIO ---
// Verificamos si hay un usuario logueado
$cliente_id = null;
if (isset($_SESSION['user']) && $_SESSION['user']['rol'] !== 'admin' && $_SESSION['user']['rol'] !== 'vendedor') {
    $cliente_id = (int)$_SESSION['user']['id'];
}
// ------------------------------------------

// Recogemos los datos del formulario
$nombre = trim($_POST['nombre'] ?? '');
$email = trim($_POST['email'] ?? '');
$asunto = trim($_POST['asunto'] ?? '');
$mensaje = trim($_POST['mensaje'] ?? '');
$vehiculo_id = !empty($_POST['vehiculo_id']) ? (int)$_POST['vehiculo_id'] : null;

if (empty($nombre) || empty($email) || empty($asunto) || empty($mensaje)) {
    $response['message'] = 'Todos los campos son obligatorios.';
    echo json_encode($response);
    exit;
}

// Preparamos el INSERT para la tabla 'solicitudes' (que ahora incluye cliente_id)
$sql = "INSERT INTO solicitudes (nombre, email, asunto, mensaje, vehiculo_id, cliente_id, fecha) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())";

$stmt = $conn->prepare($sql);

// bind_param no acepta 'null' directamente, así que usamos una variable
$vehiculo_id_sql = $vehiculo_id;
$cliente_id_sql = $cliente_id;

$stmt->bind_param("ssssii", 
    $nombre, 
    $email, 
    $asunto, 
    $mensaje, 
    $vehiculo_id_sql, 
    $cliente_id_sql
);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Solicitud enviada con éxito. Te contactaremos pronto.';
} else {
    $response['message'] = 'Error al guardar la solicitud en la base de datos.';
}

$stmt->close();
$conn->close();
echo json_encode($response);
?>