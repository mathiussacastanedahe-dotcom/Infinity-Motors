<?php
// Reemplaza php/addCar.php (o saveCar.php si ese es tu nombre)
require_once "conexion.php"; //
session_start();

// Seguridad: Solo Admin puede agregar
if (!isset($_SESSION['user']) || $_SESSION['user']['rol'] !== 'admin') {
    header("Location: ../login.html?error=" . urlencode("Acceso denegado"));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $modelo = $_POST['modelo'] ?? '';
    $precio = $_POST['precio'] ?? 0;
    $estado = $_POST['estado'] ?? 'disponible';
    // ✅ CORREGIDO: Usamos vendedor_id, que debe venir del <select>
    $vendedor_id = (int)($_POST['vendedor_id'] ?? 0); 
    $descripcion = $_POST['descripcion'] ?? '';

    // Validar ID del vendedor
    if ($vendedor_id === 0) {
        header("Location: ../admin.php?error=" . urlencode("Debe seleccionar un vendedor válido."));
        exit();
    }

    // Manejo de imagen
    $imagen = null;
    if (!empty($_FILES['imagen']['name'])) {
        $ruta_dir = "../uploads/";
        if (!is_dir($ruta_dir)) mkdir($ruta_dir, 0777, true);
        
        $nombre_archivo = time() . "_" . basename($_FILES['imagen']['name']);
        $ruta_completa = $ruta_dir . $nombre_archivo;
        
        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_completa)) {
             $imagen = $nombre_archivo; // Guardamos solo el nombre para la DB
        }
    }

    // ✅ CORREGIDO: La consulta SQL usa 'vendedor_id'
    $sql = "INSERT INTO autos (modelo, precio, estado, vendedor_id, descripcion, imagen) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    // Tipos de datos: s (modelo), d (precio), s (estado), i (vendedor_id), s (descripcion), s (imagen)
    $stmt->bind_param("sdsiss", $modelo, $precio, $estado, $vendedor_id, $descripcion, $imagen);

    if ($stmt->execute()) {
        header("Location: ../admin.php?msg=" . urlencode("Vehículo agregado con éxito"));
    } else {
        error_log("Error en addCar: " . $stmt->error);
        header("Location: ../admin.php?error=" . urlencode("Error al agregar vehículo: " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
}
?>