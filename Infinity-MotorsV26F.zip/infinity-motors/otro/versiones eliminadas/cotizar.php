<?php
session_start();
$user = $_SESSION['user'] ?? null;
$isLoggedIn = $user !== null;

// Pre-llenar datos si el usuario está logueado
$nombre_cliente = $user['nombre'] ?? '';
$email_cliente = $user['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cotizar Vehículo - Infinity Motors</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* (Estilos M3 que ya definimos en perfil.php y vendedor.php) */
        .modal-overlay { z-index: 1001; }
        .notification { z-index: 1002; }
        .cotizacion-container {
            max-width: 700px;
            margin: 120px auto 50px;
            padding: 40px;
            background: var(--color-morado-card);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        }
        .cotizacion-container h2 {
            color: var(--color-dorado-metalico);
            border-bottom: 2px solid var(--color-dorado-metalico);
            padding-bottom: 10px;
            margin-bottom: 30px;
        }
        .form-grupo {
            margin-bottom: 20px;
        }
        .form-grupo label {
            display: block;
            margin-bottom: 8px;
            color: var(--color-dorado-suave);
            font-weight: bold;
        }
        .form-grupo select,
        .form-grupo input,
        .form-grupo textarea {
            width: 100%;
            padding: 12px;
            background: var(--color-morado-oscuro-base);
            border: 1px solid var(--color-morado-medio);
            color: white;
            border-radius: 8px;
        }
        .form-grupo select:disabled {
            background: #444;
            cursor: not-allowed;
        }
        .filled-button {
             padding: 12px 28px; border-radius: 24px; border: none;
             font-family: 'Rajdhani', sans-serif; font-size: 1.1rem; font-weight: 700;
             cursor: pointer; transition: background 0.3s;
             background: var(--color-dorado-metalico); color: var(--color-negro-profundo);
             width: 100%; margin-top: 15px;
        }
        .filled-button:hover { background: var(--color-dorado-suave); }
    </style>
</head>
<body>
    <header class="navbar sticky">
        <div class="row"> 
            <nav>
                <div class="navbar-brand"><a href="home.php"><img src="assets/img/logo-icon.png" alt="Logo" class="logo-img"><h1>Infinity Motors</h1></a></div>
                <ul id="menu"><li><a href="home.php">Inicio</a></li><li><a href="home.php#catalogo">Catálogo</a></li></ul>
                <div class="navbar-actions">
                     <?php if ($isLoggedIn): ?>
                        <a href="perfil.php" class="btn btn-profile">Perfil</a>
                        <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
                    <?php else: ?>
                        <a href="login.html" class="btn btn-secondary">Iniciar Sesión</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>

    <div class="cotizacion-container">
        <h2>Solicitar Cotización</h2>
        <form id="cotizacion-form">
            <div class="form-grupo">
                <label for="select-vendedor">1. Elija un Vendedor</label>
                <select id="select-vendedor" name="vendedor_id" required>
                    <option value="">Cargando vendedores...</option>
                </select>
            </div>

            <div class="form-grupo">
                <label for="select-vehiculo">2. Elija un Vehículo</label>
                <select id="select-vehiculo" name="vehiculo_id" required disabled>
                    <option value="">(Primero elija un vendedor)</option>
                </select>
            </div>

            <hr style="border-color: var(--color-morado-medio); margin: 30px 0;">

            <div class="form-grupo">
                <label for="nombre">Su Nombre</label>
                <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($nombre_cliente) ?>" required>
            </div>
            <div class="form-grupo">
                <label for="email">Su Email</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($email_cliente) ?>" required>
            </div>
            <div class="form-grupo">
                <label for="mensaje">Mensaje Adicional</label>
                <textarea id="mensaje" name="mensaje" rows="4" placeholder="Escriba aquí sus dudas..."></textarea>
            </div>
            
            <button type="submit" class="filled-button">Enviar Cotización e Iniciar Chat</button>
        </form>
    </div>

    <div id="notification" class="notification"></div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const API_URL = 'php/cotizacion_api.php';
            const selectVendedor = document.getElementById('select-vendedor');
            const selectVehiculo = document.getElementById('select-vehiculo');
            const cotizacionForm = document.getElementById('cotizacion-form');

            // --- 1. Cargar Vendedores al inicio ---
            fetch(`${API_URL}?action=getSellers`)
                .then(res => res.json())
                .then(data => {
                    selectVendedor.innerHTML = '<option value="">-- Seleccione un vendedor --</option>';
                    if (data.success) {
                        data.data.forEach(vendedor => {
                            const option = new Option(vendedor.nombre, vendedor.id);
                            selectVendedor.add(option);
                        });
                    }
                });

            // --- 2. Cargar Vehículos cuando cambia el Vendedor ---
            selectVendedor.addEventListener('change', () => {
                const vendedorId = selectVendedor.value;
                selectVehiculo.innerHTML = '<option value="">Cargando...</option>';
                selectVehiculo.disabled = true;

                if (!vendedorId) {
                    selectVehiculo.innerHTML = '<option value="">(Primero elija un vendedor)</option>';
                    return;
                }

                fetch(`${API_URL}?action=getVehiclesBySeller&vendedor_id=${vendedorId}`)
                    .then(res => res.json())
                    .then(data => {
                        selectVehiculo.innerHTML = '<option value="">-- Seleccione un vehículo --</option>';
                        if (data.success && data.data.length > 0) {
                            data.data.forEach(vehiculo => {
                                const option = new Option(vehiculo.modelo, vehiculo.id);
                                selectVehiculo.add(option);
                            });
                            selectVehiculo.disabled = false;
                        } else {
                            selectVehiculo.innerHTML = '<option value="">(Este vendedor no tiene autos disponibles)</option>';
                        }
                    });
            });

            // --- 3. Enviar el Formulario ---
            cotizacionForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(cotizacionForm);
                formData.append('action', 'submitQuotation');

                fetch(API_URL, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    mostrarNotificacion(data.message, !data.success);
                    if (data.success) {
                        cotizacionForm.reset();
                        selectVehiculo.innerHTML = '<option value="">(Primero elija un vendedor)</option>';
                        selectVehiculo.disabled = true;
                        // Si está logueado, redirigir al perfil para que vea el chat
                        <?php if ($isLoggedIn): ?>
                            setTimeout(() => {
                                window.location.href = 'perfil.php';
                            }, 3000);
                        <?php endif; ?>
                    }
                });
            });
        });

        // Función de Notificación (copiada de tu perfil.php)
        function mostrarNotificacion(texto, isError = false) {
            const notif = document.getElementById("notification");
            if (!notif) return;
            notif.textContent = texto;
            notif.style.background = isError ? 'var(--color-peligro)' : 'var(--color-exito)';
            notif.classList.add("show");
            setTimeout(() => notif.classList.remove("show"), 4000);
        }
    </script>
</body>
</html>