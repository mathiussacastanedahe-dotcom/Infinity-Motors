<?php
require_once 'conexion.php'; 
session_start();
header('Content-Type: application/json');

$response = [];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit;
}

// Usa una sentencia preparada con comodines de LIKE
$stmt = $conn->prepare("
    SELECT id, modelo, precio 
    FROM autos 
    WHERE estado LIKE ?
    ORDER BY modelo ASC
");
$estado = '%disponible%';
$stmt->bind_param("s", $estado);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $autosDisponibles = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($autosDisponibles);
} else {
    echo json_encode(['error' => 'Error de base de datos: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>