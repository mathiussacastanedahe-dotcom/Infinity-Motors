<?php
require_once 'conexion.php'; 
session_start();
header('Content-Type: application/json');

$response = [];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT id, nombre, email, asunto, mensaje, estado, fecha_envio
        FROM solicitudes
        WHERE estado = 'pendiente' 
        ORDER BY fecha_envio ASC
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        $solicitudes = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($solicitudes);
    } else {
        throw new Exception('Error de base de datos: ' . $conn->error);
    }

    $stmt->close();

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>