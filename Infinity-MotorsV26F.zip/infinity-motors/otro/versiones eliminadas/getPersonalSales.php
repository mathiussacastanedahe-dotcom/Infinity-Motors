<?php
require_once 'conexion.php'; 
session_start();
header('Content-Type: application/json');

$response = [];

if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] !== 'vendedor' && $_SESSION['user']['rol'] !== 'admin')) {
    echo json_encode(['error' => 'Acceso no autorizado.']);
    exit;
}

$vendedorId = $_SESSION['user']['id'];

// Usa una sentencia preparada para evitar inyección SQL
$stmt = $conn->prepare("
    SELECT 
        v.id, 
        v.vehiculo_modelo AS modelo,
        v.cliente_nombre, 
        v.cliente_email, 
        v.monto_final, 
        DATE_FORMAT(v.fecha_venta, '%d/%m/%Y') AS fecha_venta
    FROM ventas v
    WHERE v.vendedor_id = ?
    ORDER BY v.fecha_venta DESC
");

// Vincula el ID del vendedor como un entero
$stmt->bind_param("i", $vendedorId);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    $ventas = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($ventas);
} else {
    echo json_encode(['error' => 'Error de base de datos: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>