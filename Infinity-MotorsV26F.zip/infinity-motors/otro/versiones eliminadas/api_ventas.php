<?php
session_start();
require_once "conexion.php"; //

header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida.', 'data' => []];

// Obtenemos los datos del usuario de forma segura
$user_id = (int)($_SESSION['user']['id'] ?? 0);
$user_rol = $_SESSION['user']['rol'] ?? 'guest';

// Usamos $_REQUEST para aceptar GET o POST
$action = $_REQUEST['action'] ?? '';

// Usamos un switch para manejar todas las acciones del Grupo 2
switch ($action) {

    // --- ACCIONES PARA PÁGINA DE COTIZACIÓN (cotizar.php) ---

    case 'getSellers':
        // Esta acción es pública, no requiere login
        $sql = "SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre ASC";
        $result = $conn->query($sql);
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'data' => $data];
        break;

    case 'getVehiclesBySeller':
        // Esta acción es pública, no requiere login
        $vendedor_id = (int)($_GET['vendedor_id'] ?? 0);
        if ($vendedor_id === 0) break;

        $sql = "SELECT id, modelo FROM autos WHERE vendedor_id = ? AND estado = 'disponible' ORDER BY modelo ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $vendedor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'data' => $data];
        break;

    case 'submitQuotation':
        // Esta acción guarda la cotización (reemplaza a gestor.php)
        $vendedor_id = (int)($_POST['vendedor_id'] ?? 0);
        $vehiculo_id = (int)($_POST['vehiculo_id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $mensaje = trim($_POST['mensaje'] ?? '');
        $asunto = "Cotización de Vehículo";
        $cliente_id_sql = ($user_rol === 'usuario') ? $user_id : null; // Vincula al usuario logueado

        if (empty($vendedor_id) || empty($vehiculo_id) || empty($nombre) || empty($email) || empty($mensaje)) {
            $response['message'] = 'Todos los campos son obligatorios.';
            break;
        }

        $sql = "INSERT INTO solicitudes (cliente_id, vendedor_id, vehiculo_id, nombre, email, asunto, mensaje, fecha) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiissss", $cliente_id_sql, $vendedor_id, $vehiculo_id, $nombre, $email, $asunto, $mensaje);
        
        if ($stmt->execute()) {
            $response = ['success' => true, 'message' => 'Cotización enviada. Pronto podrás chatear con el vendedor desde tu perfil.'];
        } else {
            $response['message'] = 'Error al guardar la cotización.';
        }
        break;

    // --- ACCIONES PARA PANEL DE CLIENTE (perfil.php) ---

    case 'getMisCotizaciones':
        if ($user_rol !== 'usuario' && $user_rol !== 'user') break;
        
        $sql = "SELECT s.*, a.modelo as vehiculo_modelo 
                FROM solicitudes s
                LEFT JOIN autos a ON s.vehiculo_id = a.id
                WHERE s.cliente_id = ? ORDER BY s.fecha DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'data' => $data];
        break;

    // --- ACCIONES PARA PANEL DE VENDEDOR (vendedor.php) ---

    case 'getAvailableCars':
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') break;
        
        $sql = "SELECT id, modelo, precio FROM autos WHERE estado = 'disponible' AND vendedor_id = ? ORDER BY modelo ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cars = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'cars' => $cars];
        break;

    case 'registerSale':
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') break;
        
        $car_id = (int)($_POST['car_id'] ?? 0);
        $cliente_nombre = trim($_POST['cliente_nombre'] ?? '');
        $cliente_email = trim($_POST['cliente_email'] ?? '');
        $fecha_venta = trim($_POST['fecha_venta'] ?? '');
        $monto_final = (float)($_POST['monto_final'] ?? 0);

        if (empty($car_id) || empty($cliente_nombre) || empty($fecha_venta) || empty($monto_final)) {
            $response['message'] = 'Faltan datos obligatorios.';
            break;
        }

        $conn->begin_transaction();
        try {
            $sql_insert = "INSERT INTO ventas (car_id, vendedor_id, cliente_nombre, cliente_email, monto_final, fecha_venta) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("iisssd", $car_id, $user_id, $cliente_nombre, $cliente_email, $monto_final, $fecha_venta);
            $stmt->execute();
            $stmt->close();

            $sql_update = "UPDATE autos SET estado = 'vendido' WHERE id = ?";
            $stmt = $conn->prepare($sql_update);
            $stmt->bind_param("i", $car_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $response = ['success' => true, 'message' => 'Venta registrada y auto actualizado.'];
        } catch (Exception $e) {
            $conn->rollback();
            $response['message'] = 'Error en la transacción: ' + $e->getMessage();
        }
        break;

    case 'getSalesHistory':
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') break;
        
        $sql = "SELECT v.id, a.modelo as vehiculo_modelo, v.cliente_nombre, v.cliente_email, v.fecha_venta, v.monto_final 
                FROM ventas v
                JOIN autos a ON v.car_id = a.id
                WHERE v.vendedor_id = ?
                ORDER BY v.fecha_venta DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $sales = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'sales' => $sales];
        break;

    case 'getCotizacionesRecibidas':
        if ($user_rol !== 'vendedor' && $user_rol !== 'admin') break;
        
        $sql = "SELECT s.*, u.nombre as cliente_nombre 
                FROM solicitudes s
                LEFT JOIN usuarios u ON s.cliente_id = u.id
                WHERE s.vendedor_id = ? ORDER BY s.fecha DESC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'data' => $data];
        break;

    // --- ACCIONES DE CHAT (COMUNES) ---

    case 'getChatMessages':
        $cotizacion_id = (int)($_REQUEST['cotizacion_id'] ?? 0);
        if ($cotizacion_id === 0) break;
        
        // (Falta validar que $user_id pertenezca a este chat)
        
        $sql = "SELECT * FROM chat_mensajes WHERE solicitud_id = ? ORDER BY fecha ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cotizacion_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $response = ['success' => true, 'data' => $data];
        break;

    case 'sendChatMessage':
        $cotizacion_id = (int)($_POST['cotizacion_id'] ?? 0);
        $mensaje = trim($_POST['mensaje'] ?? '');
        
        if ($cotizacion_id === 0 || empty($mensaje) || $user_id === 0) {
            $response['message'] = 'Faltan datos.';
            break;
        }
        
        $remitente_rol = ($user_rol === 'vendedor' || $user_rol === 'admin') ? 'vendedor' : 'cliente';

        $sql = "INSERT INTO chat_mensajes (solicitud_id, remitente_id, remitente_rol, mensaje) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiss", $cotizacion_id, $user_id, $remitente_rol, $mensaje);
        
        if ($stmt->execute()) {
            $response['success'] = true;
        } else {
            $response['message'] = 'Error al enviar mensaje.';
        }
        break;
}

$conn->close();
echo json_encode($response);
?>