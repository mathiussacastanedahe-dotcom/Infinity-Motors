<?php
// php/fix_admin_password.php
// Ejecuta en navegador: http://localhost/infinity-motors/php/fix_admin_password.php
// BORRA este archivo después de usarlo (por seguridad).

require_once __DIR__ . "/conexion.php";

$email = "mathiusinbox@gmail.com";
$newPlain = "123456";

// Generar hash seguro
$newHash = password_hash($newPlain, PASSWORD_DEFAULT);

// Actualizar usuario si existe, o crearlo si no
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($id);
    $stmt->fetch();
    $stmt->close();

    $upd = $conn->prepare("UPDATE usuarios SET password = ?, rol = 'admin' WHERE id = ?");
    $upd->bind_param("si", $newHash, $id);
    if ($upd->execute()) {
        echo "OK: contraseña actualizada para user id={$id}.<br>";
    } else {
        echo "ERROR al actualizar: " . $upd->error . "<br>";
    }
    $upd->close();
} else {
    $stmt->close();
    // (opcional) Insertar nuevo admin si no existe
    $ins = $conn->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'admin')");
    $nombre = "Mathius";
    $ins->bind_param("sss", $nombre, $email, $newHash);
    if ($ins->execute()) {
        echo "OK: usuario creado id=" . $ins->insert_id . ".<br>";
    } else {
        echo "ERROR al insertar: " . $ins->error . "<br>";
    }
    $ins->close();
}

// Comprobación inmediata
$check = $conn->prepare("SELECT id, nombre, password, rol FROM usuarios WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$res = $check->get_result();
if ($row = $res->fetch_assoc()) {
    echo "Confirmación: id={$row['id']}, nombre=" . htmlspecialchars($row['nombre']) . ", rol=" . htmlspecialchars($row['rol']) . "<br>";
    echo "Hash guardado:<pre>" . htmlspecialchars($row['password']) . "</pre><br>";
    echo "password_verify('123456') => ";
    echo password_verify('123456', $row['password']) ? "<b style='color:green'>OK</b>" : "<b style='color:red'>FALLA</b>";
} else {
    echo "No se encontró el usuario después de la actualización.";
}
$check->close();
$conn->close();
?>
