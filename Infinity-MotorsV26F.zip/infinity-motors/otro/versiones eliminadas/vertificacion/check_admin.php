<?php
require_once __DIR__ . "/conexion.php";
$email = "mathiusinbox@gmail.com";
$stmt = $conn->prepare("SELECT id, nombre, email, password, rol FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
if ($row = $res->fetch_assoc()) {
    echo "ID: ".$row['id']."<br>";
    echo "Nombre: ".htmlspecialchars($row['nombre'])."<br>";
    echo "Email: ".htmlspecialchars($row['email'])."<br>";
    echo "Rol: ".htmlspecialchars($row['rol'])."<br>";
    echo "Hash almacenado:<pre>".htmlspecialchars($row['password'])."</pre><br>";
    echo "password_verify('123456') => ";
    echo password_verify('123456', $row['password']) ? "<b style='color:green'>OK</b>" : "<b style='color:red'>FALLA</b>";
} else {
    echo "Usuario no encontrado";
}
