<?php
// php/make_admin.php
// Ejecutar desde navegador: http://localhost/infinity-motors/php/make_admin.php
// O desde CLI: php php/make_admin.php

require_once __DIR__ . "/conexion.php"; // asegúrate que conexion.php existe en /php

$email = "mathiusinbox@gmail.com";
$nombre = "Mathius";
$plainPassword = "123456";

try {
    // 1) Buscar usuario por email
    $sql = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    $hashed = password_hash($plainPassword, PASSWORD_DEFAULT);

    if ($stmt->num_rows > 0) {
        // Usuario existe -> actualizar password y rol a admin
        $stmt->bind_result($id);
        $stmt->fetch();
        $stmt->close();

        $sqlUpd = "UPDATE usuarios SET password = ?, rol = 'admin', nombre = ? WHERE id = ?";
        $stmt2 = $conn->prepare($sqlUpd);
        $stmt2->bind_param("ssi", $hashed, $nombre, $id);
        if ($stmt2->execute()) {
            echo "Usuario existente (id={$id}) actualizado: rol -> admin y contraseña cambiada correctamente.\n";
        } else {
            echo "Error al actualizar usuario: " . $stmt2->error . "\n";
        }
        $stmt2->close();
    } else {
        // Usuario NO existe -> insertar nuevo admin
        $stmt->close();
        $sqlIns = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'admin')";
        $stmt3 = $conn->prepare($sqlIns);
        $stmt3->bind_param("sss", $nombre, $email, $hashed);
        if ($stmt3->execute()) {
            echo "Usuario creado con id={$stmt3->insert_id} y rol=admin.\n";
        } else {
            echo "Error al insertar usuario: " . $stmt3->error . "\n";
        }
        $stmt3->close();
    }

    // Opcional: confirmar que ahora existe y es admin
    $confirm = $conn->prepare("SELECT id, nombre, email, rol FROM usuarios WHERE email = ?");
    $confirm->bind_param("s", $email);
    $confirm->execute();
    $res = $confirm->get_result();
    $row = $res->fetch_assoc();
    if ($row) {
        echo "Confirmación -> id: {$row['id']}, nombre: {$row['nombre']}, email: {$row['email']}, rol: {$row['rol']}\n";
    } else {
        echo "No se pudo confirmar la creación/actualización.\n";
    }
    $confirm->close();

} catch (Exception $e) {
    echo "Excepción: " . $e->getMessage() . "\n";
}
