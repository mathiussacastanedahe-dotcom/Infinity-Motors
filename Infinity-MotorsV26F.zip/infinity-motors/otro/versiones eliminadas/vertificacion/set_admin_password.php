<?php
require_once __DIR__ . "/conexion.php";

$email = "mathiusinbox@gmail.com";
$nombre = "Mathius";
$plain = "123456";
$hash = password_hash($plain, PASSWORD_DEFAULT);

// si existe -> actualizar, si no -> insertar
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($id);
    $stmt->fetch();
    $stmt->close();

    $upd = $conn->prepare("UPDATE usuarios SET password = ?, rol = 'admin', nombre = ? WHERE id = ?");
    $upd->bind_param("ssi", $hash, $nombre, $id);
    if ($upd->execute()) {
        echo "Usuario existente (id={$id}) actualizado a admin y contraseña cambiada.<br>";
    } else {
        echo "Error al actualizar: " . $upd->error;
    }
    $upd->close();
} else {
    $stmt->close();
    $ins = $conn->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'admin')");
    $ins->bind_param("sss", $nombre, $email, $hash);
    if ($ins->execute()) {
        echo "Usuario creado con id={$ins->insert_id} y rol=admin.<br>";
    } else {
        echo "Error al insertar: " . $ins->error;
    }
    $ins->close();
}

$confirm = $conn->prepare("SELECT id, nombre, email, rol FROM usuarios WHERE email = ?");
$confirm->bind_param("s", $email);
$confirm->execute();
$res = $confirm->get_result();
$r = $res->fetch_assoc();
if ($r) {
    echo "Confirmación: id={$r['id']}, nombre={$r['nombre']}, email={$r['email']}, rol={$r['rol']}<br>";
}
$confirm->close();
?>
