<?php
session_start();
require_once __DIR__ . "/conexion.php";

header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'Acceso denegado.'];

if (!isset($_SESSION['user']['id'])) {
    echo json_encode($response);
    exit;
}

$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$telefono = trim($_POST['telefono'] ?? '');
$userId = $_SESSION['user']['id'];

if (!$email || empty($telefono)) {
    $response['message'] = 'El correo y el teléfono son obligatorios y deben ser válidos.';
    echo json_encode($response);
    exit;
}

$sql = "UPDATE usuarios SET email = ?, telefono = ? WHERE id = ?";
$stmt = $conn->prepare($sql);

$stmt->bind_param("ssi", $email, $telefono, $userId);

if ($stmt->execute()) {
    // Actualizar la sesión con los nuevos datos
    $_SESSION['user']['email'] = $email;
    $_SESSION['user']['telefono'] = $telefono;
    
    $response['success'] = true;
    $response['message'] = '¡Perfil actualizado con éxito!';
} else {
    // Manejar el caso de email duplicado
    if ($conn->errno == 1062) {
        $response['message'] = 'Error: Ese correo electrónico ya está registrado.';
    } else {
        $response['message'] = 'Ocurrió un error al actualizar la base de datos.';
    }
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>