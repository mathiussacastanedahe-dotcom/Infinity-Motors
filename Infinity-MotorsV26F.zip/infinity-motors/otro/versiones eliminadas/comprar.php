<?php
session_start();

// 1. Verificar la sesión: Redirige si el usuario no está logueado
if (!isset($_SESSION['user'])) {
    header("Location: login.html?msg=" . urlencode("Debes iniciar sesión para acceder a tu perfil."));
    exit();
}

$user = $_SESSION['user'];
$isAdmin = ($user['rol'] ?? 'usuario') === 'admin';

// Conectar con la BD
$mysqli = new mysqli("localhost", "root", "", "infinity_motors");

if ($mysqli->connect_error) {
    die("Error de conexión a la base de datos. Por favor, inténtalo más tarde.");
}

// ✅ CORRECCIÓN: Consultar la tabla 'ventas' en lugar de 'compras'
// Buscamos las ventas donde el 'cliente_email' coincida con el email del usuario logueado.
// También unimos la tabla 'autos' para obtener el nombre del modelo del vehículo.
$stmt = $mysqli->prepare("
    SELECT 
        a.modelo AS vehiculo, 
        v.fecha_venta AS fecha, 
        v.monto_final AS precio 
    FROM ventas v
    JOIN autos a ON v.car_id = a.id
    WHERE v.cliente_email = ? 
    ORDER BY v.fecha_venta DESC
");
// Usamos el email del usuario para la búsqueda
$stmt->bind_param("s", $user['email']);
$stmt->execute();
$result = $stmt->get_result();

$compras = [];
while ($row = $result->fetch_assoc()) {
    $compras[] = $row;
}
$stmt->close();
$mysqli->close();

$fecha_registro = isset($user['fecha_registro']) ? date("d/m/Y", strtotime($user['fecha_registro'])) : "No disponible";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de <?= htmlspecialchars($user['nombre']) ?> - Infinity Motors</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Estilos locales para mejorar el diseño del perfil (tu código original) */
        .perfil-container {
            max-width: 900px; margin: 120px auto 50px; padding: 40px;
            background: var(--color-morado-card); border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
            color: var(--color-blanco-puro); min-height: 60vh;
        }
        .perfil-container h2 {
            color: var(--color-dorado-metalico); margin-bottom: 30px; font-size: 2.5rem;
            border-bottom: 2px solid var(--color-dorado-metalico); padding-bottom: 10px;
        }
        .perfil-info { margin-bottom: 30px; }
        .perfil-info p { font-size: 1.1em; margin: 12px 0; display: flex; align-items: center; }
        .perfil-info strong { 
            color: var(--color-dorado-suave); display: inline-block; min-width: 150px;
        }
        .compras h3 {
            color: var(--color-dorado-metalico); margin-top: 40px; padding-bottom: 5px;
            border-bottom: 1px solid var(--color-morado-oscuro-base);
        }
        .tabla-compras { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .tabla-compras th, .tabla-compras td {
            padding: 12px; text-align: left; border-bottom: 1px solid var(--color-morado-card);
        }
        .tabla-compras th {
            background: var(--color-morado-oscuro-base); color: var(--color-dorado-metalico); font-weight: 600;
        }
        .tabla-compras tr:hover { background: rgba(212, 175, 55, 0.05); }
        .no-compras { color: var(--color-plata-metalica); margin-top: 20px; }
        .btn-action-group { text-align: left; margin-top: 40px; }
        .btn-action-group .btn { margin-right: 10px; }
        .btn-edit-profile {
            background: var(--color-morado-oscuro-base); border: 1px solid var(--color-dorado-metalico);
            color: var(--color-dorado-metalico);
        }
        .btn-edit-profile:hover { background: var(--color-dorado-metalico); color: var(--color-negro-profundo); }

        /* Estilos para el Modal de Edición */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(13, 13, 13, 0.8); backdrop-filter: blur(5px);
            display: flex; justify-content: center; align-items: center; z-index: 1001;
            opacity: 0; visibility: hidden; transition: opacity 0.3s, visibility 0.3s;
        }
        .modal-overlay.show { opacity: 1; visibility: visible; }
        .modal-content {
            background: var(--color-morado-card); padding: 40px; border-radius: 15px;
            border: 1px solid var(--color-dorado-metalico);
            width: 90%; max-width: 450px; box-shadow: 0 8px 25px rgba(0,0,0,0.9);
        }
        .modal-content h2 { font-size: 2rem; }
        .modal-content label { margin-top: 15px; }
    </style>
</head>
<body>
    <header class="navbar sticky">
        <div class="row">
            <nav>
                <div class="navbar-brand">
                    <a href="home.php">
                        <img src="assets/img/logo-icon.png" alt="Infinity Motors Logo" class="logo-img">
                        <h1>Infinity Motors</h1>
                    </a>
                </div>
                
                <ul id="menu">
                    <li><a href="home.php">Inicio</a></li>
                    <li><a href="home.php#about">Sobre Nosotros</a></li>
                    <li><a href="home.php#catalogo">Catálogo</a></li>
                    <li><a href="home.php#equipo">Nuestro Equipo</a></li>

                    <li class="nav-username"><span class="btn btn-profile"><?= htmlspecialchars($user['nombre']) ?></span></li>

                    <?php if ($isAdmin): ?>
                        <li><a href="admin.php" class="btn btn-admin">Panel Admin</a></li>
                    <?php endif; ?>

                    <li><a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="perfil-container">
        <h2>Bienvenido, <?= htmlspecialchars($user['nombre']) ?></h2>
        
        <section class="perfil-info">
            <p><strong>Email:</strong> <span id="display-email"><?= htmlspecialchars($user['email'] ?? "No disponible") ?></span></p>
            <p><strong>Teléfono:</strong> <span id="display-telefono"><?= htmlspecialchars($user['telefono'] ?? "No disponible") ?></span></p>
            <p><strong>Rol:</strong> 
                <span style="color: <?= $isAdmin ? 'var(--color-advertencia)' : 'var(--color-exito)' ?>;">
                    <?= htmlspecialchars(ucfirst($user['rol'] ?? 'Usuario Estándar')) ?>
                </span>
            </p>
            <p><strong>Miembro desde:</strong> <?= $fecha_registro ?></p>
        </section>

        <div class="btn-action-group">
            <button id="edit-profile-btn" class="btn btn-edit-profile">Editar Información</button>
            <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
        </div>
        
        <section class="compras">
            <h3>Historial de Compras de Vehículos</h3>
            
            <?php if (count($compras) > 0): ?>
                <table class="tabla-compras">
                    <thead>
                        <tr>
                            <th>Vehículo/Producto</th>
                            <th>Fecha de Compra</th>
                            <th>Precio Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($compras as $c): ?>
                            <tr>
                                <td><?= htmlspecialchars($c['vehiculo']) ?></td>
                                <td><?= date("d/m/Y", strtotime($c['fecha'])) ?></td>
                                <td>$<?= number_format($c['precio'], 2, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-compras">¡Aún no tienes compras registradas! Explora nuestro <a href="home.php#catalogo">catálogo</a>.</p>
            <?php endif; ?>
        </section>
    </div>

    <div id="edit-modal" class="modal-overlay">
        <div class="modal-content">
            <form id="edit-profile-form">
                <h2>Editar Información</h2>
                <label for="email">Correo Electrónico:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                
                <label for="telefono">Teléfono:</label>
                <input type="tel" id="telefono" name="telefono" value="<?= htmlspecialchars($user['telefono'] ?? '') ?>" required>
                
                <button type="submit" class="btn" style="width:100%; margin-top:30px;">Guardar Cambios</button>
                <button type="button" id="close-modal-btn" class="btn btn-danger" style="width:100%; margin-top:10px;">Cancelar</button>
            </form>
        </div>
    </div>
    
    <div id="notification" class="notification"></div>

    <script>
    document.addEventListener("DOMContentLoaded", () => {
        const modal = document.getElementById('edit-modal');
        const editBtn = document.getElementById('edit-profile-btn');
        const closeModalBtn = document.getElementById('close-modal-btn');
        const editForm = document.getElementById('edit-profile-form');

        if (editBtn) {
            editBtn.addEventListener('click', () => modal.classList.add('show'));
        }
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => modal.classList.remove('show'));
        }

        if (editForm) {
            editForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);

                fetch('php/updateProfile.php', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    mostrarNotificacion(data.message, !data.success);
                    if (data.success) {
                        document.getElementById('display-email').textContent = formData.get('email');
                        document.getElementById('display-telefono').textContent = formData.get('telefono');
                        modal.classList.remove('show');
                    }
                })
                .catch(err => {
                    console.error("Error en fetch:", err);
                    mostrarNotificacion('Error de conexión. Inténtalo de nuevo.', true);
                });
            });
        }
    });

    function mostrarNotificacion(texto, isError = false) {
        const notif = document.getElementById("notification");
        if (!notif) return;
        
        notif.textContent = texto;
        notif.style.background = isError ? 'var(--color-peligro)' : 'var(--color-exito)';
        notif.classList.add("show");
        
        setTimeout(() => notif.classList.remove("show"), 4000);
    }
    </script>
</body>
</html>