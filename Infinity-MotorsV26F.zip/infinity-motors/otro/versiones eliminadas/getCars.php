<?php
require_once "conexion.php"; //

header('Content-Type: application/json');

// ✅ CONSULTA MEJORADA:
// Unimos 'autos' con 'usuarios' para obtener el nombre del vendedor
$sql = "SELECT 
            autos.*, 
            usuarios.nombre AS vendedor_nombre 
        FROM autos 
        LEFT JOIN usuarios ON autos.vendedor_id = usuarios.id
        ORDER BY autos.id DESC";

$result = $conn->query($sql);

if (!$result) {
    // Si la consulta falla (ej. si 'vendedor_id' no existe), envía un error
    echo json_encode(['error' => 'Error en la consulta: ' . $conn->error]);
    exit;
}

$autos = [];
while ($row = $result->fetch_assoc()) {
    $autos[] = $row;
}

$conn->close();
echo json_encode($autos);
?>