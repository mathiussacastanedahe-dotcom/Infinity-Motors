<?php
session_start();
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

// 1️⃣ Verificar sesión y permisos (seguridad)
if (!isset($_SESSION['user']) || ($_SESSION['user']['rol'] ?? 'usuario') !== 'admin') {
    $response['message'] = "Acceso denegado. Se requiere ser Administrador.";
    echo json_encode($response);
    exit();
}

// 2️⃣ Validar datos recibidos
$user_id = (int)$_POST['id'];
$new_role = trim($_POST['rol']);
$admin_id = $_SESSION['user']['id'];

// Normalizar rol (por compatibilidad)
if ($new_role === 'user') $new_role = 'usuario';

// ✅ CORRECCIÓN CLAVE: Agregar 'vendedor' a los roles permitidos
$allowed_roles = ['usuario', 'vendedor', 'admin'];

if (!in_array($new_role, $allowed_roles)) {
    $response['message'] = "Rol no válido: " . htmlspecialchars($new_role);
    echo json_encode($response);
    exit();
}

if ($user_id === $admin_id) {
    $response['message'] = "Error: No puedes cambiar tu propio rol.";
    echo json_encode($response);
    exit();
}

// 3️⃣ Conexión a la base de datos
$mysqli = new mysqli("localhost", "root", "", "infinity_motors");

if ($mysqli->connect_error) {
    $response['message'] = "Error de conexión a la base de datos.";
    echo json_encode($response);
    exit();
}

// 4️⃣ Actualizar el rol (consulta preparada)
$stmt = $mysqli->prepare("UPDATE usuarios SET rol = ? WHERE id = ?");

if (!$stmt) {
    $response['message'] = "Error preparando la consulta: " . $mysqli->error;
    echo json_encode($response);
    exit();
}

$stmt->bind_param("si", $new_role, $user_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        $response['success'] = true;
        $response['message'] = "Rol del usuario #{$user_id} actualizado a '" . ucfirst($new_role) . "'.";
    } else {
        $response['message'] = "No se realizaron cambios o el usuario no existe.";
    }
} else {
    $response['message'] = "Error al ejecutar la actualización: " . $stmt->error;
}

$stmt->close();
$mysqli->close();

echo json_encode($response);
?>