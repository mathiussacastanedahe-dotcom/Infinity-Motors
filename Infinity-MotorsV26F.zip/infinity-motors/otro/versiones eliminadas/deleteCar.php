<?php
session_start();
require_once "conexion.php"; //

// Seguridad: Solo Admin puede borrar
if (!isset($_SESSION['user']) || $_SESSION['user']['rol'] !== 'admin') {
    echo "Acceso denegado.";
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $conn->begin_transaction();
    try {
        // 1. Obtener la imagen para borrarla del disco
        $res = $conn->query("SELECT imagen FROM autos WHERE id = $id");
        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $imagen = "../uploads/" . $row['imagen'];
            if ($row['imagen'] && file_exists($imagen)) {
                unlink($imagen);
            }
        }

        // 2. ✅ BORRAR LOS "HIJOS": Eliminar registros de ventas asociados
        // Esta es la línea que soluciona el error de clave foránea
        $stmt_ventas = $conn->prepare("DELETE FROM ventas WHERE car_id = ?");
        $stmt_ventas->bind_param("i", $id);
        $stmt_ventas->execute();
        $stmt_ventas->close();
        
        // 3. (Opcional) Borrar cotizaciones asociadas si también quieres
        $stmt_solicitudes = $conn->prepare("DELETE FROM solicitudes WHERE vehiculo_id = ?");
        $stmt_solicitudes->bind_param("i", $id);
        $stmt_solicitudes->execute();
        $stmt_solicitudes->close();

        // 4. BORRAR EL "PADRE": Ahora sí, eliminar el auto
        $stmt_auto = $conn->prepare("DELETE FROM autos WHERE id = ?");
        $stmt_auto->bind_param("i", $id);
        $stmt_auto->execute();
        
        if ($stmt_auto->affected_rows > 0) {
            $conn->commit();
            echo "Vehículo y todos sus registros asociados eliminados.";
        } else {
            $conn->rollback();
            echo "Error: No se encontró el vehículo para eliminar.";
        }
        $stmt_auto->close();

    } catch (Exception $e) {
        $conn->rollback();
        echo "Error en la transacción: " + $e->getMessage();
    }
    
    $conn->close();

} else {
    echo "ID inválido";
}
?>