<?php
session_start();
require_once "conexion.php";

// Preparamos una respuesta JSON
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Acción no válida o no especificada.'];

// Obtenemos el ID del vendedor desde la SESIÓN (más seguro)
$vendedor_id = $_SESSION['user']['id'] ?? 0;

if ($vendedor_id === 0) {
    $response['message'] = 'Error de autenticación. Inicia sesión de nuevo.';
    echo json_encode($response);
    exit;
}

// Usamos un 'switch' para manejar las diferentes acciones
$action = $_POST['action'] ?? '';

switch ($action) {
    // --- Acción: Registrar una nueva venta ---
    case 'registerSale':
        $car_id = (int)($_POST['car_id'] ?? 0);
        $cliente_nombre = trim($_POST['cliente_nombre'] ?? '');
        $cliente_email = trim($_POST['cliente_email'] ?? '');
        $fecha_venta = trim($_POST['fecha_venta'] ?? '');
        $monto_final = (float)($_POST['monto_final'] ?? 0);

        if (empty($car_id) || empty($cliente_nombre) || empty($fecha_venta) || empty($monto_final)) {
            $response['message'] = 'Faltan datos obligatorios.';
            break;
        }

        // Usamos una transacción para asegurar que ambas operaciones (vender y actualizar) funcionen
        $conn->begin_transaction();
        try {
            // 1. Insertar la venta en la tabla 'ventas'
            $sql_insert = "INSERT INTO ventas (car_id, vendedor_id, cliente_nombre, cliente_email, monto_final, fecha_venta) 
                           VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("iisssd", $car_id, $vendedor_id, $cliente_nombre, $cliente_email, $monto_final, $fecha_venta);
            $stmt->execute();
            $stmt->close();

            // 2. Actualizar el auto a 'vendido' en la tabla 'autos'
            $sql_update = "UPDATE autos SET estado = 'vendido' WHERE id = ?";
            $stmt = $conn->prepare($sql_update);
            $stmt->bind_param("i", $car_id);
            $stmt->execute();
            $stmt->close();

            // Si todo fue bien, confirmamos la transacción
            $conn->commit();
            $response['success'] = true;
            $response['message'] = 'Venta registrada y auto actualizado.';

        } catch (Exception $e) {
            // Si algo falló, revertimos
            $conn->rollback();
            $response['message'] = 'Error en la transacción: ' + $e->getMessage();
        }
        break;

    // --- Acción: Obtener el historial de ventas del vendedor ---
    case 'getSalesHistory':
        // Hacemos un JOIN para obtener el nombre del modelo del auto
        $sql = "SELECT v.id, a.modelo as vehiculo_modelo, v.cliente_nombre, v.cliente_email, v.fecha_venta, v.monto_final 
                FROM ventas v
                JOIN autos a ON v.car_id = a.id
                WHERE v.vendedor_id = ?
                ORDER BY v.fecha_venta DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $vendedor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $sales = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['sales'] = $sales;
        break;

    // --- Acción: Obtener solo los autos disponibles ---
    case 'getAvailableCars':
        $sql = "SELECT id, modelo, precio FROM autos WHERE estado = 'disponible' ORDER BY modelo ASC";
        $result = $conn->query($sql);
        $cars = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['cars'] = $cars;
        break;

    // --- Acción: Obtener las solicitudes de clientes ---
    case 'getClientRequests':
        $sql = "SELECT id, nombre, email, asunto, mensaje, fecha FROM solicitudes ORDER BY fecha DESC";
        $result = $conn->query($sql);
        $requests = $result->fetch_all(MYSQLI_ASSOC);
        
        $response['success'] = true;
        $response['requests'] = $requests;
        break;

    // --- Acción: Marcar una solicitud como atendida (BorrÁNDOLA) ---
    case 'markRequestAttended':
        $request_id = (int)($_POST['id'] ?? 0);
        if ($request_id > 0) {
            $sql = "DELETE FROM solicitudes WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $request_id);
            if ($stmt->execute()) {
                $response['success'] = true;
                $response['message'] = 'Solicitud atendida.';
            } else {
                $response['message'] = 'Error al eliminar la solicitud.';
            }
            $stmt->close();
        } else {
            $response['message'] = 'ID de solicitud no válido.';
        }
        break;
}

$conn->close();
echo json_encode($response);
?>