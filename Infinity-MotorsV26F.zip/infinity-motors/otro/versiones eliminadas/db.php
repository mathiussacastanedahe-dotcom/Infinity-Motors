<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "infinity_motors";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error conexión: " . $conn->connect_error);
}
?>
