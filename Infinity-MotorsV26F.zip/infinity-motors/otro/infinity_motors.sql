-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-11-2025 a las 21:24:53
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `infinity_motors`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autos`
--

CREATE TABLE `autos` (
  `id` int(11) NOT NULL,
  `modelo` varchar(150) NOT NULL,
  `precio` decimal(12,2) NOT NULL,
  `estado` varchar(50) NOT NULL DEFAULT 'disponible',
  `descripcion` text DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `es_particular` tinyint(1) NOT NULL DEFAULT 0,
  `vendedor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `autos`
--

INSERT INTO `autos` (`id`, `modelo`, `precio`, `estado`, `descripcion`, `imagen`, `es_particular`, `vendedor_id`) VALUES
(5, 'JMC Vigus VIGUS WORK', 142000000.00, 'disponible', 'blanco', '1762056323_D_NQ_NP_2X_652456-MCO91201211256_092025-F.webp', 0, 3),
(6, 'Mg Cyberster', 250000000.00, 'disponible', 'Color: Gris\r\n\r\n\r\nTipo de combustible: Eléctrico\r\n\r\n\r\nMotor: 0.0\r\n\r\n\r\nVenpermuta: Sí\r\n\r\n\r\nPuertas: 2\r\n\r\n\r\nSensor de parqueo: Sí\r\n\r\n\r\nTransmisión: Automática\r\n\r\n\r\nCon precio negociable: No', '1762110714_D_NQ_NP_2X_678026-MCO88174284708_072025-F.webp', 0, 4),
(7, 'Audi Q3 2.O AT 40TFSI S-LINE Quattro', 144000000.00, 'vendido', 'Características del producto\r\n\r\nColor: Azul\r\n\r\n\r\nTipo de combustible: Gasolina\r\n\r\n\r\nMotor: 2.0\r\n\r\n\r\nVenpermuta: No\r\n\r\n\r\nPuertas: 5\r\n\r\n\r\nSensor de parqueo: Sí\r\n\r\n\r\nTransmisión: Automática\r\n\r\n\r\nCon precio negociable: Sí\r\n\r\nPrincipales\r\nMarca\r\nAudi\r\nModelo\r\nQ3\r\nAño\r\n2022\r\nVersión\r\n2.O AT 40TFSI S-LINE Quattro\r\nColor\r\nAzul\r\nTipo de combustible\r\nGasolina\r\nPuertas\r\n5\r\nTransmisión\r\nAutomática\r\nMotor\r\n2.0\r\nTipo de carrocería\r\nCamioneta\r\nCon cámara de reversa\r\nSí\r\nKilómetros\r\n33.666 km\r\nÚltimo dígito de la placa\r\n2\r\nSeguridad\r\nFrenos ABS\r\nSí\r\nAirbag conductor\r\nSí\r\nLuces con regulación automática\r\nSí\r\nSensor de parqueo\r\nSí\r\nAirbag para conductor y pasajero\r\nSí\r\nDesempañador trasero\r\nSí\r\nControl de estabilidad\r\nSí\r\nTercera luz de freno led\r\nSí\r\nCierre centralizado de puertas\r\nSí\r\nInterior\r\nTapizado de cuero\r\nSí\r\nCondiciones de compra\r\nCon precio negociable\r\nSí\r\nVenpermuta\r\nNo\r\nParidad de la placa\r\nPar\r\nÚltimo dígito de la placa\r\n2\r\n', '1762111417_D_NQ_NP_2X_895636-MCO96499459212_112025-F.webp', 0, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `asunto` varchar(255) NOT NULL,
  `mensaje` text NOT NULL,
  `vehiculo_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `vendedor_id` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id`, `nombre`, `email`, `asunto`, `mensaje`, `vehiculo_id`, `cliente_id`, `vendedor_id`, `fecha`) VALUES
(4, 'Daniel Felipe Nova Ussa', 'daniel.ventas@infinitymotors.com', 'Solicitud de Cotización', 'hola', NULL, 4, NULL, '2025-11-01 20:25:46'),
(6, '', '', 'Solicitud de Cotización', '', 5, 4, 3, '2025-11-02 06:31:53'),
(7, '', '', 'Solicitud de Cotización', '', 5, 2, 4, '2025-11-02 07:16:12'),
(8, '', '', 'Solicitud de Cotización', '', NULL, 4, 3, '2025-11-02 07:46:07'),
(9, '', '', 'Solicitud de Cotización', '', 7, 2, 4, '2025-11-02 19:25:58'),
(10, '', '', 'Solicitud de Cotización', '', 6, 2, 3, '2025-11-02 19:32:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('user','vendedor','admin') NOT NULL DEFAULT 'user',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `telefono`, `password`, `rol`, `fecha_registro`) VALUES
(2, 'Mathius Santiago Castañeda Herrera ', 'mathius.admin@infinitymotors.com', '3212517014', '$2y$10$3O5fXykTWNeb3uUMU0NW/uwujCWvY8oSaWQKOzT7C17TR4iSTX8Z2', 'admin', '2025-10-28 01:53:07'),
(3, 'Santiago Padilla Gutierrez', 'santiago.ventas@infinitymotors.com', '3186760126', '$2y$10$JYxCkgPudH95dKohO.StleEjy1bjnklRk4XTPxrSjB8Vn36NpZuYK', 'vendedor', '2025-10-28 02:10:18'),
(4, 'Daniel Felipe Nova Ussa', 'daniel.ventas@infinitymotors.com', '3202729567', '$2y$10$toj7WMHxPbKoGqfIdnZAdOU0FV9MJ2O.IKf5BMGp8JC4CnZGhKon2', 'vendedor', '2025-10-28 02:13:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `vendedor_id` int(11) NOT NULL,
  `cliente_nombre` varchar(150) NOT NULL,
  `cliente_email` varchar(150) NOT NULL,
  `monto_final` decimal(12,2) NOT NULL,
  `fecha_venta` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `car_id`, `vendedor_id`, `cliente_nombre`, `cliente_email`, `monto_final`, `fecha_venta`) VALUES
(2, 5, 3, 'Mathius', 'mathiusinbox@gmail.com', 140000000.00, '2025-11-02'),
(3, 7, 4, 'Mathius Santiago Castañeda Herrera', 'mathius.admin@infinitymotors.com', 140000000.00, '2025-11-02');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autos`
--
ALTER TABLE `autos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_auto_vendedor` (`vendedor_id`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehiculo_id` (`vehiculo_id`),
  ADD KEY `fk_cotizacion_cliente` (`cliente_id`),
  ADD KEY `fk_solicitud_vendedor` (`vendedor_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `car_id` (`car_id`),
  ADD KEY `vendedor_id` (`vendedor_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autos`
--
ALTER TABLE `autos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `autos`
--
ALTER TABLE `autos`
  ADD CONSTRAINT `fk_auto_vendedor` FOREIGN KEY (`vendedor_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `fk_cotizacion_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_solicitud_vendedor` FOREIGN KEY (`vendedor_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `solicitudes_ibfk_1` FOREIGN KEY (`vehiculo_id`) REFERENCES `autos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_venta_auto` FOREIGN KEY (`car_id`) REFERENCES `autos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_venta_vendedor` FOREIGN KEY (`vendedor_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `autos` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ventas_ibfk_2` FOREIGN KEY (`vendedor_id`) REFERENCES `usuarios` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
