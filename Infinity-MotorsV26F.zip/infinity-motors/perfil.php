<?php
// LÍNEA 1: Inicia sesión para acceder a datos del usuario autenticado ($_SESSION)
session_start();

// LÍNEA 3-4: Obtiene usuario de la sesión (si no existe, será null)
// Interactúa con: sistema de autenticación, login
$user = $_SESSION['user'] ?? null;

// LÍNEA 6-10: SEGURIDAD - Valida que el usuario existe y está logueado
// Si no existe, redirige a login con mensaje de error
// Previene acceso no autenticado a perfil
// Interactúa con: login.html
if (!$user) {
    header('Location: login.html?error=Debes iniciar sesión para ver tu perfil.');
    exit;
}

// LÍNEA 12-18: VALIDACIÓN DE ROLES - Redirige según tipo de usuario
// Admin: va a admin.php
// Vendedor: va a vendedor.php
// Usuario: continúa en perfil.php (esta página)
// Interactúa con: admin.php, vendedor.php
if ($user['rol'] === 'admin') {
    header('Location: admin.php');
    exit;
}
if ($user['rol'] === 'vendedor') {
    header('Location: vendedor.php');
    exit;
}

// LÍNEA 20-26: PREPARACIÓN DE DATOS PARA VISTA
// Sanitiza datos del usuario para mostrar en HTML (previene XSS)
// htmlspecialchars convierte caracteres especiales a entidades HTML
// Interactúa con: formulario perfil, navbar, banner
$userName = htmlspecialchars($user['nombre']); // Nombre completo sanitizado
$userEmail = htmlspecialchars($user['email']); // Email sanitizado
$userTelefono = htmlspecialchars($user['telefono']); // Teléfono sanitizado

// LÍNEA 28: Convierte fecha de registro de formato BD (Y-m-d) a formato legible (d/m/Y)
$userFechaRegistro = date("d/m/Y", strtotime($user['fecha_registro']));

// LÍNEA 30-31: Extrae primer nombre del usuario para mostrar en navbar
// Útil para mostrar "Mi Perfil (Juan)" en lugar del nombre completo
$userNameShort = htmlspecialchars(explode(' ', $userName)[0]);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- METADATOS HTML: Configuran página para navegadores y SEO -->
    <meta charset="UTF-8"> <!-- Codificación UTF-8 para caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive mobile -->
    <title>Mi Perfil - Infinity Motors</title> <!-- Título pestaña navegador -->
    <link rel="stylesheet" href="styles.css"> <!-- Hoja estilos global -->
</head>
<body>
    <!-- HEADER NAVBAR: Barra de navegación fija con logo, menú y botones sesión -->
    <header class="navbar sticky"> <!-- sticky = permanece en top al scroll -->
        <div class="row"> <!-- Contenedor grid con ancho controlado -->
            <nav>
                <!-- LOGO/MARCA: Enlaza a inicio.php -->
                <div class="navbar-brand"><a href="inicio.php"><img src="assets/img/logo-icon.png" alt="Logo" class="logo-img"><h1>Infinity Motors</h1></a></div>      
                
                <!-- MENÚ PRINCIPAL: Enlaces a secciones principales del sitio -->
                <!-- Interactúa con: inicio.php -->
                <ul id="menu">
                    <li><a href="inicio.php">Inicio</a></li>
                    <li><a href="inicio.php#catalogo">Catálogo</a></li>
                    <li><a href="cotizar.php">Cotizar</a></li>
                </ul>

                <!-- ACCIONES USUARIO: Botones de perfil y cierre de sesión -->
                <!-- Interactúa con: perfil.php (actual), logout.php -->
                <div class="navbar-actions">
                    <!-- Enlace al perfil mostrando primer nombre del usuario (sanitizado) -->
                    <!-- Useful para feedback visual del usuario autenticado -->
                    <a href="perfil.php" class="btn btn-profile">Mi Perfil (<?= $userNameShort ?>)</a>
                    <!-- Enlace para destruir sesión y cerrar sesión -->
                    <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
                </div>

                <!-- TOGGLE MÓVIL: Tres líneas para menú hamburguesa en dispositivos móviles -->
                <div class="mobile-toggle"><span></span><span></span><span></span></div>
            </nav>
        </div>
    </header>

    <!-- BANNER: Sección de bienvenida con nombre del usuario -->
    <div class="banner-login">
        <!-- Título dinámico con nombre completo del usuario (sanitizado) -->
        <h1>Mi Perfil: <?= $userName ?></h1>
    </div>

    <!-- MAIN: Contenedor principal del perfil con dos pestañas -->
    <main class="perfil-container">
        <!-- NAVEGACIÓN POR PESTAÑAS: Botones para cambiar entre Datos y Cotizaciones -->
        <!-- Interactúa con: JavaScript initTabs(), contenedores con id="datos" y id="cotizaciones" -->
        <div class="tab-navigation">
            <!-- Botón pestaña 1: Datos personales (activo por defecto) -->
            <button class="tab-button active" data-tab="datos">Mis Datos Personales</button>
            <!-- Botón pestaña 2: Cotizaciones/Chats -->
            <button class="tab-button" data-tab="cotizaciones">Mis Cotizaciones (Chats)</button>
        </div>
        
        <!-- PESTAÑA 1: DATOS PERSONALES -->
        <!-- ID="datos" y clase "active" indica que es visible por defecto -->
        <!-- Interactúa con: JavaScript que maneja form submit, gestionar_usuarios.php (updateProfile) -->
        <div id="datos" class="tab-content active">
            <h3>Actualizar Mis Datos</h3>
            
            <!-- FORMULARIO DE PERFIL: Recoge y actualiza datos del usuario -->
            <!-- action="gestionar_usuarios.php" via fetch (no recarga página) -->
            <form id="profile-update-form" class="profile-form-card">
                <!-- Campo oculto que indica acción al endpoint: updateProfile -->
                <input type="hidden" name="action" value="updateProfile">
                
                <!-- Nombre completo READONLY: No se puede editar por política de sistema -->
                <!-- Razón: Nombre está en registro oficial, no debe cambiar sin verificación -->
                <label for="profile-nombre">Nombre Completo (No editable)</label>
                <input type="text" id="profile-nombre" name="nombre" value="<?= $userName ?>" readonly disabled>
                
                <!-- Email EDITABLE: El usuario puede actualizar su email -->
                <!-- required = campo obligatorio -->
                <label for="profile-email">Correo Electrónico</label>
                <input type="email" id="profile-email" name="email" value="<?= $userEmail ?>" required>
                
                <!-- Teléfono EDITABLE: El usuario puede actualizar su teléfono -->
                <label for="profile-telefono">Teléfono</label>
                <input type="tel" id="profile-telefono" name="telefono" value="<?= $userTelefono ?>" required>
                
                <!-- Información: Fecha de registro mostrada como texto (no editable) -->
                <!-- Convertida a formato legible (d/m/Y) en PHP -->
                <p>Miembro desde: <?= $userFechaRegistro ?></p>
                
                <!-- BOTÓN SUBMIT: Envía cambios sin recargar página (manejo vía JavaScript/fetch) -->
                <button type="submit" class="btn btn-primary" style="width: 100%;">Guardar Cambios</button>
            </form>
        </div>
        
        <!-- PESTAÑA 2: COTIZACIONES / CHATS -->
        <!-- Inicialmente oculta (no tiene clase "active") -->
        <!-- Se muestra al hacer click en botón "Mis Cotizaciones" -->
        <!-- Interactúa con: JavaScript que carga cotizaciones, api_vendedor.php (getMisCotizaciones) -->
        <div id="cotizaciones" class="tab-content">
            <h3>Mis Conversaciones</h3>
            
            <!-- CONTENEDOR DE COTIZACIONES: Se rellena dinámicamente con JavaScript -->
            <!-- Por defecto muestra mensaje de carga -->
            <div id="user-cotizaciones-list" class="cotizacion-list">
                <p>Cargando cotizaciones...</p>
            </div>
        </div>
    </main>

    <!-- MODAL PARA CHAT CON VENDEDOR: Se abre cuando usuario hace click en "Ver Chat" -->
    <!-- Inicialmente oculto (sin clase "show"), se abre vía JavaScript -->
    <!-- Interactúa con: JavaScript que carga mensajes, api_vendedor.php (getChatMessages, sendChatMessage) -->
    <div id="chat-modal-user" class="modal-overlay">
        <!-- CONTENIDO DEL MODAL: Área principal con ventana de chat y formulario -->
        <div class="modal-content-chat">
            <!-- HEADER DEL MODAL: Título dinámico y botón cerrar -->
            <div class="chat-header">
                <!-- Título que se actualiza según cotización abierta -->
                <h3 id="chat-modal-title-user">Chat con Vendedor</h3>
                <!-- Botón X para cerrar modal -->
                <button id="chat-close-btn-user" class="icon-button">&times;</button>
            </div>

            <!-- VENTANA DE CHAT: Muestra conversación entre usuario y vendedor -->
            <!-- Se rellena dinámicamente con mensajes via JavaScript -->
            <!-- Interactúa con: api_vendedor.php (getChatMessages) -->
            <div id="chat-window-user" class="chat-window">
            </div>

            <!-- FORMULARIO ENVÍO DE MENSAJES: Permite usuario enviar mensajes al vendedor -->
            <!-- Interactúa con: JavaScript que valida y envía, api_vendedor.php (sendChatMessage) -->
            <form id="chat-form-user" class="chat-form">
                <!-- Input de texto para escribir mensaje -->
                <input type="text" id="chat-mensaje-user" name="mensaje" placeholder="Escribe tu mensaje..." required>
                <!-- Botón enviar -->
                <button type="submit" class="filled-button">Enviar</button>
            </form>
        </div>
    </div>
    
    <!-- CONTENEDOR NOTIFICACIONES: Muestra mensajes de éxito/error generados por JavaScript -->
    <!-- Manipulado por función global mostrarNotificacion() en script.js -->
    <div id="notification" class="notification"></div>

    <!-- SCRIPT GLOBAL: Importa script.js con funciones reutilizables (initTabs, mostrarNotificacion, etc.) -->
    <script src="script.js"></script>
    
    <!-- SCRIPT LOCAL: Lógica específica del perfil del usuario -->
    <script>
        // Espera a que DOM esté completamente cargado antes de ejecutar código
        document.addEventListener('DOMContentLoaded', () => {
            
            // --- CONSTANTES Y REFERENCIAS DE API ---
            // URLs de endpoints que manejan las operaciones del perfil
            // Interactúa con: api_vendedor.php, gestionar_usuarios.php
            const API_CHAT_URL = 'php/api_vendedor.php'; // Endpoint de chat y cotizaciones
            const API_USER_URL = 'php/gestionar_usuarios.php'; // Endpoint de actualización de perfil

            // --- INICIALIZACIÓN DE SISTEMA DE PESTAÑAS ---
            // Interactúa con: función global initTabs() en script.js, contenedores pestañas
            
            // LÍNEA 1-8: Inicializa el sistema de pestañas (Datos vs Cotizaciones)
            // Si usuario hace click en pestaña "Cotizaciones", ejecuta callback para cargar datos
            if (typeof initTabs === 'function') {
                // initTabs recibe callback que se ejecuta al cambiar de pestaña
                // Cuando tabId === 'cotizaciones', carga la lista de cotizaciones
                initTabs((tabId) => {
                    if (tabId === 'cotizaciones') {
                        cargarMisCotizaciones(); // Función definida abajo
                    }
                });
            } else {
                // Si initTabs no existe en script.js, registra error para debugging
                console.error("Error: initTabs no se encontró en script.js");
            }

            // --- LÓGICA PESTAÑA 1: "MIS DATOS PERSONALES" ---
            // Interactúa con: formulario id="profile-update-form", gestionar_usuarios.php
            
            // LÍNEA 10-26: Referencia al formulario de actualización de perfil
            const profileForm = document.getElementById('profile-update-form');
            if (profileForm) {
                // Al hacer submit en el formulario
                profileForm.addEventListener('submit', (e) => {
                    e.preventDefault(); // Previene recarga de página
                    
                    // FormData recoge automáticamente todos los campos del formulario
                    const formData = new FormData(profileForm);
                    
                    // POST a gestionar_usuarios.php que procesa la actualización
                    // Interactúa con: gestionar_usuarios.php (updateProfile)
                    fetch(API_USER_URL, { 
                        method: 'POST', 
                        body: formData 
                    })
                    .then(res => res.json()) // Convierte respuesta a JSON
                    .then(data => {
                        // Si data.success = true, perfil actualizado correctamente
                        if (data.success) {
                            mostrarNotificacion(data.message, false); // false = tipo success
                        } else {
                            // Si hubo error, muestra mensaje de error del servidor
                            mostrarNotificacion(data.message, true); // true = tipo error
                        }
                    })
                    // Si hay error de conexión
                    .catch(() => mostrarNotificacion('Error de conexión.', true));
                });
            }

            // --- LÓGICA PESTAÑA 2: "MIS COTIZACIONES (CHATS)" ---
            // Interactúa con: api_vendedor.php, chat modal, lista cotizaciones
            
            // LÍNEA 28-34: Referencias a elementos DOM del chat
            const chatListUser = document.getElementById('user-cotizaciones-list');
            const chatModal = document.getElementById('chat-modal-user');
            const chatCloseBtn = document.getElementById('chat-close-btn-user');
            const chatForm = document.getElementById('chat-form-user');
            const chatInput = document.getElementById('chat-mensaje-user');
            const chatWindow = document.getElementById('chat-window-user');
            const chatTitle = document.getElementById('chat-modal-title-user');
            
            // Variable global que almacena ID de cotización abierta actualmente
            // Usada para saber a qué cotización enviar mensajes
            let currentCotizacionId = null;

            // FUNCIÓN: Carga lista de cotizaciones del usuario desde servidor
            // Interactúa con: api_vendedor.php (getMisCotizaciones)
            function cargarMisCotizaciones() {
                // Muestra indicador de carga mientras obtiene datos
                chatListUser.innerHTML = '<p>Cargando cotizaciones...</p>';
                
                // Fetch GET a API que devuelve cotizaciones del usuario autenticado
                fetch(`${API_CHAT_URL}?action=getMisCotizaciones`)
                .then(res => res.json()) // Convierte respuesta a JSON
                .then(response => {
                    // Si respuesta es ok y hay datos en array
                    if (response.success && Array.isArray(response.data) && response.data.length > 0) {
                        chatListUser.innerHTML = ''; // Limpia el contenedor
                        
                        // Itera sobre cada cotización y crea tarjeta
                        response.data.forEach(cotizacion => {
                            // Crea elemento div para tarjeta
                            const card = document.createElement('div');
                            card.className = 'cotizacion-card';
                            
                            // Decide título: si hay modelo de vehículo lo usa, si no usa asunto
                            const tituloChat = cotizacion.vehiculo_modelo || cotizacion.asunto;
                            
                            // Rellena HTML con información de cotización
                            card.innerHTML = `
                                <div class="cotizacion-info">
                                    <h4>${tituloChat}</h4>
                                    <p>Asunto: ${cotizacion.asunto}</p>
                                    <p>Enviado: ${new Date(cotizacion.fecha).toLocaleDateString()}</p>
                                </div>
                                <button class="outlined-button chat-button-user" data-cotizacion-id="${cotizacion.id}" data-titulo="${tituloChat}">
                                    Ver Chat
                                </button>
                            `;
                            
                            // Agrega tarjeta al contenedor
                            chatListUser.appendChild(card);
                        });
                        
                        // Agrega event listeners a botones "Ver Chat"
                        // Cuando hace click, abre modal del chat
                        document.querySelectorAll('.chat-button-user').forEach(btn => {
                            btn.addEventListener('click', function() {
                                abrirChatUser(
                                    this.getAttribute('data-cotizacion-id'), // ID cotización
                                    this.getAttribute('data-titulo') // Título (modelo o asunto)
                                );
                            });
                        });
                        
                    } else {
                        // Si no hay cotizaciones, muestra mensaje y link para crear una
                        chatListUser.innerHTML = '<p>No has iniciado ninguna cotización. <a href="cotizar.php">¡Inicia una aquí!</a></p>';
                    }
                })
                // Si hay error al cargar
                .catch(() => chatListUser.innerHTML = '<p class="error-message">Error al cargar cotizaciones.</p>');
            }

            // FUNCIÓN: Abre modal del chat para una cotización específica
            // Parámetros: cotizacionId (número), titulo (string)
            function abrirChatUser(cotizacionId, titulo) {
                currentCotizacionId = cotizacionId; // Guarda ID actual en variable global
                chatTitle.textContent = `Chat sobre: ${titulo}`; // Actualiza título del modal
                chatModal.classList.add('show'); // Muestra modal (CSS lo hace visible)
                cargarMensajesUser(cotizacionId); // Carga mensajes de la cotización
            }

            // EVENTO: Cierra modal cuando hace click en botón X
            if (chatCloseBtn) {
                chatCloseBtn.addEventListener('click', () => chatModal.classList.remove('show'));
            }

            // FUNCIÓN: Carga y renderiza mensajes de una cotización
            // Parámetros: cotizacionId (número)
            // Interactúa con: api_vendedor.php (getChatMessages)
            function cargarMensajesUser(cotizacionId) {
                chatWindow.innerHTML = '<p>Cargando mensajes...</p>'; // Indicador de carga
                
                // Fetch GET a API que devuelve mensajes de esa cotización
                fetch(`${API_CHAT_URL}?action=getChatMessages&cotizacion_id=${cotizacionId}`)
                .then(res => res.json()) // Convierte a JSON
                .then(response => {
                    chatWindow.innerHTML = ''; // Limpia ventana
                    
                    // Si hay mensajes en respuesta
                    if (response.success && Array.isArray(response.data) && response.data.length > 0) {
                        // Itera sobre cada mensaje y lo renderiza
                        response.data.forEach(msg => {
                            // Crea contenedor del mensaje con clase que indica remitente (user/vendedor)
                            const msgDiv = document.createElement('div');
                            msgDiv.className = `chat-message-container ${msg.remitente_rol}`; 
                            
                            // Crea elemento con info del remitente (nombre, hora)
                            const infoDiv = document.createElement('div');
                            infoDiv.className = 'message-info';
                            infoDiv.innerHTML = `
                                <span class="sender-name">${msg.remitente_nombre || 'Vendedor'}</span>
                                <span class="message-time">${new Date(msg.fecha).toLocaleTimeString()}</span>
                            `;
                            
                            // Crea burbuja de mensaje con el contenido
                            const msgBubble = document.createElement('div');
                            msgBubble.className = 'chat-message'; 
                            msgBubble.textContent = msg.mensaje; // Texto del mensaje
                            
                            // Agrega info y burbuja al contenedor
                            msgDiv.appendChild(infoDiv);
                            msgDiv.appendChild(msgBubble);
                            
                            // Agrega contenedor al área de chat
                            chatWindow.appendChild(msgDiv);
                        });
                    } else {
                        // Si aún no hay mensajes, muestra texto informativo
                        chatWindow.innerHTML = '<p style="text-align: center; color: var(--color-plata-metalica);">Inicia la conversación.</p>';
                    }
                    
                    // Desplaza scroll al final para ver mensajes más recientes
                    chatWindow.scrollTop = chatWindow.scrollHeight; 
                });
            }

            // EVENTO: Manejo del envío de mensajes en el modal
            // Interactúa con: api_vendedor.php (sendChatMessage)
            if (chatForm) {
                chatForm.addEventListener('submit', function(e) {
                    e.preventDefault(); // Previene recarga de página
                    
                    const mensaje = chatInput.value; // Obtiene texto del input
                    
                    // Valida que haya texto y una cotización abierta
                    if (!mensaje.trim() || !currentCotizacionId) return;

                    // Prepara datos para enviar
                    const formData = new FormData();
                    formData.append('action', 'sendChatMessage'); // Acción
                    formData.append('cotizacion_id', currentCotizacionId); // ID cotización
                    formData.append('mensaje', mensaje); // Texto del mensaje

                    // POST a api_vendedor.php que procesa y guarda el mensaje
                    fetch(API_CHAT_URL, { method: 'POST', body: formData })
                    .then(res => res.json()) // Convierte a JSON
                    .then(data => {
                        if (data.success) {
                            // Si envío fue exitoso
                            chatInput.value = ''; // Limpia input
                            cargarMensajesUser(currentCotizacionId); // Recarga conversación
                        } else {
                            // Si hay error, muestra notificación
                            mostrarNotificacion(data.message, true);
                        }
                    })
                    // Si hay error de conexión
                    .catch(() => mostrarNotificacion('Error al enviar el mensaje.', true));
                });
            }

            // LÓGICA INICIAL: Si URL contiene ?tab=cotizaciones, carga esa pestaña
            // Útil cuando user es redirigido desde cotizar.php
            // Interactúa con: URL search params
            const urlParamsCheck = new URLSearchParams(window.location.search);
            if (urlParamsCheck.get('tab') === 'cotizaciones') {
                 cargarMisCotizaciones(); // Carga cotizaciones al cargar página
            }

        }); // fin DOMContentLoaded
    </script>
</body>
</html>
