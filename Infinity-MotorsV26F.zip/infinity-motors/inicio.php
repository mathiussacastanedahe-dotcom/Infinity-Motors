<?php
// Inicia o reanuda la sesión del usuario.
// Esto permite acceder a $_SESSION para información de usuario.
session_start();

// ========== VARIABLES DE SESIÓN ==========
// Obtiene el objeto/array 'user' de la sesión si existe, o null si no.
$user = $_SESSION['user'] ?? null;
// Booleano que indica si hay un usuario logueado.
$isLoggedIn = $user !== null;
// Inicializa la variable para mostrar el nombre en el header.
$userName = '';

// Si el usuario está logueado, extrae su nombre completo y toma el primer nombre.
if ($isLoggedIn) {
    // Nombre completo guardado en la sesión (ej: "Mathius Castañeda")
    $nombreCompleto = $user['nombre'] ?? '';
    // Separa por espacios y toma la primera palabra como primer nombre.
    $primerNombre = explode(' ', $nombreCompleto)[0];
    // Sanitiza el primer nombre para evitar XSS al imprimir en HTML.
    $userName = htmlspecialchars($primerNombre, ENT_QUOTES, 'UTF-8');
}

// Obtiene el rol del usuario (admin, vendedor, user) o 'guest' si no hay sesión.
$userRole = $user['rol'] ?? 'guest';

// ========== PERMISOS ==========
// Determina si se deben mostrar botones de gestión en la home (solo admin).
$showHomeManagementButtons = ($userRole === 'admin');
// Determina si es un usuario 'regular' (no admin ni vendedor) y está logueado.
$is_regular_user = $isLoggedIn && ($userRole === 'user'); 

// ========== CONSULTA DE DATOS ==========
// Conexión MySQLi al servidor local con base de datos 'infinity_motors'.
// Ajustar usuario/contraseña según tu entorno.
$mysqli_team = new mysqli("localhost", "root", "", "infinity_motors");

// Arrays para almacenar resultados de consultas que se mostrarán en HTML.
$team_members = [];
$vendedores = [];

// Verifica que la conexión no tenga errores antes de ejecutar consultas.
if (!$mysqli_team->connect_error) {
    // Consulta: obtiene usuarios que sean admin o vendedor, ordenados.
    $query_team = "SELECT nombre, rol FROM usuarios WHERE rol IN ('admin', 'vendedor') ORDER BY rol DESC, nombre ASC";
    $result_team = $mysqli_team->query($query_team);
    
    // Si la consulta devuelve resultados, los procesa fila por fila.
    if ($result_team) {
        while ($row = $result_team->fetch_assoc()) {
            // Sanitiza el nombre para evitar inyección XSS.
            $nombre = htmlspecialchars($row['nombre']);
            // Toma el rol tal cual desde la fila.
            $rol = $row['rol'];
            // Define un título base a partir del rol (Admin -> Admin).
            $titulo = ucfirst($rol);

            // Mapear títulos especiales por nombre (personalización).
            if ($nombre === 'Mathius Castañeda') {
                $titulo = 'Dueño';
            } elseif ($nombre === 'Santiago Padilla') {
                $titulo = 'Jefe';
            } elseif ($rol === 'admin') {
                // Si es admin y no coincide con los nombres especiales, también 'Dueño'.
                $titulo = 'Dueño';
            }
            
            // Agrega un miembro al array con nombre y título.
            $team_members[] = ['nombre' => $nombre, 'titulo' => $titulo];
        }
    }
    
    // Consulta adicional: lista de vendedores para poblar el select del modal.
    $query_vendedores = "SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre ASC";
    $result_vendedores = $mysqli_team->query($query_vendedores);
    
    // Si hay resultados, los agrega al array $vendedores (id, nombre).
    if ($result_vendedores) {
        while ($row = $result_vendedores->fetch_assoc()) {
            $vendedores[] = $row;
        }
    }
    
    // Cierra la conexión con la base de datos.
    $mysqli_team->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Metadatos básicos -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Motors - Lujo y Rendimiento</title>
    <!-- Hoja de estilos principal del proyecto -->
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <!-- ========== HEADER / NAVEGACIÓN ========== -->
    <header class="navbar sticky">
        <div class="row"> 
            <nav>
                <!-- Corregida referencia de home.php a inicio.php -->
                <div class="navbar-brand">
                    <a href="inicio.php">
                        <img src="assets/img/logo-icon.png" alt="Logo" class="logo-img">
                        <h1>Infinity Motors</h1>
                    </a>
                </div>
                
                <!-- Menú de navegación (ancoras internas) -->
                <ul id="menu">
                    <li><a href="inicio.php">Inicio</a></li>
                    <li><a href="#about">Sobre Nosotros</a></li>
                    <li><a href="#catalogo">Catálogo</a></li>
                    <li><a href="#equipo">Nuestro Equipo</a></li>
                </ul>
                
                <!-- ========== ACCIONES DE USUARIO (dinámicas) ========== -->
                <!-- Se muestran distintos botones según si hay sesión y el rol -->
                <div class="navbar-actions">
                    <?php if ($isLoggedIn): ?>
                        <!-- Si el usuario es regular (client) muestra enlace a perfil -->
                        <?php if ($is_regular_user): ?>
                            <a href="perfil.php" class="btn btn-profile">Perfil (<?= $userName ?>)</a>
                        <?php endif; ?>
                        
                        <!-- Si es admin muestra panel del dueño, si es vendedor el panel vendedor -->
                        <?php if ($userRole === 'admin'): ?>
                            <a href="admin.php" class="btn btn-admin">Panel Dueño</a>
                        <?php elseif ($userRole === 'vendedor'): ?>
                            <a href="vendedor.php" class="btn btn-admin">Panel Vendedor</a>
                        <?php endif; ?>
                        
                        <!-- Enlace para cerrar sesión (php/logout.php destruye la sesión) -->
                        <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
                    <?php else: ?>
                        <!-- Si no hay sesión, mostrar opciones para login/registro -->
                        <a href="login.html" class="btn btn-secondary">Iniciar Sesión</a>
                        <a href="register.html" class="btn btn-primary">Registrarme</a>
                    <?php endif; ?>
                </div>
                
                <!-- Toggle para menú móvil (se activa en script.js) -->
                <div class="mobile-toggle"><span></span><span></span><span></span></div>
            </nav>
        </div>
    </header>

    <!-- ========== HERO SECTION CON VIDEO ========== -->
    <section class="hero">
        <!-- Video autoplay silencioso en loop para el banner -->
        <video class="hero-video" autoplay muted loop playsinline>
            <source src="assets/video/hero-banner.mp4" type="video/mp4">
        </video>
        
        <!-- Comentario: si prefieres gif, reemplazar por un <img> (más ligero en algunos casos) -->
        <!-- <img class="hero-video" src="assets/img/hero-banner.gif" alt="Banner animado"> -->
        
        <!-- Overlays y contenido textual encima del video -->
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1>Infinity Motors</h1>
            <p>Experimenta el lujo y el rendimiento sin límites en cada curva.</p>
            <a href="#catalogo" class="btn btn-primary">EXPLORAR MODELOS EXCLUSIVOS</a>
        </div>
    </section>

    <!-- ========== SOBRE NOSOTROS ========== -->
    <!-- Contenido estático que explica la empresa -->
    <section id="about" class="info">
        <h2>Sobre Nosotros</h2>
        <p>
            Bienvenido a <b>Infinity Motors</b>, un concesionario destacado en la industria automotriz, 
            comprometido con brindarte los mejores vehículos y una experiencia de compra única.
        </p>
        <p>
            Nos especializamos en ofrecer una amplia gama de autos nuevos y de segunda mano, 
            todos cuidadosamente seleccionados. Nuestro equipo de expertos está aquí para ayudarte 
            a encontrar el vehículo perfecto que se ajuste a tu estilo de vida y presupuesto.
        </p>
        <p><strong>¡Gracias por elegirnos! Tu satisfacción es nuestra prioridad.</strong></p>
    </section>

    <!-- ========== CATÁLOGO DE VEHÍCULOS ========== -->
    <!-- El contenido de #car-list se inyecta dinámicamente desde script.js -->
    <section id="catalogo" class="catalogo">
        <h2>Catálogo de Vehículos</h2>
        <div id="car-list">
            <!-- Indicador inicial de carga que se reemplaza cuando llegan los datos -->
            <p class="loading-indicator">Cargando autos de lujo...</p>
        </div>
    </section>

    <hr>

    <!-- ========== SECCIÓN DE COTIZACIÓN (Solo para usuarios regulares) ========== -->
    <!-- Solo visible si $is_regular_user === true -->
    <?php if ($is_regular_user): ?>
    <section id="contact" class="info" style="text-align: center;">
        <h2>¿Interesado en un Vehículo?</h2>
        <p>Nuestro sistema te permite cotizar directamente con el vendedor de tu preferencia.</p>
        <a href="cotizar.php" class="btn btn-primary" style="font-size: 1.2rem; padding: 15px 40px;">
            Ir al Formulario de Cotización
        </a>
    </section>
    <?php endif; ?>

    <!-- ========== NUESTRO EQUIPO ========== -->
    <!-- Rellena las tarjetas con los miembros cargados desde la BD -->
    <section id="equipo" class="equipo">
        <h2>Nuestro Equipo</h2>
        <div class="team-grid">
            <?php if (!empty($team_members)): ?>
                <!-- Recorre $team_members y muestra cada tarjeta -->
                <?php foreach ($team_members as $member): ?>
                    <div class="team-card">
                        <!-- Título personalizado (Dueño, Jefe, Vendedor) -->
                        <h4><?= $member['titulo'] ?></h4>
                        <!-- Nombre (sanitizado anteriormente) -->
                        <p><?= $member['nombre'] ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Mensaje de fallback si no hay miembros -->
                <p style="color: var(--color-plata-metalica);">No se pudieron cargar los miembros del equipo.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- ========== FOOTER con año dinámico ========== -->
    <!-- date("Y") imprime el año actual en el servidor -->
    <footer>
        <p>© <?= date("Y") ?> Infinity Motors. Todos los derechos reservados.</p>
    </footer>

    <!-- ========== CONTENEDOR DE NOTIFICACIONES (vacío, JS lo llena) ========= -->
    <div id="notification" class="notification"></div>

    <!-- ========== MODAL DE EDICIÓN (SOLO PARA ADMIN) ========== -->
    <!-- El formulario envía a php/gestionar_vehiculos.php con enctype para archivos. -->
    <div id="edit-modal" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="edit-modal-title">Editar Vehículo</h2>
                <!-- Botón para cerrar modal (agrega/remueve la clase .show desde JS) -->
                <button id="edit-modal-close" class="icon-button">&times;</button>
            </div>
            
            <div class="modal-body">
                <!-- Formulario para actualizar un vehículo (updateCar) -->
                <form id="edit-modal-form" action="php/gestionar_vehiculos.php" method="POST" enctype="multipart/form-data">
                    <!-- Campo oculto para indicar la acción esperada en el backend -->
                    <input type="hidden" name="action" value="updateCar">
                    <!-- Campo oculto para pasar el id del vehículo que se edita -->
                    <input type="hidden" id="edit-car-id" name="id">
                    
                    <div class="form-grid">
                        <!-- Modelo -->
                        <div>
                            <label for="edit-modelo">Modelo</label>
                            <input type="text" id="edit-modelo" name="modelo" required>
                        </div>

                        <!-- Precio -->
                        <div>
                            <label for="edit-precio">Precio ($)</label>
                            <input type="number" id="edit-precio" name="precio" required min="1000">
                        </div>

                        <!-- Vendedor asignado (llenado desde $vendedores) -->
                        <div>
                            <label for="edit-vendedor_id">Vendedor Asignado</label>
                            <select id="edit-vendedor_id" name="vendedor_id" required>
                                <option value="">-- Seleccionar Vendedor --</option>
                                <?php foreach ($vendedores as $vendedor): ?>
                                    <option value="<?= $vendedor['id'] ?>">
                                        <?= htmlspecialchars($vendedor['nombre']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Estado del vehículo -->
                        <div>
                            <label for="edit-estado">Estado</label>
                            <select id="edit-estado" name="estado" required>
                                <option value="disponible">Disponible</option>
                                <option value="reservado">Reservado</option>
                                <option value="vendido">Vendido</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Descripción amplia del vehículo -->
                    <div class="form-full-width">
                        <label for="edit-descripcion">Descripción</label>
                        <textarea id="edit-descripcion" name="descripcion" rows="4"></textarea>
                    </div>
                    
                    <!-- Opción para cambiar imagen (file input) -->
                    <div class="form-full-width">
                        <label for="edit-imagen">Cambiar Imagen (Opcional)</label>
                        <input type="file" id="edit-imagen" name="imagen" accept="image/*">
                        <!-- Preview de imagen actual (se reemplaza dinámicamente desde JS si es necesario) -->
                        <img id="edit-current-image" src="/placeholder.svg" alt="Imagen actual" class="current-image-preview">
                    </div>
                    
                    <div class="form-full-width">
                        <!-- Botón para enviar cambios; el envío se maneja por fetch si quieres, o por post normal -->
                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top: 20px;">
                            Guardar Cambios
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ========== SCRIPTS ========== -->
    <!-- script.js contiene funciones globales (cargarProductos, mostrarNotificacion, toggles, etc.) -->
    <script src="script.js"></script> 
    <script>
        // Espera a que el DOM esté cargado para usar elementos HTML y variables PHP.
        document.addEventListener("DOMContentLoaded", () => {
            // Pasa variables de PHP a JS usando json_encode para seguridad/sanitización básica.
            const userRole = <?= json_encode($userRole) ?>;            // rol actual (ej: 'admin', 'user', 'vendedor', 'guest')
            const hasAccess = <?= json_encode($showHomeManagementButtons) ?>; // true si es admin
            const isRegular = <?= json_encode($is_regular_user) ?>;    // true si es usuario normal

            // URL del backend que devuelve JSON con el catálogo de autos.
            const fetchUrl = "php/gestionar_vehiculos.php?action=getCarsCatalogo";
            
            // Intento de llamada a la función cargarProductos que debe estar definida en script.js
            if (typeof cargarProductos === 'function') {
                // cargarProductos(fetchUrl, hasAccess, isRegular)
                // - fetchUrl: endpoint
                // - hasAccess: si se deben mostrar botones de edición/eliminación
                // - isRegular: si se debe mostrar funcionalidad de cotizar
                cargarProductos(fetchUrl, hasAccess, isRegular);
            } else {
                // Mensaje de consola si script.js no cargó o no definió la función.
                console.error("Error: 'cargarProductos' no se encontró en script.js.");
            }

            // ========== LÓGICA DEL MODAL DE EDICIÓN (solo si el usuario tiene acceso admin) ========== -->
            if (hasAccess) {
                // Referencias a elementos del modal
                const editModal = document.getElementById('edit-modal');
                const editModalCloseBtn = document.getElementById('edit-modal-close');
                const editForm = document.getElementById('edit-modal-form');

                // Agrega listener para cerrar el modal cuando se presiona la X
                if (editModalCloseBtn) {
                    editModalCloseBtn.addEventListener('click', () => {
                        editModal.classList.remove('show');
                    });
                }

                // Manejo del submit del formulario del modal usando fetch para mantener la SPA feel
                if (editForm) {
                    editForm.addEventListener('submit', function(e) {
                        // Evita el envío tradicional y usa fetch para mayor control y UX.
                        e.preventDefault();
                        const formData = new FormData(this);
                        
                        // Envía los datos a php/gestionar_vehiculos.php (el backend debe tratar 'updateCar')
                        fetch('php/gestionar_vehiculos.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => {
                            // Si la respuesta HTTP es 200-299 se considera ok
                            if (response.ok) {
                                // Muestra notificación de éxito y recarga la lista de autos
                                mostrarNotificacion("Vehículo actualizado con éxito.", false);
                                editModal.classList.remove('show');
                                cargarProductos(fetchUrl, hasAccess, isRegular); 
                            } else {
                                // Muestra error si la respuesta no fue ok (ej: 400/500)
                                mostrarNotificacion("Error al actualizar el vehículo.", true);
                            }
                        })
                        .catch(err => {
                            // Captura errores de red o excepciones
                            mostrarNotificacion("Error de conexión al actualizar.", true);
                            console.error('Error en fetch (updateCar):', err);
                        });
                    });
                }
            } // fin if (hasAccess)
        }); // fin DOMContentLoaded
    </script>
</body>
</html>
