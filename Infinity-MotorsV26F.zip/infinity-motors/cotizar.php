<?php
// LÍNEA 1: Inicia sesión para acceder a variables de sesión ($_SESSION)
session_start();

// LÍNEA 3-4: Obtiene usuario de la sesión (si no existe, $user será null)
$user = $_SESSION['user'] ?? null;

// LÍNEA 6-10: SEGURIDAD - Valida que el usuario está logueado Y tiene rol 'user'
// Si no cumple, redirige a login con mensaje de error
// Impide que vendedores o admins accedan a cotización
// Interactúa con: sistema de autenticación, login.html
if (!$user || $user['rol'] !== 'user') {
    header('Location: login.html?msg=Necesitas iniciar sesión para cotizar.');
    exit;
}

// LÍNEA 12-14: Extrae primer nombre del usuario para mostrar en navbar
// htmlspecialchars previene inyección XSS en HTML
// Interactúa con: navbar, mostrado en botón perfil
$userName = htmlspecialchars(explode(' ', $user['nombre'])[0]);
$userEmail = htmlspecialchars($user['email'] ?? '');
$userFullName = htmlspecialchars($user['nombre'] ?? '');

// LÍNEA 17: Importa archivo conexion.php que contiene $conn (conexión a BD)
// Interactúa con: conexion.php, base de datos
require_once "php/conexion.php";

// LÍNEA 20-26: Consulta SQL que obtiene lista de TODOS los vendedores ordenados alfabéticamente
// Los datos se guardan en array $vendedores para renderizar select HTML
// Interactúa con: tabla usuarios (rol='vendedor'), formulario cotización
$vendedores = [];
$result_vend = $conn->query("SELECT id, nombre FROM usuarios WHERE rol = 'vendedor' ORDER BY nombre");
while($row = $result_vend->fetch_assoc()) {
    $vendedores[] = $row;
}

// Los autos se cargarán dinámicamente via JavaScript
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- METADATOS HTML: Configuran la página para navegadores y SEO -->
    <meta charset="UTF-8"> <!-- Codificación UTF-8 para caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsive design mobile -->
    <title>Cotizar Vehículo | Infinity Motors</title> <!-- Título pestaña navegador -->
    <link rel="stylesheet" href="styles.css"> <!-- Hoja de estilos global -->
        <!-- ESTILOS LOCALES: CSS específico para esta página -->
    <style>
        .form-container {
            max-width: 650px; 
            margin: 40px auto; 
        }
    </style>
</head>
<body>
    <!-- HEADER NAVBAR: Barra de navegación fija con logo, menú y botones sesión -->
    <header class="navbar sticky"> <!-- sticky = permanece en top al hacer scroll -->
        <div class="row"> <!-- Contenedor grid con ancho controlado -->
            <nav>
                <!-- LOGO/MARCA: Enlaza a inicio.php -->
                <div class="navbar-brand">
                    <a href="inicio.php">
                        <img src="assets/img/logo-icon.png" alt="Logo" class="logo-img">
                        <h1>Infinity Motors</h1>
                    </a>
                </div> 
                
                <!-- MENÚ PRINCIPAL: Enlaces a secciones principales -->
                <!-- Interactúa con: inicio.php -->
                <ul id="menu">
                    <li><a href="home.php">Inicio</a></li>
                    <li><a href="home.php#catalogo">Catálogo</a></li>
                </ul>
                
                <!-- ACCIONES USUARIO: Botones de perfil y cerrar sesión -->
                <!-- Interactúa con: perfil.php, logout.php -->
                <div class="navbar-actions">
                    <!-- Enlace a perfil mostrando primer nombre del usuario (sanitizado) -->
                    <a href="perfil.php" class="btn btn-profile">Mi Perfil (<?= $userName ?>)</a>
                    <!-- Enlace para destruir sesión y cerrar sesión -->
                    <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
                </div>
                
                <!-- TOGGLE MÓVIL: Tres líneas para abrir/cerrar menú en dispositivos móviles -->
                <div class="mobile-toggle"><span></span><span></span><span></span></div>
            </nav>
        </div>
    </header>

    <!-- BANNER/HERO: Sección de bienvenida con título -->
    <div class="banner-login">
        <h1>Formulario de Cotización</h1>
    </div>

    <!-- MAIN: Contenedor principal con formulario de cotización -->
    <main class="perfil-container form-container">
        <!-- Descripción del proceso -->
        <h2>Iniciar una nueva cotización</h2>
        <p>Completa el formulario para contactar a uno de nuestros vendedores. Podrás seguir la conversación desde tu perfil.</p>
        
        <!-- FORMULARIO COTIZACIÓN: Recoge datos del usuario y preferencias de vehículo -->
        <!-- Interactúa con: api_vendedor.php (crearCotizacion), perfil.php (redirección) -->
        <form id="cotizacion-form" class="login-form-card" style="max-width: 100%;">
            <!-- Campo oculto que indica acción: crearCotizacion -->
            <input type="hidden" name="action" value="crearCotizacion">
            
            <!-- Campos ocultos con datos del usuario desde $_SESSION -->
            <!-- Interactúa con: variables PHP $userFullName, $userEmail -->
            <input type="hidden" id="usuario_nombre" name="usuario_nombre" value="<?= $userFullName ?>">
            <input type="hidden" id="usuario_email_hidden" name="usuario_email" value="<?= $userEmail ?>">
            
            <!-- Email visible pero readonly: muestra email del usuario de forma informativa -->
            <!-- Readonly = no editable (protege integridad de datos) -->
            <label for="usuario_email">Tu Email:</label>
            <input type="email" id="usuario_email" name="usuario_email_display" value="<?= $userEmail ?>" readonly>
            
            <!-- SELECT VENDEDOR: Dropdown que carga datos del array PHP $vendedores -->
            <!-- Interactúa con: JavaScript para cargar vehículos dinámicamente -->
            <label for="vendedor_id">Vendedor al que deseas contactar:</label>
            <select id="vendedor_id" name="vendedor_id" required>
                <option value="">Selecciona un vendedor...</option>
                <?php foreach ($vendedores as $vendedor): ?>
                    <option value="<?= $vendedor['id'] ?>">
                        <?= htmlspecialchars($vendedor['nombre']) ?>
                    </option>
                <?php endforeach; ?>
                <?php if (empty($vendedores)): ?>
                    <option value="" disabled>No hay vendedores disponibles.</option>
                <?php endif; ?>
            </select>
            
            <!-- SELECT VEHÍCULO (DEPENDIENTE): Se habilita/llena solo cuando selecciona vendedor -->
            <!-- Interactúa con: JavaScript que carga autos vía API gestionar_vehiculos.php -->
            <label for="vehiculo_id">Vehículo de interés (Opcional):</label>
            <select id="vehiculo_id" name="vehiculo_id" disabled>
                <option value="0">Selecciona un vendedor primero...</option>
            </select>
            
            <!-- ASUNTO: Campo de texto que se auto-llena según vehículo seleccionado -->
            <!-- JavaScript actualiza este campo al cambiar vehículo -->
            <label for="asunto">Asunto:</label>
            <input type="text" id="asunto" name="asunto" placeholder="Ej: Interés en Ferrari F8" required>

            <!-- MENSAJE: Textarea que se auto-llena según vehículo seleccionado -->
            <!-- JavaScript genera mensaje personalizado basado en selección -->
            <label for="mensaje">Tu primer mensaje:</label>
            <textarea id="mensaje" name="mensaje" rows="5" placeholder="Escribe tu consulta aquí..." required></textarea>
            
            <!-- BOTÓN SUBMIT: Envía cotización y crea chat con vendedor -->
            <button type="submit" class="btn btn-primary" style="width: 100%;">Enviar Cotización e Iniciar Chat</button>
        </form>
    </main>

    <!-- NOTIFICACIONES: Contenedor donde aparecen mensajes de éxito/error -->
    <!-- Manipulado por función global mostrarNotificacion() en script.js -->
    <div id="notification" class="notification"></div>

    <!-- IMPORTA SCRIPT GLOBAL: Contiene funciones reutilizables (mostrarNotificacion, etc.) -->
    <script src="script.js"></script>
    
    <!-- SCRIPT LOCAL: Lógica específica de cotización -->
    <script>
        // Espera a que DOM esté completamente cargado antes de ejecutar código
        document.addEventListener('DOMContentLoaded', () => {
            
            // REFERENCIAS A ELEMENTOS DOM: Guardan referencias para mejor rendimiento
            const cotizacionForm = document.getElementById('cotizacion-form');
            const vendedorSelect = document.getElementById('vendedor_id');
            const vehiculoSelect = document.getElementById('vehiculo_id');
            const asuntoInput = document.getElementById('asunto');
            const mensajeInput = document.getElementById('mensaje');
            
            // URLs DE API: Endpoints que se usan para obtener datos del servidor
            // Interactúa con: api_vendedor.php (crearCotizacion, etc.), gestionar_vehiculos.php (getCarsByVendedor)
            const API_FORM_URL = 'php/api_vendedor.php'; 
            const API_CARS_URL = 'php/gestionar_vehiculos.php';

            
            // --- DROPDOWN DEPENDIENTE: AL CAMBIAR VENDEDOR CARGA SUS VEHÍCULOS ---
            // Interactúa con: API gestionar_vehiculos.php, JavaScript
            
            // LÍNEA 1-22: Evento que se ejecuta cuando el usuario selecciona un vendedor
            vendedorSelect.addEventListener('change', () => {
                const vendedorId = vendedorSelect.value; // Obtiene ID del vendedor seleccionado
                
                // Limpia select de vehículos (por si había datos previos)
                vehiculoSelect.innerHTML = '';
                vehiculoSelect.disabled = true; // Deshabilita mientras carga
                
                // Limpia asunto y mensaje (se rellenarán después)
                asuntoInput.value = '';
                mensajeInput.value = '';

                // Si el usuario realmente seleccionó un vendedor (no la opción vacía)
                if (vendedorId) {
                    // Muestra mensaje "Cargando..." mientras obtiene datos
                    vehiculoSelect.innerHTML = '<option value="0">Cargando vehículos...</option>';
                    
                    // Fetch GET a API que devuelve vehículos de ese vendedor
                    // Interactúa con: gestionar_vehiculos.php (getCarsByVendedor)
                    fetch(`${API_CARS_URL}?action=getCarsByVendedor&vendedor_id=${vendedorId}`)
                        .then(response => response.json()) // Convierte respuesta a JSON
                        .then(autos => {
                            // Limpia "Cargando..." anterior
                            vehiculoSelect.innerHTML = '';

                            // Opción por defecto: "Consulta general" sin vehículo específico
                            const generalOption = document.createElement('option');
                            generalOption.value = '0';
                            generalOption.textContent = 'Consulta general (Sin vehículo específico)';
                            vehiculoSelect.appendChild(generalOption);

                            // Si hay vehículos, itera y crea option por cada uno
                            if (autos && autos.length > 0) {
                                autos.forEach(auto => {
                                    const option = document.createElement('option');
                                    option.value = auto.id; // ID del vehículo
                                    // Formatea precio con separadores de miles en formato español
                                    const precio = parseFloat(auto.precio).toLocaleString('es-CO');
                                    option.textContent = `${auto.modelo} ($${precio})`; // Modelo + precio
                                    vehiculoSelect.appendChild(option);
                                });
                            } else {
                                // Si el vendedor no tiene vehículos asignados, muestra mensaje
                                const noCarsOption = document.createElement('option');
                                noCarsOption.value = '0';
                                noCarsOption.disabled = true;
                                noCarsOption.textContent = 'Este vendedor no tiene autos asignados.';
                                vehiculoSelect.appendChild(noCarsOption);
                            }
                            
                            // Habilita el select de vehículos ya que finalizó carga
                            vehiculoSelect.disabled = false;
                        })
                        // Si hay error en la petición
                        .catch(err => {
                            console.error('Error al cargar vehículos:', err);
                            vehiculoSelect.innerHTML = '<option value="0">Error al cargar autos</option>';
                        });
                } else {
                    // Si vuelve a "Selecciona un vendedor..." (valor vacío)
                    vehiculoSelect.innerHTML = '<option value="0">Selecciona un vendedor primero...</option>';
                }
            });

            // --- EVENTO: AL CAMBIAR VEHÍCULO SE AUTO-RELLENA ASUNTO Y MENSAJE ---
            // Interactúa con: campos asunto y mensaje del formulario
            
            // LÍNEA 24-36: Evento que se ejecuta cuando el usuario selecciona un vehículo
            vehiculoSelect.addEventListener('change', () => {
                const vehiculoId = vehiculoSelect.value; // Obtiene ID del vehículo
                const selectedOption = vehiculoSelect.options[vehiculoSelect.selectedIndex]; // Opción seleccionada
                const modeloText = selectedOption.textContent; // Texto completo (modelo + precio)
                
                if (vehiculoId === '0') {
                    // Si selecciona "Consulta general" (sin vehículo específico)
                    asuntoInput.value = 'Consulta General'; // Asunto genérico
                    mensajeInput.value = 'Hola, me gustaría obtener más información sobre los vehículos disponibles. ¿Podrías ayudarme?';
                } else {
                    // Si selecciona un vehículo específico
                    // Extrae solo el modelo (sin el precio que está entre paréntesis)
                    const modelo = modeloText.split(' (')[0];
                    asuntoInput.value = `Interés en ${modelo}`; // Asunto personalizado
                    mensajeInput.value = `Hola, estoy interesado en el vehículo ${modelo}. ¿Podrías darme más detalles y hablar sobre las opciones disponibles?`;
                }
            });

            
            // --- LÓGICA DE ENVÍO DEL FORMULARIO ---
            // Interactúa con: api_vendedor.php (crearCotizacion), perfil.php (redirección)
            
            // LÍNEA 38-65: Al hacer submit en el formulario
            cotizacionForm.addEventListener('submit', (e) => {
                e.preventDefault(); // Previene comportamiento por defecto (recarga página)
                
                // Recoge todos los datos del formulario en objeto FormData
                const formData = new FormData(cotizacionForm);
                
                // Obtiene referencia al botón para deshabilitarlo (evita múltiples envíos)
                const submitButton = cotizacionForm.querySelector('button[type="submit"]');
                submitButton.disabled = true; // Deshabilita botón
                submitButton.textContent = 'Enviando...'; // Cambia texto para feedback visual

                // POST a api_vendedor.php que procesa la cotización
                fetch(API_FORM_URL, {
                    method: 'POST',
                    body: formData // Envía datos incluido acción y mensaje
                })
                .then(response => response.json()) // Convierte respuesta JSON
                .then(data => {
                    // Si data.success = true, cotización se creó correctamente
                    if (data.success) {
                        mostrarNotificacion(data.message, false); // Muestra mensaje éxito
                        cotizacionForm.reset(); // Limpia formulario
                        
                        // Resetea también el dropdown de vehículos
                        vehiculoSelect.innerHTML = '<option value="0">Selecciona un vendedor primero...</option>';
                        vehiculoSelect.disabled = true;
                        
                        // Después de 2 segundos, redirige a perfil en tab de cotizaciones
                        setTimeout(() => {
                            window.location.href = 'perfil.php?tab=cotizaciones';
                        }, 2000);
                    } else {
                        // Si hubo error, muestra mensaje de error del servidor
                        mostrarNotificacion(data.message || 'Error al enviar la cotización.', true);
                        
                        // Re-habilita botón para que usuario pueda intentar de nuevo
                        submitButton.disabled = false;
                        submitButton.textContent = 'Enviar Cotización e Iniciar Chat';
                    }
                })
                // Si hay error de conexión con servidor
                .catch(error => {
                    mostrarNotificacion('Error de conexión con el servidor.', true);
                    
                    // Re-habilita botón para reintentar
                    submitButton.disabled = false;
                    submitButton.textContent = 'Enviar Cotización e Iniciar Chat';
                });
            });
        });
    </script>
</body>
</html>
