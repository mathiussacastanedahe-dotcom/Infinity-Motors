<?php
// Inicia o reanuda la sesión PHP para acceder a $_SESSION.
session_start();

// Obtiene el usuario almacenado en sesión (si existe), o null si no.
$user = $_SESSION['user'] ?? null;

// Seguridad: solo vendedores y admin pueden acceder a este panel.
// Si no hay usuario o su rol no es 'vendedor' ni 'admin', se bloquea el acceso.
if (!$user || ($user['rol'] !== 'vendedor' && $user['rol'] !== 'admin')) {
    // Redirige a la home con un mensaje en la URL indicando acceso denegado.
    header('Location: inicio.php?msg=Acceso denegado al panel de ventas.');
    // Detiene la ejecución del script para evitar que se renderice el resto.
    exit;
}

// Guarda el id del vendedor desde la sesión (útil para consultas filtradas).
$vendedorId = $user['id'];

// Nombre del vendedor sanitizado para imprimir en HTML de forma segura.
$vendedorNombre = htmlspecialchars($user['nombre']);

// Flags booleanos según el rol del usuario para condicionales en la vista/JS.
$isAdmin = $user['rol'] === 'admin';
$isSeller = $user['rol'] === 'vendedor';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <title>Panel Vendedor | Infinity Motors</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <header class="navbar sticky">
        <div class="row"> 
            <nav>
                <div class="navbar-brand">
                    <a href="inicio.php">
                        <img src="assets/img/logo-icon.png" alt="Logo" class="logo-img">
                        <h1>Infinity Motors</h1>
                    </a>
                </div> 
                <ul id="menu">
                    <li><a href="inicio.php">Inicio</a></li>
                    <li><a href="inicio.php#catalogo">Catálogo</a></li>
                </ul>
                <div class="navbar-actions">
                    <?php if ($isAdmin): ?>
                        <a href="admin.php" class="btn btn-admin">Panel Admin</a>
                    <?php endif; ?>
                    <a href="php/logout.php" class="btn btn-danger">Cerrar Sesión</a>
                </div>
                <div class="mobile-toggle"><span></span><span></span><span></span></div>
            </nav>
        </div>
    </header>
    
    <div class="banner-login">
        <h1>Panel de Vendedor: <?= $vendedorNombre ?></h1>
    </div>
    
    <main class="perfil-container">
        <h2>Gestión de Ventas y Clientes</h2>
        
        <div class="tab-navigation">
            <button class="tab-button active" data-tab="historial">Historial de Ventas</button>
            <button class="tab-button" data-tab="registrar">Registrar Nueva Venta</button>
            <button class="tab-button" data-tab="cotizaciones">Cotizaciones y Chats</button>
        </div>
        
        <div id="historial" class="tab-content active">
            <h3>Tus Ventas Realizadas</h3>
            <div id="sales-history-list" class="tabla-compras">
                <p>Cargando historial...</p> </div>
        </div>
        
        <div id="registrar" class="tab-content">
            <h3>Registrar Transacción</h3>
            <form id="register-sale-form">
                <label for="car_id">Vehículo Vendido:</label>
                <select id="car_id" name="car_id" required>
                    <option value="">Cargando autos disponibles...</option>
                </select>

                <label for="cliente_email">Email del Cliente:</label>
                <input type="email" id="cliente_email" name="cliente_email" required>

                <label for="cliente_nombre">Nombre del Cliente:</label>
                <input type="text" id="cliente_nombre" name="cliente_nombre" required>

                <label for="fecha_venta">Fecha de Venta:</label>
                <input type="date" id="fecha_venta" name="fecha_venta" value="<?= date('Y-m-d') ?>" required>

                <label for="monto_final">Monto Final ($):</label>
                <input type="number" id="monto_final" name="monto_final" step="100" required>

                <button type="submit" class="btn">Registrar Venta y Actualizar Stock</button>
            </form>
        </div>
        
        <div id="cotizaciones" class="tab-content">
            <h3>Cotizaciones y Chats Recibidos</h3>
            <div class="table-controls" style="margin-bottom: 20px;">
                <div class="search-box">
                    <input type="text" id="cotizacion-search" placeholder="Buscar por nombre de cliente...">
                </div>
                <div class="records-selector">
                    <label for="cotizacion-records">Mostrar:</label>
                    <select id="cotizacion-records">
                        <option value="5">5 registros</option>
                        <option value="10" selected>10 registros</option>
                        <option value="15">15 registros</option>
                        <option value="20">20 registros</option>
                        <option value="all">Todos</option>
                    </select>
                </div>
            </div>
            <div id="vendedor-cotizaciones-list" class="cotizacion-list">
                <p>Cargando cotizaciones...</p> </div>
        </div>
    </main>

    <div id="chat-modal-vendedor" class="modal-overlay">
        <div class="modal-content-chat">
            <div class="chat-header">
                <div>
                    <h3 id="chat-modal-title-vendedor">Chat con Cliente</h3>
                    <p id="chat-client-info" style="color: var(--color-plata-oscura); font-size: 0.9rem; margin-top: 4px;"></p>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <button id="chat-delete-btn-vendedor" class="btn btn-danger btn-sm" title="Eliminar chat">
                        Eliminar
                    </button>
                    <button id="chat-close-btn-vendedor" class="icon-button">&times;</button>
                </div>
            </div>
            <div id="chat-window-vendedor" class="chat-window">
            </div>
            <form id="chat-form-vendedor" class="chat-form">
                <input type="text" id="chat-mensaje-vendedor" name="mensaje" placeholder="Escribe tu respuesta..." required>
                <button type="submit" class="filled-button">Enviar</button>
            </form>
        </div>
    </div>
    
    <div id="notification" class="notification"></div>

    <script src="script.js"></script> 
    
    <script>
        // Ejecuta cuando el DOM esté listo
        document.addEventListener('DOMContentLoaded', () => {
            
            // --- URL ÚNICA DE API PARA ESTE PANEL --- 
            const API_URL = 'php/api_vendedor.php';

            // --- SELECTORES DE ELEMENTOS DEL DOM --- 
            const tabButtons = document.querySelectorAll('.tab-button'); // botones de pestañas
            const tabContents = document.querySelectorAll('.tab-content'); // contenidos de pestañas
            const registerForm = document.getElementById('register-sale-form'); // form registrar venta
            const salesHistoryList = document.getElementById('sales-history-list'); // contenedor historial
            const carSelect = document.getElementById('car_id'); // select de autos disponibles
            const chatListVendedor = document.getElementById('vendedor-cotizaciones-list'); // lista de cotizaciones
            const chatCloseBtn = document.getElementById('chat-close-btn-vendedor'); // botón cerrar
            const chatForm = document.getElementById('chat-form-vendedor'); // form enviar mensaje
            const chatInput = document.getElementById('chat-mensaje-vendedor'); // input mensaje
            const chatWindow = document.getElementById('chat-window-vendedor'); // ventana mensajes
            const chatTitle = document.getElementById('chat-modal-title-vendedor'); // título del modal
            const chatDeleteBtn = document.getElementById('chat-delete-btn-vendedor'); // botón eliminar chat
            const clientInfo = document.getElementById('chat-client-info'); // información del cliente
            let currentCotizacionId = null; // id de la cotización abierta actualmente
            
            // --- (NUEVO) Selectores para el formulario de Venta ---
            const montoFinalInput = document.getElementById('monto_final');
            const clienteEmailInput = document.getElementById('cliente_email');
            const clienteNombreInput = document.getElementById('cliente_nombre');


            // --- LÓGICA DE PESTAÑAS (initTabs inline) --- 
            tabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const tabId = button.getAttribute('data-tab'); 

                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    tabContents.forEach(content => content.classList.remove('active'));

                    button.classList.add('active');
                    document.getElementById(tabId).classList.add('active');

                    if (tabId === 'historial') {
                        fetchSalesHistory(); 
                    } else if (tabId === 'registrar') {
                        fetchAvailableCars(); 
                    } else if (tabId === 'cotizaciones') {
                        cargarCotizacionesRecibidas(); 
                    }
                });
            });

            // --- Lógica de Registrar Venta (Pestaña "Registrar") --- 
            if (registerForm) {
                registerForm.addEventListener('submit', (e) => {
                    e.preventDefault(); 
                    const formData = new FormData(registerForm); 
                    formData.append('action', 'registerSale'); 
                    
                    fetch(API_URL, { method: 'POST', body: formData })
                    .then(response => response.json()) 
                    .then(data => {
                        if (data.success) {
                            mostrarNotificacion('Venta registrada exitosamente.', false);
                            registerForm.reset();
                            fetchAvailableCars();
                            fetchSalesHistory();
                        } else {
                            mostrarNotificacion(data.message || 'Error al registrar la venta.', true);
                        }
                    })
                    .catch(error => mostrarNotificacion('Error de conexión al registrar.', true)); 
                });
            }
            
            // --- ✨ NUEVO: Listener para auto-rellenar el precio ---
            if (carSelect && montoFinalInput) {
                carSelect.addEventListener('change', () => {
                    // Obtenemos la opción seleccionada
                    const selectedOption = carSelect.options[carSelect.selectedIndex];
                    
                    // Obtenemos el precio que guardamos en el 'data-precio'
                    const precio = selectedOption.getAttribute('data-precio');
                    
                    if (precio) {
                        montoFinalInput.value = precio; // Lo ponemos en el input de monto
                    } else {
                        montoFinalInput.value = ''; // Limpiamos si seleccionan "Selecciona..."
                    }
                });
            }

            // --- ✨ NUEVO: Listener para auto-rellenar el nombre por email ---
            if (clienteEmailInput && clienteNombreInput) {
                clienteEmailInput.addEventListener('blur', () => { // 'blur' se activa cuando sales del campo
                    const email = clienteEmailInput.value.trim();
                    if (email.includes('@')) {
                        // Llamamos a la nueva API (que debe existir en api_vendedor.php)
                        fetch(`${API_URL}?action=getUserByEmail&email=${encodeURIComponent(email)}`)
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                clienteNombreInput.value = data.data.nombre; // ¡Autocompletado!
                            }
                        })
                        .catch(err => console.error("Error buscando email:", err));
                    }
                });
            }


            // --- Pestaña "HISTORIAL": función para obtener ventas realizadas --- 
            function fetchSalesHistory() {
                salesHistoryList.innerHTML = '<p>Cargando historial...</p>';
                const formData = new FormData();
                formData.append('action', 'getSalesHistory'); 
                
                fetch(API_URL, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        salesHistoryList.innerHTML = ''; 
                        if (data.sales && data.sales.length > 0) {
                            const table = document.createElement('table');
                            table.className = "tabla-compras";
                            let tableHtml = `
                                <thead>
                                    <tr>
                                        <th>ID</th> <th>Vehículo</th> <th>Cliente</th>
                                        <th>Email</th> <th>Fecha</th> <th>Monto</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${data.sales.map(sale => ` 
                                        <tr>
                                            <td>${sale.id}</td>
                                            <td>${sale.vehiculo_modelo}</td>
                                            <td>${sale.cliente_nombre}</td>
                                            <td>${sale.cliente_email}</td>
                                            <td>${sale.fecha_venta}</td>
                                            <td>$${parseInt(sale.monto_final).toLocaleString('es-CO')}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>`;
                            table.innerHTML = tableHtml;
                            salesHistoryList.appendChild(table); 
                        } else {
                            salesHistoryList.innerHTML = '<p>Aún no has registrado ninguna venta.</p>';
                        }
                    } else {
                        salesHistoryList.innerHTML = `<p class="error-message">${data.message || 'Error.'}</p>`;
                    }
                })
                .catch(error => salesHistoryList.innerHTML = `<p class="error-message">Error de conexión.</p>`); 
            }

            // --- Pestaña "REGISTRAR": obtiene autos disponibles para vender --- 
            function fetchAvailableCars() {
                carSelect.innerHTML = '<option value="">Cargando autos disponibles...</option>';
                const formData = new FormData();
                formData.append('action', 'getAvailableCars'); 
                
                fetch(API_URL, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    carSelect.innerHTML = '<option value="">Selecciona un vehículo</option>';
                    if (data.success && Array.isArray(data.cars) && data.cars.length > 0) {
                        data.cars.forEach(car => {
                            const option = document.createElement('option');
                            option.value = car.id;
                            
                            // --- ✨ MODIFICADO: Guardamos el precio en un data-attribute ---
                            option.setAttribute('data-precio', car.precio);
                            
                            option.textContent = `${car.modelo} - $${parseInt(car.precio).toLocaleString('es-CO')}`;
                            carSelect.appendChild(option);
                        });
                    } else {
                        carSelect.innerHTML = '<option value="">No tienes autos disponibles asignados.</option>';
                    }
                })
                .catch(error => carSelect.innerHTML = `<option value="">Error de conexión.</option>`); 
            }

            // --- Pestaña "COTIZACIONES Y CHAT": carga cotizaciones recibidas --- 
            function cargarCotizacionesRecibidas() {
                chatListVendedor.innerHTML = '<p>Cargando cotizaciones...</p>';
                
                const formData = new FormData();
                formData.append('action', 'getCotizacionesRecibidas');
                
                fetch(API_URL, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(response => {
                    console.log("[v0] Cotizaciones recibidas:", response);
                    
                    if (response.success && response.data && response.data.length > 0) {
                        chatListVendedor.innerHTML = '';
                        response.data.forEach(cotizacion => {
                            const card = document.createElement('div');
                            card.className = 'cotizacion-card';
                            const tituloChat = cotizacion.cliente_nombre; 
                            card.innerHTML = ` 
                                <div class="cotizacion-info">
                                    <h4>Cliente: ${tituloChat}</h4>
                                    <p>Email: ${cotizacion.cliente_email || 'No disponible'}</p>
                                    <p>Asunto: ${cotizacion.asunto}</p>
                                    <p>Recibido: ${new Date(cotizacion.fecha).toLocaleDateString()}</p>
                                </div>
                                <button class="outlined-button chat-button-vendedor" 
                                        data-cotizacion-id="${cotizacion.id}" 
                                        data-titulo="${tituloChat}"
                                        data-email="${cotizacion.cliente_email || ''}">
                                    Responder Chat
                                </button>
                            `;
                            chatListVendedor.appendChild(card);
                        });
                        
                        document.querySelectorAll('.chat-button-vendedor').forEach(btn => {
                            btn.addEventListener('click', function() {
                                abrirChatVendedor(
                                    this.getAttribute('data-cotizacion-id'),
                                    this.getAttribute('data-titulo'),
                                    this.getAttribute('data-email')
                                );
                            });
                        });

                        const searchBox = document.getElementById('cotizacion-search');
                        const recordsSelect = document.getElementById('cotizacion-records');
                        
                        if (searchBox) {
                            searchBox.addEventListener('input', function() {
                                const searchTerm = this.value.toLowerCase();
                                const cards = chatListVendedor.querySelectorAll('.cotizacion-card');
                                
                                cards.forEach(card => {
                                    const clientName = card.querySelector('h4')?.textContent.toLowerCase() || '';
                                    const asunto = card.querySelector('p')?.textContent.toLowerCase() || '';
                                    
                                    if (clientName.includes(searchTerm) || asunto.includes(searchTerm)) {
                                        card.style.display = '';
                                    } else {
                                        card.style.display = 'none';
                                    }
                                });
                            });
                        }
                        
                        if (recordsSelect) {
                            recordsSelect.addEventListener('change', function() {
                                const limit = this.value;
                                const cards = Array.from(chatListVendedor.querySelectorAll('.cotizacion-card'));
                                
                                if (limit === 'all') {
                                    cards.forEach(card => card.style.display = '');
                                } else {
                                    const limitNum = parseInt(limit);
                                    cards.forEach((card, index) => {
                                        card.style.display = index < limitNum ? '' : 'none';
                                    });
                                }
                            });
                        }
                        
                    } else {
                        chatListVendedor.innerHTML = '<p>No hay cotizaciones recibidas.</p>';
                    }
                })
                .catch(err => {
                    console.error("[v0] Error cargando cotizaciones:", err);
                    chatListVendedor.innerHTML = '<p>Error al cargar cotizaciones.</p>';
                });
            }

            // Abre modal del chat para la cotización dada y carga mensajes
            function abrirChatVendedor(cotizacionId, nombreCliente, emailCliente) {
                currentCotizacionId = cotizacionId; 
                chatTitle.textContent = `Chat con: ${nombreCliente}`; 
                if (clientInfo) {
                    clientInfo.textContent = emailCliente ? `${emailCliente}` : '';
                }
                document.getElementById('chat-modal-vendedor').classList.add('show');
                
                cargarMensajesVendedor(cotizacionId); 
            }

            // Listener para cerrar modal (X)
            if (chatCloseBtn) {
                chatCloseBtn.addEventListener('click', () => {
                     document.getElementById('chat-modal-vendedor').classList.remove('show');
                });
            }

            if (chatDeleteBtn) {
                chatDeleteBtn.addEventListener('click', () => {
                    if (!currentCotizacionId) return;
                    
                    if (confirm('¿Estás seguro de que deseas eliminar este chat? Esta acción no se puede deshacer.')) {
                        const formData = new FormData();
                        formData.append('action', 'deleteCotizacion');
                        formData.append('cotizacion_id', currentCotizacionId);
                        
                        fetch(API_URL, { method: 'POST', body: formData })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                mostrarNotificacion('Chat eliminado exitosamente.', false);
                                document.getElementById('chat-modal-vendedor').classList.remove('show');
                                cargarCotizacionesRecibidas(); // Recargar lista
                            } else {
                                mostrarNotificacion(data.message || 'Error al eliminar chat.', true);
                            }
                        })
                        .catch(() => mostrarNotificacion('Error de conexión.', true));
                    }
                });
            }

            // Carga mensajes de una cotización concreta para el vendedor
            function cargarMensajesVendedor(cotizacionId) {
                chatWindow.innerHTML = '<p>Cargando mensajes...</p>'; 
                fetch(`${API_URL}?action=getChatMessages&cotizacion_id=${cotizacionId}`)
                .then(res => res.json())
                .then(response => {
                    chatWindow.innerHTML = ''; 
                    if (response.success && response.data && response.data.length > 0) {
                        response.data.forEach(msg => {
                            const msgDiv = document.createElement('div');
                            msgDiv.className = `chat-message-container ${msg.remitente_rol}`; 
                            
                            const infoDiv = document.createElement('div');
                            infoDiv.className = 'message-info';
                            infoDiv.innerHTML = `
                                <span class="sender-name">${msg.remitente_nombre || 'Usuario'}</span>
                                <span class="message-time">${new Date(msg.fecha).toLocaleTimeString()}</span>
                            `;
                            
                            const msgBubble = document.createElement('div');
                            msgBubble.className = 'chat-message'; 
                            msgBubble.textContent = msg.mensaje;
                            
                            msgDiv.appendChild(infoDiv);
                            msgDiv.appendChild(msgBubble);
                            chatWindow.appendChild(msgDiv);
                        });
                    } else {
                        chatWindow.innerHTML = '<p style="text-align: center; color: var(--color-plata-metalica);">Aún no hay mensajes. Responde para iniciar.</p>';
                    }
                    chatWindow.scrollTop = chatWindow.scrollHeight;
                });
            }

            // Envío de mensajes desde el modal del vendedor
            if (chatForm) {
                chatForm.addEventListener('submit', function(e) {
                    e.preventDefault(); 
                    const mensaje = chatInput.value; 
                    if (!mensaje.trim() || !currentCotizacionId) return;

                    const formData = new FormData();
                    formData.append('action', 'sendChatMessage');
                    formData.append('cotizacion_id', currentCotizacionId);
                    formData.append('mensaje', mensaje);

                    fetch(API_URL, { method: 'POST', body: formData })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            chatInput.value = '';
                            cargarMensajesVendedor(currentCotizacionId); 
                        } else {
                            mostrarNotificacion(data.message, true);
                        }
                    });
                });
            }

            // --- Carga inicial al abrir el panel --- 
            fetchSalesHistory();
        });
    </script>
</body>
</html>